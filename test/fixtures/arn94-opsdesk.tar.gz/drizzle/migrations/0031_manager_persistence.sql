-- ARN-97: SOURCE ONLY. DO NOT APPLY TO CANONICAL SUPABASE WITHOUT OWNER RELEASE GATE.
-- Requires ARN-88 0030_execution_broker.sql. Manager writes are a separate tenant-scoped
-- journal, not another execution lock/budget broker and not a live dispatcher.
--
-- Adversarial bounds: broker_caller ONLY, verified ACP executor claim, tenant_ids claim,
-- no table privileges, audited atomic transitions, no client payloads, zero budget.
-- Setting request.jwt.claims in a disposable PostgreSQL test is NOT proof of JWT verification.
BEGIN;

-- The isolated independent verifier is a NOLOGIN role, not an agent with
-- ambient permissions. An authenticated gateway must assume this role using
-- verified claims; a broker_caller cannot grant it to itself.
DO $role$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='manager_verifier') THEN
  CREATE ROLE manager_verifier NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
 END IF;
END
$role$;
GRANT USAGE ON SCHEMA public TO manager_verifier;

-- The existing ARN-88 broker_owner is NOLOGIN/NOBYPASSRLS; the owner of these objects
-- is the sole table reader/writer through SECURITY DEFINER RPCs.
CREATE TABLE public.manager_event_receipts (
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  event_id text NOT NULL CHECK (length(event_id) BETWEEN 1 AND 200),
  task_id text NOT NULL CHECK (length(task_id) BETWEEN 1 AND 200),
  seq bigint NOT NULL CHECK (seq >= 0),
  expectation jsonb NOT NULL CHECK (jsonb_typeof(expectation) = 'object'),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','admitted','staged')),
  job jsonb,
  outcome jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, event_id),
  CHECK ((status = 'pending' AND job IS NULL AND outcome IS NULL) OR
         (status IN ('admitted','staged') AND job IS NOT NULL))
);
CREATE TABLE public.manager_task_cursors (
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  task_id text NOT NULL CHECK (length(task_id) BETWEEN 1 AND 200),
  max_seq bigint NOT NULL CHECK (max_seq >= 0),
  PRIMARY KEY (tenant_id, task_id)
);
CREATE TABLE public.manager_claim_bindings (
  tenant_id uuid NOT NULL,
  event_id text NOT NULL,
  claim_id uuid NOT NULL,
  attempt_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, event_id),
  CONSTRAINT manager_claim_unique UNIQUE (tenant_id, claim_id),
  FOREIGN KEY (tenant_id, event_id) REFERENCES public.manager_event_receipts (tenant_id, event_id)
);
CREATE TABLE public.manager_verifications (
  tenant_id uuid NOT NULL,
  event_id text NOT NULL,
  fence bigint NOT NULL CHECK (fence BETWEEN 1 AND 3),
  decision text NOT NULL CHECK (decision IN ('complete','failed')),
  verifier text NOT NULL CHECK (length(verifier) BETWEEN 1 AND 60),
  evidence_ref text NOT NULL CHECK (length(evidence_ref) BETWEEN 1 AND 200),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, event_id, fence),
  FOREIGN KEY (tenant_id, event_id) REFERENCES public.manager_event_receipts (tenant_id, event_id)
);
CREATE TABLE public.manager_audit_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  event_id text NOT NULL,
  task_id text NOT NULL,
  job_id text,
  step text NOT NULL CHECK (length(step) BETWEEN 1 AND 80),
  outcome text NOT NULL CHECK (length(outcome) BETWEEN 1 AND 1024),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, event_id) REFERENCES public.manager_event_receipts (tenant_id, event_id)
);
CREATE INDEX manager_audit_tenant_event_idx
  ON public.manager_audit_entries (tenant_id, event_id, created_at, id);

-- Audit history is append-only even for privileged maintenance SQL. Recovery
-- is represented by a new audit entry, never by modifying evidence in place.
CREATE FUNCTION public.manager_int_forbid_audit_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'manager audit is append-only'; END;
$$;
CREATE TRIGGER manager_audit_immutable BEFORE UPDATE OR DELETE ON public.manager_audit_entries
  FOR EACH ROW EXECUTE FUNCTION public.manager_int_forbid_audit_mutation();
CREATE TRIGGER manager_verification_immutable BEFORE UPDATE OR DELETE ON public.manager_verifications
  FOR EACH ROW EXECUTE FUNCTION public.manager_int_forbid_audit_mutation();
CREATE TRIGGER manager_binding_immutable BEFORE UPDATE OR DELETE ON public.manager_claim_bindings
  FOR EACH ROW EXECUTE FUNCTION public.manager_int_forbid_audit_mutation();
ALTER TABLE public.manager_claim_bindings OWNER TO broker_owner;
ALTER TABLE public.manager_verifications OWNER TO broker_owner;
ALTER TABLE public.manager_event_receipts OWNER TO broker_owner;
ALTER TABLE public.manager_task_cursors OWNER TO broker_owner;
ALTER TABLE public.manager_audit_entries OWNER TO broker_owner;
ALTER TABLE public.manager_claim_bindings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.manager_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.manager_event_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.manager_task_cursors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.manager_audit_entries ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.manager_event_receipts, public.manager_task_cursors,
  public.manager_audit_entries, public.manager_claim_bindings, public.manager_verifications
  FROM PUBLIC, anon, authenticated, service_role,
  broker_caller, broker_intake, broker_gateway, manager_verifier;

CREATE FUNCTION public.manager_int_refuse(reason text) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'manager_denied:%', reason USING ERRCODE = '42501'; END;
$$;

-- These checks run inside a trusted definer call. The gateway must validate JWT
-- signature, issuer, audience and role before installing claims; SQL cannot do so.
CREATE FUNCTION public.manager_int_auth(tenant uuid) RETURNS void
LANGUAGE plpgsql STABLE AS $$
BEGIN
  IF tenant IS NULL OR public.broker_int_executor() <> 'acp'
     OR NOT coalesce(public.broker_int_tenant_allowed(tenant), false)
  THEN PERFORM public.manager_int_refuse('unauthorized'); END IF;
END;
$$;

CREATE FUNCTION public.manager_int_expectation(e jsonb, tenant uuid, task text)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE k text; i text; t text; ex text;
BEGIN
  IF jsonb_typeof(e) IS DISTINCT FROM 'object' THEN PERFORM public.manager_int_refuse('bad_expectation'); END IF;
  IF EXISTS (SELECT 1 FROM jsonb_object_keys(e) AS names(k) WHERE names.k NOT IN
     ('kind','intent','tier','executor','claimKey','bodyDigest','permissionsExpireAt','maxBudgetMicros'))
  THEN PERFORM public.manager_int_refuse('extra_expectation'); END IF;
  k := e ->> 'kind'; i := e ->> 'intent'; t := e ->> 'tier'; ex := e ->> 'executor';
  IF k IS NULL OR i IS NULL OR t IS NULL OR ex IS NULL OR NOT (
     (k = 'task_completed' AND i = 'review_result' AND t = 'green') OR
     (k = 'owner_schedule' AND i = 'periodic_summary' AND t = 'green') OR
     (k = 'task_exception' AND i = 'triage_exception' AND t = 'yellow'))
     OR ex NOT IN ('claude','chatgpt') OR ex IS NULL
     OR e ->> 'claimKey' IS DISTINCT FROM tenant::text || ':' || task || ':' || i
     OR coalesce(length(e ->> 'bodyDigest'),0) NOT BETWEEN 1 AND 128
     OR jsonb_typeof(e -> 'maxBudgetMicros') IS DISTINCT FROM 'number'
     OR e ->> 'maxBudgetMicros' IS DISTINCT FROM '0'
     OR e ->> 'permissionsExpireAt' IS NULL
  THEN PERFORM public.manager_int_refuse('unapproved_expectation'); END IF;
  BEGIN
    IF (e ->> 'permissionsExpireAt')::timestamptz <= now()
    THEN PERFORM public.manager_int_refuse('expired_grant'); END IF;
  EXCEPTION WHEN invalid_datetime_format OR datetime_field_overflow THEN
    PERFORM public.manager_int_refuse('invalid_expiration');
  END;
END;
$$;

-- No payload or client content can be inserted through this function. The only
-- accepted data are the typed manager job envelope and evidence fields.
CREATE FUNCTION public.manager_int_job(j jsonb, rec public.manager_event_receipts, desired text)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE exp jsonb := rec.expectation;
BEGIN
  IF jsonb_typeof(j) IS DISTINCT FROM 'object' OR desired NOT IN ('admitted','staged')
  THEN PERFORM public.manager_int_refuse('invalid_job'); END IF;
  IF EXISTS (SELECT 1 FROM jsonb_object_keys(j) AS names(k) WHERE names.k NOT IN (
      'jobId','eventId','correlationId','tenantId','taskId','source','intent','tier','trigger',
      'idempotencyKey','claimKey','executor','permissions','permissionsExpireAt',
      'maxBudgetMicros','state','attempt','replayId','claimId','attemptId','fence','result','order'))
  THEN PERFORM public.manager_int_refuse('extra_job_data'); END IF;
  IF j ->> 'tenantId' IS DISTINCT FROM rec.tenant_id::text OR
     j ->> 'eventId' IS DISTINCT FROM rec.event_id OR
     j ->> 'taskId' IS DISTINCT FROM rec.task_id OR
     j ->> 'source' IS DISTINCT FROM 'internal' OR
     j ->> 'idempotencyKey' IS DISTINCT FROM rec.tenant_id::text || ':' || rec.event_id OR
     j ->> 'claimKey' IS DISTINCT FROM exp ->> 'claimKey' OR
     j ->> 'intent' IS DISTINCT FROM exp ->> 'intent' OR
     j ->> 'tier' IS DISTINCT FROM exp ->> 'tier' OR
     j ->> 'executor' IS DISTINCT FROM exp ->> 'executor' OR
     j ->> 'permissionsExpireAt' IS DISTINCT FROM exp ->> 'permissionsExpireAt' OR
     j ->> 'maxBudgetMicros' IS DISTINCT FROM '0' OR
     jsonb_typeof(j -> 'maxBudgetMicros') IS DISTINCT FROM 'number' OR
     j -> 'permissions' IS DISTINCT FROM jsonb_build_array(exp ->> 'intent') OR
     j -> 'trigger' ->> 'kind' IS DISTINCT FROM exp ->> 'kind' OR
     j -> 'trigger' ->> 'seq' IS DISTINCT FROM rec.seq::text OR
     j -> 'trigger' ->> 'bodyDigest' IS DISTINCT FROM exp ->> 'bodyDigest' OR
     jsonb_typeof(j -> 'result') IS DISTINCT FROM 'null' OR
     coalesce(length(j ->> 'jobId'),0) NOT BETWEEN 1 AND 200 OR
     coalesce(length(j ->> 'correlationId'),0) NOT BETWEEN 1 AND 200 OR
     j ->> 'attempt' IS DISTINCT FROM '1' OR
     j ->> 'replayId' IS DISTINCT FROM (j ->> 'jobId') || '#1' OR
     (desired='staged' AND j ->> 'state' IS DISTINCT FROM 'awaiting_owner') OR
     (desired='admitted' AND j ->> 'state' IS DISTINCT FROM 'admitted')
  THEN PERFORM public.manager_int_refuse('job_mismatch'); END IF;
  IF desired = 'staged' AND
     (j -> 'claimId' <> 'null'::jsonb OR j -> 'attemptId' <> 'null'::jsonb OR j -> 'fence' <> 'null'::jsonb)
  THEN PERFORM public.manager_int_refuse('staged_must_not_claim'); END IF;
END;
$$;

-- This attestation only comes from a fresh join against existing broker rows,
-- never from a client-provided boolean. Manager actor selection is validated
-- against immutable receipt expectation; broker execution actor is always ACP.
CREATE FUNCTION public.manager_int_claim_proof(rec public.manager_event_receipts)
RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE cl public.execution_claims; a public.execution_attempts;
  binding public.manager_claim_bindings;
BEGIN
  IF rec.status <> 'admitted' OR rec.job IS NULL OR rec.job ->> 'claimId' IS NULL THEN RETURN NULL; END IF;
  SELECT * INTO binding FROM public.manager_claim_bindings
    WHERE tenant_id=rec.tenant_id AND event_id=rec.event_id
      AND claim_id::text=rec.job ->> 'claimId'
      AND attempt_id::text=rec.job ->> 'attemptId';
  IF NOT FOUND THEN RETURN NULL; END IF;
  SELECT * INTO cl FROM public.execution_claims
    WHERE id=binding.claim_id
      AND tenant_id=rec.tenant_id AND command_key=rec.expectation ->> 'claimKey';
  IF NOT FOUND THEN RETURN NULL; END IF;
  -- Duplicate evidence is scoped to the exact immutable attempt admitted
  -- for this event, never a newer claim reclaim at a higher fence.
  SELECT * INTO a FROM public.execution_attempts
    WHERE id = binding.attempt_id AND claim_id = cl.id AND executor = 'acp';
  IF NOT FOUND OR a.fence <> cl.fence
     OR a.fence::text IS DISTINCT FROM rec.job ->> 'fence'
  THEN RETURN NULL; END IF;
  -- The event's idempotency key is kept in the immutable receipt job; the
  -- ARN-88 claim does NOT independently store event idempotency. The identity
  -- binding is therefore tenant/key/claim plus receipt provenance, not a
  -- separate cryptographic broker-idempotency proof.
  RETURN jsonb_build_object(
    'verified', true, 'claimId', cl.id::text, 'tenantId', rec.tenant_id::text,
    'claimKey', cl.command_key,
    'idempotencyKey', rec.tenant_id::text || ':' || rec.event_id,
    'executor', rec.expectation ->> 'executor', 'brokerExecutor', a.executor);
END;
$$;

CREATE FUNCTION public.manager_int_audit(tenant uuid, event text, task text, jid text, name text, verdict text)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE v_id uuid;
BEGIN
  IF coalesce(length(name),0) NOT BETWEEN 1 AND 80 OR
     coalesce(length(verdict),0) NOT BETWEEN 1 AND 1024
  THEN PERFORM public.manager_int_refuse('invalid_audit'); END IF;
  INSERT INTO public.manager_audit_entries (tenant_id,event_id,task_id,job_id,step,outcome)
    VALUES (tenant,event,task,jid,name,verdict) RETURNING id INTO v_id;
  RETURN v_id;
END;
$$;

CREATE FUNCTION public.manager_record_receipt(p_data jsonb)
RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE t uuid; e text; task text; n bigint; exp jsonb; cur public.manager_task_cursors;
        rec public.manager_event_receipts; proof jsonb;
BEGIN
  IF jsonb_typeof(p_data) IS DISTINCT FROM 'object' THEN PERFORM public.manager_int_refuse('invalid_input'); END IF;
  t := (p_data ->> 'tenantId')::uuid; e := p_data ->> 'eventId';
  task := p_data ->> 'taskId'; n := (p_data ->> 'seq')::bigint; exp := p_data -> 'expectation';
  PERFORM public.manager_int_auth(t);
  IF coalesce(length(e),0) NOT BETWEEN 1 AND 200 OR
     coalesce(length(task),0) NOT BETWEEN 1 AND 200 OR n IS NULL OR n < 0 OR
     jsonb_typeof(p_data -> 'seq') IS DISTINCT FROM 'number'
  THEN PERFORM public.manager_int_refuse('invalid_input'); END IF;
  PERFORM public.manager_int_expectation(exp,t,task);
  INSERT INTO public.manager_task_cursors (tenant_id,task_id,max_seq)
    VALUES (t,task,0) ON CONFLICT DO NOTHING;
  SELECT * INTO cur FROM public.manager_task_cursors
    WHERE tenant_id=t AND task_id=task FOR UPDATE;
  SELECT * INTO rec FROM public.manager_event_receipts
    WHERE tenant_id=t AND event_id=e FOR UPDATE;
  IF FOUND THEN
    IF rec.task_id <> task OR rec.seq <> n OR rec.expectation <> exp
    THEN PERFORM public.manager_int_refuse('duplicate_mismatch'); END IF;
    proof := public.manager_int_claim_proof(rec);
    RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,'eventId',e,
      'taskId',task,'verdict','duplicate',
      'entry',jsonb_build_object('status',rec.status,'job',rec.job,'outcome',rec.outcome) -
         CASE WHEN rec.outcome IS NULL THEN 'outcome' ELSE '__not_a_key__' END,
      'claimProof',proof);
  END IF;
  IF n <= cur.max_seq THEN
    -- This refusal is evidence-backed and immutable, but creates no receipt
    -- because an older event must never occupy the monotonic event stream.
    RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
      'eventId',e,'taskId',task,'verdict','out_of_order');
  END IF;
  INSERT INTO public.manager_event_receipts (tenant_id,event_id,task_id,seq,expectation)
    VALUES (t,e,task,n,exp);
  UPDATE public.manager_task_cursors SET max_seq=n
    WHERE tenant_id=t AND task_id=task;
  PERFORM public.manager_int_audit(t,e,task,NULL,'receipt_recorded','pending');
  RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,'eventId',e,
                            'taskId',task,'verdict','new');
END;
$$;

CREATE FUNCTION public.manager_resolve_receipt(p_data jsonb)
RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE t uuid; e text; task text; desired text; j jsonb; rec public.manager_event_receipts;
        cl public.execution_claims; a public.execution_attempts;
BEGIN
  t := (p_data ->> 'tenantId')::uuid; e := p_data ->> 'eventId';
  task := p_data ->> 'taskId'; desired := p_data ->> 'status'; j := p_data -> 'job';
  PERFORM public.manager_int_auth(t);
  SELECT * INTO rec FROM public.manager_event_receipts
    WHERE tenant_id=t AND event_id=e FOR UPDATE;
  IF NOT FOUND OR rec.task_id IS DISTINCT FROM task OR desired NOT IN ('admitted','staged')
  THEN PERFORM public.manager_int_refuse('missing_receipt'); END IF;
  PERFORM public.manager_int_job(j,rec,desired);
  IF rec.status <> 'pending' THEN
    IF rec.status = desired AND rec.job = j
    THEN RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
       'eventId',e,'taskId',task,'status',desired); END IF;
    PERFORM public.manager_int_refuse('conflicting_admission');
  END IF;
  -- A receipt created just before the grant expires must never be admitted
  -- after expiration. Revalidate in the same locked transition.
  PERFORM public.manager_int_expectation(rec.expectation,t,task);
  IF desired = 'admitted' THEN
    IF j ->> 'claimId' IS NULL OR j ->> 'attemptId' IS NULL OR j ->> 'fence' IS NULL
    THEN PERFORM public.manager_int_refuse('unclaimed_admission'); END IF;
    SELECT * INTO cl FROM public.execution_claims WHERE id::text = j ->> 'claimId'
      AND tenant_id=t AND command_key=rec.expectation ->> 'claimKey' FOR SHARE;
    IF NOT FOUND THEN PERFORM public.manager_int_refuse('foreign_claim'); END IF;
    SELECT * INTO a FROM public.execution_attempts WHERE id::text = j ->> 'attemptId'
      AND claim_id=cl.id AND executor='acp' FOR SHARE;
    IF NOT FOUND OR a.fence <> cl.fence OR a.fence::text <> j ->> 'fence'
      OR a.state <> 'claimed' OR a.reserved_micros <> 0
    THEN PERFORM public.manager_int_refuse('unverified_claim'); END IF;
    -- One claim can have only one manager event lineage. Unique claim binding
    -- prevents two different event receipts settling off one broker execution.
    INSERT INTO public.manager_claim_bindings (tenant_id,event_id,claim_id,attempt_id)
      VALUES (t,e,cl.id,a.id);
  END IF;
  PERFORM public.manager_int_audit(t,e,task,j ->> 'jobId','admission_resolved',desired);
  UPDATE public.manager_event_receipts SET status=desired,job=j,updated_at=now()
    WHERE tenant_id=t AND event_id=e;
  RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
                            'eventId',e,'taskId',task,'status',desired);
END;
$$;

CREATE FUNCTION public.manager_record_terminal(p_data jsonb)
RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE t uuid; e text; s text; f bigint; rec public.manager_event_receipts;
        cl public.execution_claims; a public.execution_attempts;
BEGIN
  t := (p_data ->> 'tenantId')::uuid; e := p_data ->> 'eventId';
  s := p_data -> 'outcome' ->> 'state'; f := (p_data -> 'outcome' ->> 'fence')::bigint;
  PERFORM public.manager_int_auth(t);
  IF s IS NULL OR s NOT IN ('complete','failed') OR f IS NULL OR f < 1 OR f > 3
  THEN PERFORM public.manager_int_refuse('invalid_terminal'); END IF;
  SELECT * INTO rec FROM public.manager_event_receipts
    WHERE tenant_id=t AND event_id=e FOR UPDATE;
  IF NOT FOUND OR rec.status <> 'admitted' OR rec.job IS NULL
  THEN PERFORM public.manager_int_refuse('unadmitted_terminal'); END IF;
  IF rec.outcome IS NOT NULL THEN
    IF rec.outcome = jsonb_build_object('state',s,'fence',f)
    THEN RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
       'eventId',e,'state',s,'fence',f); END IF;
    PERFORM public.manager_int_refuse('conflicting_terminal');
  END IF;
  SELECT * INTO cl FROM public.execution_claims WHERE id::text = rec.job ->> 'claimId'
    AND tenant_id=t AND command_key=rec.expectation ->> 'claimKey' FOR SHARE;
  IF NOT FOUND THEN PERFORM public.manager_int_refuse('foreign_claim'); END IF;
  -- Terminal evidence is valid only for the exact attempt/fence admitted
  -- into the immutable receipt, never a later reclaim of the same claim.
  SELECT * INTO a FROM public.execution_attempts
    WHERE id::text = rec.job ->> 'attemptId' AND claim_id=cl.id
      AND fence=f AND executor='acp' FOR SHARE;
  IF NOT FOUND OR a.fence <> cl.fence
     OR a.fence::text IS DISTINCT FROM rec.job ->> 'fence' OR
     (s='complete' AND (a.state <> 'settled' OR a.actual_micros <> 0)) OR
     (s='failed' AND a.state <> 'failed')
  THEN PERFORM public.manager_int_refuse('terminal_not_confirmed'); END IF;
  -- The manager/broker_caller may record an audit message but may NOT
  -- independently attest verification. Only a distinct NOLOGIN verifier
  -- role can write the matching immutable verification row.
  IF NOT EXISTS (
    SELECT 1 FROM public.manager_verifications v
    WHERE v.tenant_id=t AND v.event_id=e AND v.fence=f AND v.decision=s
      AND v.verifier IS DISTINCT FROM rec.job ->> 'executor'
  ) THEN PERFORM public.manager_int_refuse('missing_independent_verification'); END IF;
  PERFORM public.manager_int_audit(t,e,rec.task_id,rec.job ->> 'jobId','terminal_recorded',
    s || '/fence=' || f::text);
  UPDATE public.manager_event_receipts SET outcome=jsonb_build_object('state',s,'fence',f),
    updated_at=now() WHERE tenant_id=t AND event_id=e;
  RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
                            'eventId',e,'state',s,'fence',f);
END;
$$;

-- The verifier role can only attest one bounded outcome per attempt.
-- It cannot enqueue, settle, or mutate the manager/broker ledger.
CREATE FUNCTION public.manager_record_verification(p_data jsonb)
RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE t uuid; e text; f bigint; decision text; checked text; ref text;
        rec public.manager_event_receipts; existing public.manager_verifications;
        claims jsonb := public.broker_int_claims();
BEGIN
  t := (p_data ->> 'tenantId')::uuid; e := p_data ->> 'eventId';
  f := (p_data ->> 'fence')::bigint; decision := p_data ->> 'decision';
  checked := claims ->> 'verifier'; ref := p_data ->> 'evidenceRef';
  IF claims ->> 'executor' IS DISTINCT FROM 'verifier'
     OR claims ->> 'role' IS DISTINCT FROM 'manager_verifier'
     OR NOT public.broker_int_tenant_allowed(t)
  THEN PERFORM public.manager_int_refuse('not_independent_verifier'); END IF;
  IF f IS NULL OR f NOT BETWEEN 1 AND 3 OR decision IS NULL
    OR decision NOT IN ('complete','failed') OR
    coalesce(length(checked),0) NOT BETWEEN 1 AND 60 OR
    coalesce(length(ref),0) NOT BETWEEN 1 AND 200
  THEN PERFORM public.manager_int_refuse('invalid_verification'); END IF;
  SELECT * INTO rec FROM public.manager_event_receipts
    WHERE tenant_id=t AND event_id=e FOR UPDATE;
  IF NOT FOUND OR rec.status <> 'admitted' OR rec.job IS NULL
     OR checked = rec.job ->> 'executor'
  THEN PERFORM public.manager_int_refuse('self_or_unknown_verification'); END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.manager_claim_bindings b
    JOIN public.execution_claims c ON c.id=b.claim_id AND c.tenant_id=b.tenant_id
    JOIN public.execution_attempts a ON a.id=b.attempt_id AND a.claim_id=c.id
    WHERE b.tenant_id=t AND b.event_id=e AND a.fence=f
       AND a.fence::text = rec.job ->> 'fence'
       AND a.executor='acp' AND a.fence=c.fence
  ) THEN PERFORM public.manager_int_refuse('unverified_broker_attempt'); END IF;
  SELECT * INTO existing FROM public.manager_verifications
    WHERE tenant_id=t AND event_id=e AND fence=f;
  IF FOUND THEN
    IF existing.decision=decision AND existing.verifier=checked AND existing.evidence_ref=ref
    THEN RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
      'eventId',e,'fence',f,'state',decision,'verified',true); END IF;
    PERFORM public.manager_int_refuse('conflicting_verification');
  END IF;
  INSERT INTO public.manager_verifications (tenant_id,event_id,fence,decision,verifier,evidence_ref)
    VALUES (t,e,f,decision,checked,ref);
  PERFORM public.manager_int_audit(t,e,rec.task_id,rec.job ->> 'jobId',
    'independent_verification',decision || '/fence=' || f::text);
  RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
    'eventId',e,'fence',f,'state',decision,'verified',true);
END;
$$;

CREATE FUNCTION public.manager_append_audit(p_data jsonb)
RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE t uuid; e text; task text; rec public.manager_event_receipts; auditid uuid;
BEGIN
  t := (p_data ->> 'tenantId')::uuid;
  e := p_data ->> 'eventId'; task := p_data ->> 'taskId';
  PERFORM public.manager_int_auth(t);
  SELECT * INTO rec FROM public.manager_event_receipts
    WHERE tenant_id=t AND event_id=e FOR SHARE;
  IF NOT FOUND OR rec.task_id <> task THEN PERFORM public.manager_int_refuse('missing_receipt'); END IF;
  -- Only opaque job reference and bounded state strings may be logged, no body/content.
  IF coalesce(length(p_data ->> 'step'),0) NOT BETWEEN 1 AND 80 OR
     coalesce(length(p_data ->> 'outcome'),0) NOT BETWEEN 1 AND 1024 OR
     (p_data ->> 'jobId' IS NOT NULL AND
      p_data ->> 'jobId' IS DISTINCT FROM rec.job ->> 'jobId')
  THEN PERFORM public.manager_int_refuse('invalid_audit'); END IF;
  auditid := public.manager_int_audit(t,e,task,p_data ->> 'jobId',
                                    p_data ->> 'step',p_data ->> 'outcome');
  RETURN jsonb_build_object('ok',true,'committed',true,'tenantId',t::text,
     'eventId',e,'taskId',task,'auditId',auditid::text);
END;
$$;

-- Owner tables are inaccessible even with a service_role key; access requires
-- verified caller privileges plus a tenant-scoped, authenticated broker context.
ALTER FUNCTION public.manager_int_forbid_audit_mutation() OWNER TO broker_owner;
ALTER FUNCTION public.manager_int_refuse(text) OWNER TO broker_owner;
ALTER FUNCTION public.manager_int_auth(uuid) OWNER TO broker_owner;
ALTER FUNCTION public.manager_int_expectation(jsonb,uuid,text) OWNER TO broker_owner;
ALTER FUNCTION public.manager_int_job(jsonb,public.manager_event_receipts,text) OWNER TO broker_owner;
ALTER FUNCTION public.manager_int_claim_proof(public.manager_event_receipts) OWNER TO broker_owner;
ALTER FUNCTION public.manager_int_audit(uuid,text,text,text,text,text) OWNER TO broker_owner;
ALTER FUNCTION public.manager_record_receipt(jsonb) OWNER TO broker_owner;
ALTER FUNCTION public.manager_resolve_receipt(jsonb) OWNER TO broker_owner;
ALTER FUNCTION public.manager_record_terminal(jsonb) OWNER TO broker_owner;
ALTER FUNCTION public.manager_append_audit(jsonb) OWNER TO broker_owner;
ALTER FUNCTION public.manager_record_verification(jsonb) OWNER TO broker_owner;
REVOKE ALL ON FUNCTION
  public.manager_int_forbid_audit_mutation(), public.manager_int_refuse(text), public.manager_int_auth(uuid),
  public.manager_int_expectation(jsonb,uuid,text),
  public.manager_int_job(jsonb,public.manager_event_receipts,text),
  public.manager_int_claim_proof(public.manager_event_receipts),
  public.manager_int_audit(uuid,text,text,text,text,text),
  public.manager_record_receipt(jsonb),public.manager_resolve_receipt(jsonb),
  public.manager_record_terminal(jsonb),public.manager_append_audit(jsonb),
  public.manager_record_verification(jsonb)
  FROM PUBLIC, anon, authenticated, service_role, broker_caller, broker_intake,
  broker_gateway, manager_verifier;
GRANT EXECUTE ON FUNCTION
  public.manager_record_receipt(jsonb),public.manager_resolve_receipt(jsonb),
  public.manager_record_terminal(jsonb),public.manager_append_audit(jsonb)
  TO broker_caller;
GRANT EXECUTE ON FUNCTION public.manager_record_verification(jsonb)
  TO manager_verifier;

COMMENT ON TABLE public.manager_event_receipts IS
 'ARN-97: disabled manager receipt, task sequence and immutable admission/terminal evidence. Never client payload.';
COMMENT ON FUNCTION public.manager_record_receipt(jsonb) IS
 'ARN-97: requires verified gateway ACP principal/tenant scope; source only, not applied to canonical Supabase.';
COMMIT;
