CREATE OR REPLACE FUNCTION public.audit_platform_row() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.platform_audit_events (actor_user_id, action, entity, entity_id, inputs, outcome, side_effect)
  VALUES (auth.uid(), TG_TABLE_NAME || '_' || lower(TG_OP), TG_TABLE_NAME, NULL, to_jsonb(NEW), 'recorded', 'none');
  RETURN NEW;
END $$;

CREATE TABLE public.platform_sender_config (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  legal_sender_name text, from_domain text, reply_to text, postal_address text,
  unsubscribe_status text NOT NULL DEFAULT 'not_configured' CHECK (unsubscribe_status IN ('not_configured','configured')),
  spf_status text NOT NULL DEFAULT 'not_verified' CHECK (spf_status IN ('not_verified','verified')),
  dkim_status text NOT NULL DEFAULT 'not_verified' CHECK (dkim_status IN ('not_verified','verified')),
  dmarc_status text NOT NULL DEFAULT 'not_verified' CHECK (dmarc_status IN ('not_verified','verified')),
  approved_sending_domains text[] NOT NULL DEFAULT '{}',
  send_capability_implemented boolean NOT NULL DEFAULT false CHECK (send_capability_implemented = false),
  updated_by uuid, updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.platform_sender_config TO authenticated;
GRANT ALL ON public.platform_sender_config TO service_role;
ALTER TABLE public.platform_sender_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY sender_owner_all ON public.platform_sender_config FOR ALL TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
CREATE POLICY sender_auditor_read ON public.platform_sender_config FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'auditor'));
CREATE TRIGGER sender_audit AFTER INSERT OR UPDATE ON public.platform_sender_config FOR EACH ROW EXECUTE FUNCTION public.audit_platform_row();

CREATE TABLE public.platform_recipient_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text, domain text, reason text NOT NULL, created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (email IS NOT NULL OR domain IS NOT NULL)
);
GRANT SELECT, INSERT ON public.platform_recipient_blocks TO authenticated;
GRANT ALL ON public.platform_recipient_blocks TO service_role;
ALTER TABLE public.platform_recipient_blocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY blocks_owner_select ON public.platform_recipient_blocks FOR SELECT TO authenticated USING (public.is_platform_admin());
CREATE POLICY blocks_owner_insert ON public.platform_recipient_blocks FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());

CREATE TABLE public.outbound_preflight_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.platform_prospects(id),
  sequence_id uuid REFERENCES public.platform_outreach_sequences(id),
  step_id uuid REFERENCES public.platform_outreach_steps(id),
  result text NOT NULL CHECK (result IN ('BLOCKED','PREFLIGHT_PASSED_SEND_NOT_IMPLEMENTED')),
  failed_checks text[] NOT NULL DEFAULT '{}',
  checks jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid, created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.outbound_preflight_results TO authenticated;
GRANT ALL ON public.outbound_preflight_results TO service_role;
ALTER TABLE public.outbound_preflight_results ENABLE ROW LEVEL SECURITY;
CREATE POLICY preflight_owner_select ON public.outbound_preflight_results FOR SELECT TO authenticated USING (public.is_platform_admin() OR public.has_role(auth.uid(),'auditor'));
CREATE POLICY preflight_owner_insert ON public.outbound_preflight_results FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());
CREATE TRIGGER preflight_immutable BEFORE UPDATE OR DELETE ON public.outbound_preflight_results FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

ALTER TABLE public.platform_prospects
  ADD COLUMN team_size text, ADD COLUMN current_tools text, ADD COLUMN bottleneck text,
  ADD COLUMN operational_pain text,
  ADD COLUMN decision_maker_status text NOT NULL DEFAULT 'unknown' CHECK (decision_maker_status IN ('unknown','confirmed','not_decision_maker')),
  ADD COLUMN admin_burden_note text,
  ADD COLUMN discovery_status text NOT NULL DEFAULT 'not_started' CHECK (discovery_status IN ('not_started','scheduled','in_progress','complete'));

CREATE TABLE public.prospect_qualifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.platform_prospects(id),
  rule_version text NOT NULL, score integer NOT NULL,
  positive jsonb NOT NULL DEFAULT '[]'::jsonb, negative jsonb NOT NULL DEFAULT '[]'::jsonb,
  unknowns text[] NOT NULL DEFAULT '{}', created_by uuid, created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.prospect_qualifications TO authenticated;
GRANT ALL ON public.prospect_qualifications TO service_role;
ALTER TABLE public.prospect_qualifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY qual_owner_select ON public.prospect_qualifications FOR SELECT TO authenticated USING (public.is_platform_admin() OR public.has_role(auth.uid(),'auditor'));
CREATE POLICY qual_owner_insert ON public.prospect_qualifications FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());
CREATE TRIGGER qual_immutable BEFORE UPDATE OR DELETE ON public.prospect_qualifications FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

CREATE TABLE public.prospect_discovery_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.platform_prospects(id),
  question_key text NOT NULL, answer text, evidence_ref text, answered_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (prospect_id, question_key)
);
GRANT SELECT, INSERT, UPDATE ON public.prospect_discovery_answers TO authenticated;
GRANT ALL ON public.prospect_discovery_answers TO service_role;
ALTER TABLE public.prospect_discovery_answers ENABLE ROW LEVEL SECURITY;
CREATE POLICY disc_owner_all ON public.prospect_discovery_answers FOR ALL TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
CREATE POLICY disc_auditor_read ON public.prospect_discovery_answers FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'auditor'));

CREATE TABLE public.proposal_drafts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  root_id uuid, version integer NOT NULL DEFAULT 1,
  prospect_id uuid REFERENCES public.platform_prospects(id),
  intake_submission_id uuid REFERENCES public.intake_submissions(id),
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','review_ready','superseded','withdrawn')),
  client_name text NOT NULL, scope text[] NOT NULL DEFAULT '{}',
  pain_points text, implementation_steps text, exclusions text, authority_boundaries text, assumptions text, dependencies text,
  setup_fee_cents bigint CHECK (setup_fee_cents IS NULL OR setup_fee_cents >= 0),
  monthly_fee_cents bigint CHECK (monthly_fee_cents IS NULL OR monthly_fee_cents >= 0),
  term_text text,
  outcome text NOT NULL DEFAULT 'open' CHECK (outcome IN ('open','won','lost')),
  outcome_evidence text,
  owner_win_probability_pct integer CHECK (owner_win_probability_pct IS NULL OR owner_win_probability_pct BETWEEN 0 AND 100),
  created_by uuid, created_at timestamptz NOT NULL DEFAULT now(), review_ready_at timestamptz,
  CHECK (outcome <> 'won' OR (outcome_evidence IS NOT NULL AND length(trim(outcome_evidence)) > 0)),
  UNIQUE (root_id, version)
);
GRANT SELECT, INSERT, UPDATE ON public.proposal_drafts TO authenticated;
GRANT ALL ON public.proposal_drafts TO service_role;
ALTER TABLE public.proposal_drafts ENABLE ROW LEVEL SECURITY;
CREATE POLICY prop_owner_select ON public.proposal_drafts FOR SELECT TO authenticated USING (public.is_platform_admin() OR public.has_role(auth.uid(),'auditor'));
CREATE POLICY prop_owner_insert ON public.proposal_drafts FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());
CREATE POLICY prop_owner_update ON public.proposal_drafts FOR UPDATE TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());

CREATE OR REPLACE FUNCTION public.proposal_version_guard() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'proposal drafts cannot be deleted'; END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW.root_id IS NULL THEN NEW.root_id := NEW.id; END IF;
    IF NEW.status <> 'draft' THEN RAISE EXCEPTION 'new proposal versions start as draft'; END IF;
    IF NEW.outcome <> 'open' THEN RAISE EXCEPTION 'new proposal versions start open'; END IF;
    RETURN NEW;
  END IF;
  IF OLD.status <> 'draft' AND (
     NEW.client_name IS DISTINCT FROM OLD.client_name OR NEW.scope IS DISTINCT FROM OLD.scope OR
     NEW.pain_points IS DISTINCT FROM OLD.pain_points OR NEW.implementation_steps IS DISTINCT FROM OLD.implementation_steps OR
     NEW.exclusions IS DISTINCT FROM OLD.exclusions OR NEW.authority_boundaries IS DISTINCT FROM OLD.authority_boundaries OR
     NEW.assumptions IS DISTINCT FROM OLD.assumptions OR NEW.dependencies IS DISTINCT FROM OLD.dependencies OR
     NEW.setup_fee_cents IS DISTINCT FROM OLD.setup_fee_cents OR NEW.monthly_fee_cents IS DISTINCT FROM OLD.monthly_fee_cents OR
     NEW.term_text IS DISTINCT FROM OLD.term_text OR NEW.version IS DISTINCT FROM OLD.version OR NEW.root_id IS DISTINCT FROM OLD.root_id OR
     NEW.prospect_id IS DISTINCT FROM OLD.prospect_id) THEN
    RAISE EXCEPTION 'proposal version % is locked after approval-for-review; create a new version', OLD.version;
  END IF;
  IF OLD.status IN ('superseded','withdrawn') AND NEW.status <> OLD.status THEN RAISE EXCEPTION 'terminal proposal status'; END IF;
  IF NEW.outcome <> OLD.outcome AND NEW.status = 'draft' THEN RAISE EXCEPTION 'mark review_ready before recording won/lost'; END IF;
  IF NEW.status = 'review_ready' AND OLD.status = 'draft' THEN NEW.review_ready_at := now(); END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER proposal_guard BEFORE INSERT OR UPDATE OR DELETE ON public.proposal_drafts FOR EACH ROW EXECUTE FUNCTION public.proposal_version_guard();
CREATE TRIGGER proposal_audit AFTER INSERT OR UPDATE ON public.proposal_drafts FOR EACH ROW EXECUTE FUNCTION public.audit_platform_row();

CREATE TABLE public.invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  tenant_id uuid REFERENCES public.tenants(id),
  intended_role public.app_role NOT NULL CHECK (intended_role <> 'owner_admin'),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','cancelled','activated')),
  created_by uuid NOT NULL, expires_at timestamptz NOT NULL,
  activated_user_id uuid, activated_by uuid, activated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((intended_role = 'auditor' AND tenant_id IS NULL) OR (intended_role IN ('client_admin','client_member') AND tenant_id IS NOT NULL))
);
GRANT SELECT ON public.invitations TO authenticated;
GRANT ALL ON public.invitations TO service_role;
ALTER TABLE public.invitations ENABLE ROW LEVEL SECURITY;
CREATE POLICY inv_select ON public.invitations FOR SELECT TO authenticated USING (
  public.is_platform_admin() OR public.has_role(auth.uid(),'auditor')
  OR (tenant_id IS NOT NULL AND EXISTS (SELECT 1 FROM public.memberships m WHERE m.tenant_id = invitations.tenant_id AND m.user_id = auth.uid() AND m.role = 'client_admin')));

CREATE OR REPLACE FUNCTION public.can_manage_invite(p_tenant uuid, p_role public.app_role) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE
    WHEN p_role = 'owner_admin' THEN false
    WHEN public.is_platform_admin() THEN true
    WHEN p_role IN ('client_admin','client_member') AND p_tenant IS NOT NULL THEN EXISTS (
      SELECT 1 FROM public.memberships WHERE tenant_id = p_tenant AND user_id = auth.uid() AND role = 'client_admin')
    ELSE false END;
$$;

CREATE OR REPLACE FUNCTION public.create_invitation(p_email text, p_tenant uuid, p_role public.app_role, p_days integer DEFAULT 7) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_id uuid; v_email text := lower(trim(p_email));
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF v_email !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' THEN RAISE EXCEPTION 'invalid email'; END IF;
  IF p_days < 1 OR p_days > 30 THEN RAISE EXCEPTION 'expiry must be 1-30 days'; END IF;
  IF NOT public.can_manage_invite(p_tenant, p_role) THEN RAISE EXCEPTION 'forbidden: cannot grant % for this tenant', p_role; END IF;
  INSERT INTO public.invitations (email, tenant_id, intended_role, created_by, expires_at)
  VALUES (v_email, p_tenant, p_role, auth.uid(), now() + make_interval(days => p_days)) RETURNING id INTO v_id;
  INSERT INTO public.platform_audit_events (actor_user_id, action, entity, entity_id, inputs, outcome, side_effect)
  VALUES (auth.uid(), 'invitation_created', 'invitations', v_id, jsonb_build_object('email', v_email, 'tenant_id', p_tenant, 'role', p_role), 'pending — no email sent', 'none');
  RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION public.cancel_invitation(p_id uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v public.invitations;
BEGIN
  SELECT * INTO v FROM public.invitations WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'invitation not found'; END IF;
  IF NOT public.can_manage_invite(v.tenant_id, v.intended_role) THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF v.status <> 'pending' THEN RAISE EXCEPTION 'only pending invitations can be cancelled'; END IF;
  UPDATE public.invitations SET status = 'cancelled' WHERE id = p_id;
  INSERT INTO public.platform_audit_events (actor_user_id, action, entity, entity_id, inputs, outcome, side_effect)
  VALUES (auth.uid(), 'invitation_cancelled', 'invitations', p_id, '{}'::jsonb, 'cancelled', 'none');
END $$;

CREATE OR REPLACE FUNCTION public.activate_invitation(p_id uuid) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v public.invitations; v_user uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v FROM public.invitations WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'invitation not found'; END IF;
  IF NOT public.can_manage_invite(v.tenant_id, v.intended_role) THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF v.status <> 'pending' THEN RAISE EXCEPTION 'invitation is %', v.status; END IF;
  IF v.expires_at <= now() THEN RAISE EXCEPTION 'invitation expired'; END IF;
  SELECT id INTO v_user FROM auth.users WHERE lower(email) = v.email LIMIT 1;
  IF v_user IS NULL THEN RAISE EXCEPTION 'no authenticated user with the invited email exists yet'; END IF;
  IF v_user = auth.uid() AND NOT public.is_platform_admin() THEN RAISE EXCEPTION 'self-activation is not allowed'; END IF;
  IF v.intended_role = 'auditor' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (v_user, 'auditor') ON CONFLICT DO NOTHING;
  ELSE
    IF EXISTS (SELECT 1 FROM public.memberships WHERE tenant_id = v.tenant_id AND user_id = v_user) THEN
      RAISE EXCEPTION 'user already has a membership in this tenant';
    END IF;
    INSERT INTO public.memberships (tenant_id, user_id, role) VALUES (v.tenant_id, v_user, v.intended_role);
  END IF;
  UPDATE public.invitations SET status = 'activated', activated_user_id = v_user, activated_by = auth.uid(), activated_at = now() WHERE id = p_id;
  INSERT INTO public.platform_audit_events (actor_user_id, action, entity, entity_id, inputs, outcome, side_effect)
  VALUES (auth.uid(), 'invitation_activated', 'invitations', p_id, jsonb_build_object('user_id', v_user, 'tenant_id', v.tenant_id, 'role', v.intended_role), 'membership granted', 'none — internal access record');
  IF v.tenant_id IS NOT NULL THEN
    INSERT INTO public.audit_events (tenant_id, actor, actor_type, actor_user_id, action, inputs, decision, policy_rule, intended_side_effect, outcome, mode)
    VALUES (v.tenant_id, 'Access Management', 'human', auth.uid(), 'membership_granted_via_invitation', jsonb_build_object('invitation_id', p_id, 'user_id', v_user, 'role', v.intended_role), 'allow', 'invitation_activation', 'none', 'membership created', 'shadow');
  END IF;
  RETURN v_user;
END $$;
REVOKE ALL ON FUNCTION public.create_invitation(text, uuid, public.app_role, integer) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.cancel_invitation(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.activate_invitation(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_invitation(text, uuid, public.app_role, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_invitation(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.activate_invitation(uuid) TO authenticated;

CREATE TABLE public.subprocessors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL UNIQUE, purpose text NOT NULL,
  data_categories text[] NOT NULL DEFAULT '{}',
  handles_tenant_data boolean NOT NULL DEFAULT false,
  credential_type text, region_notes text,
  dpa_status text NOT NULL DEFAULT 'pending' CHECK (dpa_status IN ('pending','in_review','signed','not_required')),
  security_review_status text NOT NULL DEFAULT 'pending' CHECK (security_review_status IN ('pending','in_review','complete')),
  approved_for_pilot boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT false,
  evidence_ref text, notes text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT approved_for_pilot OR (security_review_status = 'complete' AND dpa_status IN ('signed','not_required') AND evidence_ref IS NOT NULL))
);
GRANT SELECT, INSERT, UPDATE ON public.subprocessors TO authenticated;
GRANT ALL ON public.subprocessors TO service_role;
ALTER TABLE public.subprocessors ENABLE ROW LEVEL SECURITY;
CREATE POLICY sub_owner_all ON public.subprocessors FOR ALL TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
CREATE POLICY sub_auditor_read ON public.subprocessors FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'auditor'));
CREATE TRIGGER sub_audit AFTER INSERT OR UPDATE ON public.subprocessors FOR EACH ROW EXECUTE FUNCTION public.audit_platform_row();

CREATE TABLE public.data_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_name text NOT NULL UNIQUE, data_category text NOT NULL,
  contains_personal_data boolean NOT NULL DEFAULT false,
  tenant_scoped boolean NOT NULL DEFAULT true,
  retention_category text NOT NULL,
  subprocessors text[] NOT NULL DEFAULT '{}', notes text
);
GRANT SELECT, INSERT, UPDATE ON public.data_inventory TO authenticated;
GRANT ALL ON public.data_inventory TO service_role;
ALTER TABLE public.data_inventory ENABLE ROW LEVEL SECURITY;
CREATE POLICY dinv_owner_all ON public.data_inventory FOR ALL TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
CREATE POLICY dinv_auditor_read ON public.data_inventory FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'auditor'));

CREATE TABLE public.commercial_evidence (
  gate_key text PRIMARY KEY,
  status text NOT NULL DEFAULT 'incomplete' CHECK (status IN ('incomplete','complete')),
  evidence_ref text, recorded_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (status = 'incomplete' OR (evidence_ref IS NOT NULL AND length(trim(evidence_ref)) > 0))
);
GRANT SELECT, INSERT, UPDATE ON public.commercial_evidence TO authenticated;
GRANT ALL ON public.commercial_evidence TO service_role;
ALTER TABLE public.commercial_evidence ENABLE ROW LEVEL SECURITY;
CREATE POLICY ce_owner_all ON public.commercial_evidence FOR ALL TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
CREATE POLICY ce_auditor_read ON public.commercial_evidence FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'auditor'));
CREATE TRIGGER ce_audit AFTER INSERT OR UPDATE ON public.commercial_evidence FOR EACH ROW EXECUTE FUNCTION public.audit_platform_row();