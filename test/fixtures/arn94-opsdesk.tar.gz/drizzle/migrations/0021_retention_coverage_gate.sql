-- Make retention-policy coverage explicit and fail closed.
-- Every retention category used by the data inventory must have a global policy row.

CREATE OR REPLACE FUNCTION public.data_retention_coverage_status()
RETURNS TABLE (
  inventory_categories text[],
  policy_categories text[],
  missing_policy_categories text[],
  unapproved_policy_categories text[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL
     OR NOT (public.is_platform_admin() OR public.has_role(auth.uid(), 'auditor')) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  RETURN QUERY
  WITH inv AS (
    SELECT DISTINCT d.retention_category AS category
    FROM public.data_inventory d
  ),
  pol AS (
    SELECT rp.category, rp.status
    FROM public.retention_policies rp
    WHERE rp.tenant_id IS NULL
  ),
  missing AS (
    SELECT i.category
    FROM inv i
    LEFT JOIN pol p ON p.category = i.category
    WHERE p.category IS NULL
  ),
  unapproved AS (
    SELECT DISTINCT i.category
    FROM inv i
    JOIN pol p ON p.category = i.category
    WHERE p.status <> 'approved'
  )
  SELECT
    COALESCE((SELECT array_agg(i.category ORDER BY i.category) FROM inv i), ARRAY[]::text[]),
    COALESCE((SELECT array_agg(p.category ORDER BY p.category) FROM pol p), ARRAY[]::text[]),
    COALESCE((SELECT array_agg(m.category ORDER BY m.category) FROM missing m), ARRAY[]::text[]),
    COALESCE((SELECT array_agg(u.category ORDER BY u.category) FROM unapproved u), ARRAY[]::text[]);
END
$$;

REVOKE ALL ON FUNCTION public.data_retention_coverage_status() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.data_retention_coverage_status() TO authenticated;

COMMENT ON FUNCTION public.data_retention_coverage_status() IS
  'Owner/auditor-only retention-policy coverage check. Missing or unapproved categories block commercial readiness.';
