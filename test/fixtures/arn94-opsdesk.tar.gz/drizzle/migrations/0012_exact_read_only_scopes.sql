-- Fail closed on Stage 3 provider scopes.
-- Only explicitly reviewed read-only scopes qualify; regex lookalikes do not.

CREATE OR REPLACE FUNCTION public.is_arnexyia_read_only_scope(scope text)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT lower(trim(scope)) = ANY (ARRAY[
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/calendar.readonly',
    'https://www.googleapis.com/auth/drive.readonly',
    'contacts:read',
    'deals:read'
  ]::text[]);
$$;

CREATE OR REPLACE FUNCTION public.real_data_source_guard()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM unnest(NEW.requested_scopes) s
    WHERE NOT public.is_arnexyia_read_only_scope(s)
  ) THEN
    NEW.write_scope_enabled := true;
  ELSE
    NEW.write_scope_enabled := false;
  END IF;

  IF NEW.connection_status = 'connected' AND NEW.connection_verified_by IS NULL THEN
    RAISE EXCEPTION 'connected requires a verified Arnexyia-side connection';
  END IF;

  NEW.updated_at := now();
  RETURN NEW;
END $$;

UPDATE public.real_data_sources
SET write_scope_enabled = EXISTS (
  SELECT 1
  FROM unnest(requested_scopes) s
  WHERE NOT public.is_arnexyia_read_only_scope(s)
);
