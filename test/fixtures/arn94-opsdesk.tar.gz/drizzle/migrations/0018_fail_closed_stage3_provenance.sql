-- Fail-closed provenance for tenants and real-data authorization.
-- Existing known fixture tenants are classified explicitly; unknown legacy rows stay unclassified.

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS tenant_kind text NOT NULL DEFAULT 'unclassified';

UPDATE public.tenants
SET tenant_kind = 'synthetic_seed'
WHERE slug IN ('apex-mechanical','northline-electrical','cedar-ridge-plumbing')
  AND tenant_kind = 'unclassified';

-- Unknown legacy tenants fail closed. Never infer that an existing row is a customer.
UPDATE public.tenants
SET mode = 'shadow'
WHERE tenant_kind <> 'customer'
  AND mode <> 'shadow';

ALTER TABLE public.tenants
  DROP CONSTRAINT IF EXISTS tenants_tenant_kind_check;
ALTER TABLE public.tenants
  ADD CONSTRAINT tenants_tenant_kind_check
  CHECK (tenant_kind IN ('unclassified','synthetic_seed','internal_test','customer'));

ALTER TABLE public.tenants
  DROP CONSTRAINT IF EXISTS tenants_noncustomer_shadow_only;
ALTER TABLE public.tenants
  ADD CONSTRAINT tenants_noncustomer_shadow_only
  CHECK (tenant_kind = 'customer' OR mode = 'shadow');

ALTER TABLE public.real_data_sources
  ADD COLUMN IF NOT EXISTS authorization_basis text NOT NULL DEFAULT 'unclassified';

ALTER TABLE public.real_data_sources
  DROP CONSTRAINT IF EXISTS real_data_sources_authorization_basis_check;
ALTER TABLE public.real_data_sources
  ADD CONSTRAINT real_data_sources_authorization_basis_check
  CHECK (authorization_basis IN ('unclassified','synthetic_fixture','owner_internal_test','client_authorization'));

-- Do not guess provenance for approved legacy rows. Preserve connection/test evidence,
-- but revoke approval until an explicit authorization basis is recorded.
UPDATE public.real_data_sources
SET approved = false,
    notes = concat_ws(E'\n', nullif(notes, ''), 'Migration 0018: prior approval disabled because authorization provenance was unclassified; explicit re-authorization is required.')
WHERE approved = true
  AND authorization_basis = 'unclassified';

ALTER TABLE public.real_data_sources
  DROP CONSTRAINT IF EXISTS rds_approved_basis_check;
ALTER TABLE public.real_data_sources
  ADD CONSTRAINT rds_approved_basis_check
  CHECK (NOT approved OR authorization_basis IN ('owner_internal_test','client_authorization'));

COMMENT ON COLUMN public.tenants.tenant_kind IS
  'unclassified fails closed; synthetic_seed is fixture-only; internal_test is Arnexyia-owned technical validation; customer is a real client tenant.';
COMMENT ON COLUMN public.real_data_sources.authorization_basis IS
  'Provenance only. owner_internal_test may support controlled Stage 3 technical validation; client_authorization is required for commercial/client readiness.';

CREATE OR REPLACE FUNCTION public.real_data_source_guard()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $function$
DECLARE v_kind text;
BEGIN
  SELECT tenant_kind INTO v_kind FROM public.tenants WHERE id = NEW.tenant_id;
  IF v_kind IS NULL THEN RAISE EXCEPTION 'real-data source tenant missing'; END IF;

  IF NEW.authorization_basis = 'owner_internal_test' THEN
    IF v_kind <> 'internal_test' THEN
      RAISE EXCEPTION 'owner_internal_test authorization requires an internal_test tenant';
    END IF;
    IF NEW.provider <> 'gmail' THEN
      RAISE EXCEPTION 'owner_internal_test authorization is currently Gmail-only';
    END IF;
  END IF;

  IF NEW.authorization_basis = 'client_authorization' AND v_kind <> 'customer' THEN
    RAISE EXCEPTION 'client_authorization requires a customer tenant';
  END IF;

  IF NEW.approved AND NEW.authorization_basis NOT IN ('owner_internal_test','client_authorization') THEN
    RAISE EXCEPTION 'approved real-data source requires explicit authorization provenance';
  END IF;

  IF EXISTS (
    SELECT 1 FROM unnest(NEW.requested_scopes) s
    WHERE NOT public.is_arnexyia_read_only_scope(s)
  ) THEN
    NEW.write_scope_enabled := true;
  ELSE
    NEW.write_scope_enabled := false;
  END IF;

  IF NEW.connection_status = 'connected' AND NEW.connection_verified_by IS NULL THEN
    RAISE EXCEPTION 'connected requires a verified Arnexyia-side connection';
  END IF;

  NEW.updated_at := now();
  RETURN NEW;
END
$function$;

-- Existing non-customer policy rows also fail closed before the write guard is installed.
UPDATE public.authority_policies ap
SET live_enabled = false
FROM public.tenants t
WHERE ap.tenant_id = t.id
  AND t.tenant_kind <> 'customer'
  AND ap.live_enabled = true;

CREATE OR REPLACE FUNCTION public.authority_policy_tenant_kind_guard()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $function$
DECLARE v_kind text;
BEGIN
  SELECT tenant_kind INTO v_kind FROM public.tenants WHERE id = NEW.tenant_id;
  IF NEW.live_enabled AND v_kind <> 'customer' THEN
    RAISE EXCEPTION 'live authority is restricted to customer tenants';
  END IF;
  RETURN NEW;
END
$function$;

DROP TRIGGER IF EXISTS authority_policy_tenant_kind_guard ON public.authority_policies;
CREATE TRIGGER authority_policy_tenant_kind_guard
BEFORE INSERT OR UPDATE ON public.authority_policies
FOR EACH ROW EXECUTE FUNCTION public.authority_policy_tenant_kind_guard();

REVOKE EXECUTE ON FUNCTION public.authority_policy_tenant_kind_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.authority_policy_tenant_kind_guard() TO authenticated, service_role;

-- Normal owner provisioning remains customer-only.
CREATE OR REPLACE FUNCTION public.provision_tenant(p_name text, p_slug text, p_industry text, p_timezone text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE new_id uuid; tpl uuid;
BEGIN
  IF NOT public.is_platform_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF p_slug !~ '^[a-z0-9][a-z0-9-]{2,48}$' THEN RAISE EXCEPTION 'invalid slug'; END IF;
  IF length(trim(coalesce(p_name,''))) < 2 THEN RAISE EXCEPTION 'invalid name'; END IF;
  SELECT id INTO tpl FROM public.tenants WHERE tenant_kind = 'synthetic_seed' ORDER BY created_at LIMIT 1;
  IF tpl IS NULL THEN RAISE EXCEPTION 'provisioning template missing'; END IF;

  INSERT INTO public.tenants(name, slug, industry, status, health, mode, timezone, tenant_kind)
  VALUES (trim(p_name), p_slug, p_industry, 'onboarding', 'unknown', 'shadow',
          coalesce(nullif(p_timezone,''),'America/New_York'), 'customer')
  RETURNING id INTO new_id;

  INSERT INTO public.authority_policies(tenant_id, capability, risk, live_enabled, requires_secondary_validation,
    amount_threshold_cents, permitted_domains, permitted_recipients, rate_limit_per_hour, min_confidence, notes)
  SELECT new_id, capability, risk, false, requires_secondary_validation, amount_threshold_cents,
    '{}'::text[], '{}'::text[], rate_limit_per_hour, min_confidence, 'Default matrix; domains must be set per client.'
  FROM public.authority_policies WHERE tenant_id = tpl;

  INSERT INTO public.integrations(tenant_id, provider, category, status, circuit_open, failure_count, required_credentials, setup_notes)
  SELECT new_id, provider, category, 'not_configured', false, 0, required_credentials, setup_notes
  FROM public.integrations WHERE tenant_id = tpl;

  INSERT INTO public.channel_capabilities(tenant_id, channel, research_enabled, draft_enabled, asset_ready, api_connected, publish_enabled, setup_notes)
  SELECT new_id, channel, research_enabled, draft_enabled, false, false, false, 'Not connected.'
  FROM public.channel_capabilities WHERE tenant_id = tpl;

  INSERT INTO public.setup_checklist(tenant_id, item_key, label, category, required_for, status, owner_action_required, notes)
  SELECT DISTINCT ON (item_key) new_id, item_key, label, category, required_for, 'pending', owner_action_required, notes
  FROM public.setup_checklist WHERE tenant_id = tpl ORDER BY item_key;

  INSERT INTO public.billing_accounts(tenant_id, plan, mrr_cents, status, is_placeholder)
  VALUES (new_id, 'unassigned', 0, 'placeholder', true);

  INSERT INTO public.memberships(tenant_id, user_id, role) VALUES (new_id, auth.uid(), 'owner_admin');

  INSERT INTO public.audit_events(tenant_id, actor, actor_type, actor_user_id, action, inputs, decision, policy_rule,
    intended_side_effect, outcome, mode, correlation_key)
  VALUES (new_id, 'Platform Owner', 'human', auth.uid(), 'provision_tenant',
    jsonb_build_object('name', p_name, 'slug', p_slug, 'tenant_kind', 'customer'), 'allow', 'owner_provisioning',
    'none — internal records only; no external accounts or credentials', 'customer tenant provisioned in shadow mode', 'shadow', 'provision-' || new_id);
  RETURN new_id;
END $$;

-- Create exactly one dedicated internal Stage 3 tenant, never through the customer provisioner.
DO $$
DECLARE v_id uuid; tpl uuid;
BEGIN
  SELECT id INTO v_id FROM public.tenants WHERE slug = 'arnexyia-internal-test';
  IF v_id IS NULL THEN
    SELECT id INTO tpl FROM public.tenants WHERE tenant_kind = 'synthetic_seed' ORDER BY created_at LIMIT 1;
    IF tpl IS NULL THEN RAISE EXCEPTION 'internal test template missing'; END IF;

    INSERT INTO public.tenants(name, slug, industry, status, health, mode, timezone, tenant_kind)
    VALUES ('Arnexyia Internal Test','arnexyia-internal-test','internal','shadow_testing','unknown','shadow','America/New_York','internal_test')
    RETURNING id INTO v_id;

    INSERT INTO public.authority_policies(tenant_id, capability, risk, live_enabled, requires_secondary_validation,
      amount_threshold_cents, permitted_domains, permitted_recipients, rate_limit_per_hour, min_confidence, notes)
    SELECT v_id, capability, risk, false, requires_secondary_validation, amount_threshold_cents,
      '{}'::text[], '{}'::text[], rate_limit_per_hour, min_confidence, 'Internal Stage 3 test only; never customer authority.'
    FROM public.authority_policies WHERE tenant_id = tpl;
  END IF;

  INSERT INTO public.real_data_sources(
    tenant_id, provider, optional, required_scopes, requested_scopes,
    authorization_basis, approved, connection_status, connection_test_status,
    write_scope_enabled, notes
  )
  VALUES (
    v_id, 'gmail', false,
    ARRAY['https://www.googleapis.com/auth/gmail.readonly'],
    ARRAY['https://www.googleapis.com/auth/gmail.readonly'],
    'unclassified', false, 'not_connected', 'not_tested', false,
    'Dedicated Arnexyia-controlled Stage 3 Gmail source. Must be explicitly recorded as owner_internal_test before approval.'
  )
  ON CONFLICT (tenant_id, provider) DO NOTHING;
END $$;
