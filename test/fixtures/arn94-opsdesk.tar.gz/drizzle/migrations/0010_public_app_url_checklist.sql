INSERT INTO public.setup_checklist (tenant_id, item_key, label, category, required_for, status, owner_action_required, notes)
SELECT NULL, 'public_app_url', 'Production auth callback domain (PUBLIC_APP_URL) configured', 'auth', 'first_customer', 'pending', true,
 'Set VITE_PUBLIC_APP_URL to the real production domain and add it to allowed auth redirects. No domain chosen yet; preview URLs must not be used for customer email verification or OAuth.'
WHERE NOT EXISTS (SELECT 1 FROM public.setup_checklist WHERE item_key = 'public_app_url' AND tenant_id IS NULL);