CREATE OR REPLACE FUNCTION public.audit_retention_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.tenant_id IS NOT NULL THEN
    INSERT INTO public.audit_events(tenant_id, actor, actor_type, actor_user_id, action, inputs, decision, policy_rule, intended_side_effect, outcome, mode)
    VALUES (NEW.tenant_id, coalesce((SELECT email FROM public.profiles WHERE id = auth.uid()), 'system'), CASE WHEN auth.uid() IS NULL THEN 'system' ELSE 'human' END,
      auth.uid(), 'retention_policies_' || lower(TG_OP), to_jsonb(NEW), 'allow', 'internal_record_change', 'none — no data deleted', 'recorded', 'shadow');
  ELSE
    INSERT INTO public.platform_audit_events(actor_user_id, action, entity, entity_id, inputs, outcome)
    VALUES (auth.uid(), 'retention_policies_' || lower(TG_OP), 'retention_policies', NEW.id, to_jsonb(NEW), 'recorded');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER retention_policies_audit AFTER INSERT OR UPDATE ON public.retention_policies FOR EACH ROW EXECUTE FUNCTION public.audit_retention_change();