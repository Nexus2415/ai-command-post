-- Make the global kill-switch transition and audit evidence atomic.
-- Releasing or engaging cannot succeed without the authoritative flag row and
-- the matching per-tenant audit evidence being written in the same transaction.

CREATE OR REPLACE FUNCTION public.set_global_kill_switch(p_engaged boolean)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_updated text;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_platform_admin() THEN
    RAISE EXCEPTION 'forbidden: platform owner only';
  END IF;

  UPDATE public.system_flags
  SET bool_value = p_engaged,
      updated_at = now(),
      updated_by = auth.uid()
  WHERE key = 'global_kill_switch'
  RETURNING key INTO v_updated;

  IF v_updated IS NULL THEN
    RAISE EXCEPTION 'global_kill_switch flag row missing';
  END IF;

  INSERT INTO public.audit_events (
    tenant_id,
    actor,
    actor_type,
    actor_user_id,
    action,
    inputs,
    decision,
    policy_rule,
    intended_side_effect,
    outcome,
    mode,
    correlation_key
  )
  SELECT
    t.id,
    'Platform Owner',
    'human',
    auth.uid(),
    CASE WHEN p_engaged THEN 'engage_global_kill_switch' ELSE 'release_global_kill_switch' END,
    jsonb_build_object('engaged', p_engaged),
    'allow',
    'platform_owner_override',
    CASE
      WHEN p_engaged THEN 'halt all autonomous execution'
      ELSE 'resume autonomous evaluation'
    END,
    CASE
      WHEN p_engaged THEN 'kill switch engaged'
      ELSE 'kill switch released'
    END,
    'shadow'::public.exec_mode,
    'killswitch-' || gen_random_uuid()::text
  FROM public.tenants t;

  RETURN p_engaged;
END
$$;

REVOKE ALL ON FUNCTION public.set_global_kill_switch(boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_global_kill_switch(boolean) TO authenticated;

COMMENT ON FUNCTION public.set_global_kill_switch(boolean) IS
  'Owner-only atomic kill-switch transition. Updates the authoritative flag and writes per-tenant audit evidence in one transaction.';
