DROP POLICY IF EXISTS system_flags_select ON public.system_flags;
CREATE POLICY system_flags_select ON public.system_flags
FOR SELECT TO authenticated
USING (
  EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM public.memberships m WHERE m.user_id = auth.uid())
);