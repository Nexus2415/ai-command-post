-- Harden shadow_readiness view against anonymous/RLS-bypass reads.
-- Default PostgreSQL view execution can use the view owner's privileges.
-- Force invoker semantics and remove unauthenticated direct SELECT.

ALTER VIEW public.shadow_readiness SET (security_invoker = true);

REVOKE ALL ON TABLE public.shadow_readiness FROM PUBLIC, anon;
GRANT SELECT ON TABLE public.shadow_readiness TO authenticated, service_role;
