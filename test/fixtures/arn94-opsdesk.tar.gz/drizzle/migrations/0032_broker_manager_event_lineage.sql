-- ARN-98: SOURCE ONLY, requires reviewed ARN-97 migration 0031.
-- No network, live execution, flag change, JWT verifier creation or model spend.
-- This is the ONLY manager admission path that proves atomic event-to-broker lineage.
BEGIN;

-- Migration must not manufacture provenance for already admitted legacy work.
DO $guard$
BEGIN
  IF EXISTS (SELECT 1 FROM public.manager_event_receipts WHERE status='admitted')
     OR EXISTS (SELECT 1 FROM public.manager_claim_bindings)
     OR EXISTS (SELECT 1 FROM public.manager_verifications)
  THEN RAISE EXCEPTION 'ARN-98 refused: existing admissions need owner-led reconciliation';
  END IF;
END
$guard$;

CREATE TABLE public.broker_manager_event_lineage (
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  event_id text NOT NULL CHECK (length(event_id) BETWEEN 1 AND 200),
  idempotency_key text NOT NULL CHECK (length(idempotency_key) BETWEEN 1 AND 250),
  claim_id uuid NOT NULL REFERENCES public.execution_claims(id),
  attempt_id uuid NOT NULL REFERENCES public.execution_attempts(id),
  fence bigint NOT NULL CHECK (fence BETWEEN 1 AND 3),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id,event_id),
  CONSTRAINT broker_manager_lineage_claim_unique UNIQUE (claim_id),
  CONSTRAINT broker_manager_lineage_attempt_unique UNIQUE (attempt_id),
  CONSTRAINT broker_manager_lineage_key_unique UNIQUE (tenant_id,idempotency_key),
  FOREIGN KEY (tenant_id,event_id) REFERENCES public.manager_event_receipts (tenant_id,event_id)
);
ALTER TABLE public.broker_manager_event_lineage OWNER TO broker_owner;
ALTER TABLE public.broker_manager_event_lineage ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.broker_manager_event_lineage
 FROM PUBLIC,anon,authenticated,service_role,broker_caller,broker_intake,
 broker_gateway,manager_verifier;
CREATE TRIGGER broker_manager_lineage_immutable
 BEFORE UPDATE OR DELETE ON public.broker_manager_event_lineage
 FOR EACH ROW EXECUTE FUNCTION public.manager_int_forbid_audit_mutation();

-- Compare against wall time, never the transaction-start timestamp. The
-- original 0031 grant check uses now(), so it cannot detect a lock wait or a
-- long transaction that crosses a grant's expiry.
CREATE FUNCTION public.manager_int_wallclock_grant_fresh(expiry text) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  IF expiry IS NULL OR expiry::timestamptz <= clock_timestamp()
  THEN PERFORM public.manager_int_refuse('expired_grant_wallclock'); END IF;
EXCEPTION WHEN invalid_datetime_format OR datetime_field_overflow THEN
  PERFORM public.manager_int_refuse('invalid_expiration');
END;
$$;
CREATE FUNCTION public.manager_admission_wallclock_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status='pending' AND NEW.status IN ('admitted','staged') THEN
    PERFORM public.manager_int_wallclock_grant_fresh(OLD.expectation ->> 'permissionsExpireAt');
    -- If broker already reserved this event, staging it as owner-only would
    -- strand its paid/free reservation. Require normal claim reconciliation
    -- rather than silently switching the accepted manager event to staged.
    IF NEW.status='staged' AND EXISTS (
      SELECT 1 FROM public.broker_manager_event_lineage l
      WHERE l.tenant_id=OLD.tenant_id AND l.event_id=OLD.event_id
    ) THEN PERFORM public.manager_int_refuse('claim_reservation_prevents_staging'); END IF;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER manager_admission_wallclock
 BEFORE UPDATE OF status,job ON public.manager_event_receipts
 FOR EACH ROW EXECUTE FUNCTION public.manager_admission_wallclock_guard();

CREATE FUNCTION public.broker_claim_manager_event(
  p_tenant uuid, p_event text, p_command_key text, p_action_ref uuid,
  p_tariff_ref uuid, p_max_input integer, p_max_cached integer, p_max_output integer)
RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE rec public.manager_event_receipts; r jsonb;
        cl public.execution_claims; a public.execution_attempts;
        old public.broker_manager_event_lineage; v_claim uuid;
        v_attempt uuid; v_fence bigint;
BEGIN
  IF p_tenant IS NULL OR coalesce(length(p_event),0) NOT BETWEEN 1 AND 200
    OR p_command_key IS NULL OR p_action_ref IS NULL OR p_tariff_ref IS NULL
    OR public.broker_int_executor() <> 'acp'
    OR NOT public.broker_int_tenant_allowed(p_tenant)
  THEN PERFORM public.manager_int_refuse('unauthorized_manager_claim'); END IF;
  -- Record must already exist. The authenticated intake still owns the
  -- authorization provenance, not this wrapper or a client-supplied bool.
  -- Serialize with owner staging/admission for the entire broker reservation.
  -- Lock receipt before claim; manager_resolve_receipt uses the same order.
  SELECT * INTO rec FROM public.manager_event_receipts
    WHERE tenant_id=p_tenant AND event_id=p_event FOR UPDATE;
  IF NOT FOUND OR rec.status <> 'pending'
     OR rec.expectation ->> 'claimKey' IS DISTINCT FROM p_command_key
  THEN PERFORM public.manager_int_refuse('unrecorded_manager_event'); END IF;
  PERFORM public.manager_int_expectation(rec.expectation,p_tenant,rec.task_id);
  -- Native broker guardrails, budget, approvals and kill-switch still execute.
  -- If lineage insertion refuses, a SQL exception rolls back the entire
  -- claim reservation and budget side effects in this transaction.
  r := public.broker_claim_and_reserve(p_tenant,p_command_key,p_action_ref,
                                       p_tariff_ref,p_max_input,p_max_cached,p_max_output);
  IF jsonb_typeof(r) IS DISTINCT FROM 'object' OR r -> 'ok' IS DISTINCT FROM 'true'::jsonb
  THEN RETURN coalesce(r,jsonb_build_object('ok',false,'reason','broker_unavailable')); END IF;
  v_claim := (r ->> 'claim_id')::uuid;
  SELECT * INTO cl FROM public.execution_claims
    WHERE id=v_claim AND tenant_id=p_tenant AND command_key=p_command_key FOR UPDATE;
  IF NOT FOUND OR cl.state <> 'claimed'
  THEN PERFORM public.manager_int_refuse('unclaimable_manager_event'); END IF;
  IF r -> 'created' = 'true'::jsonb THEN
    v_attempt := (r ->> 'attempt_id')::uuid;
    v_fence := (r ->> 'fence')::bigint;
  ELSE
    -- An existing claim without a broker-authored lineage row is legacy.
    -- Do NOT retrofit a receipt-idempotency key from caller-controlled JSON.
    SELECT * INTO old FROM public.broker_manager_event_lineage
       WHERE claim_id=v_claim AND tenant_id=p_tenant AND event_id=p_event;
    IF NOT FOUND THEN PERFORM public.manager_int_refuse('legacy_or_foreign_claim'); END IF;
    v_attempt := old.attempt_id; v_fence := old.fence;
  END IF;
  SELECT * INTO a FROM public.execution_attempts
    WHERE id=v_attempt AND claim_id=cl.id AND executor='acp' FOR SHARE;
  IF NOT FOUND OR a.fence <> cl.fence OR a.fence <> v_fence
     OR a.state <> 'claimed' OR a.reserved_micros <> 0
  THEN PERFORM public.manager_int_refuse('attempt_mismatch'); END IF;
  -- After broker lock/reservation and before creating event authority, check
  -- real wall-clock time. Exception rolls back the broker side effect too.
  PERFORM public.manager_int_wallclock_grant_fresh(rec.expectation ->> 'permissionsExpireAt');
  IF r -> 'created' = 'true'::jsonb THEN
    INSERT INTO public.broker_manager_event_lineage
      (tenant_id,event_id,idempotency_key,claim_id,attempt_id,fence)
    VALUES (p_tenant,p_event,p_tenant::text || ':' || p_event,v_claim,v_attempt,v_fence);
  END IF;
  RETURN jsonb_build_object(
    'ok',true,'created',r -> 'created','claim_id',v_claim,'attempt_id',v_attempt,
    'fence',v_fence,'reserved_micros',0,
    'idempotency_key',p_tenant::text || ':' || p_event);
END;
$$;

-- Calls to the older broker reservation RPC remain valid for other callers,
-- but never qualify as an authenticated *manager* admission without lineage.
CREATE FUNCTION public.broker_manager_lineage_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE rec public.manager_event_receipts; l public.broker_manager_event_lineage;
BEGIN
  SELECT * INTO rec FROM public.manager_event_receipts
    WHERE tenant_id=NEW.tenant_id AND event_id=NEW.event_id;
  SELECT * INTO l FROM public.broker_manager_event_lineage
    WHERE tenant_id=NEW.tenant_id AND event_id=NEW.event_id
      AND claim_id=NEW.claim_id AND attempt_id=NEW.attempt_id
      AND idempotency_key=NEW.tenant_id::text || ':' || NEW.event_id;
  IF rec.tenant_id IS NULL OR rec.status <> 'pending' OR l.claim_id IS NULL
    OR NOT EXISTS (
       SELECT 1 FROM public.execution_attempts a
       WHERE a.id=NEW.attempt_id AND a.claim_id=NEW.claim_id
         AND a.fence=l.fence AND a.executor='acp' AND a.reserved_micros=0
    )
  THEN PERFORM public.manager_int_refuse('missing_event_claim_lineage'); END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER manager_claim_requires_broker_lineage
 BEFORE INSERT ON public.manager_claim_bindings
 FOR EACH ROW EXECUTE FUNCTION public.broker_manager_lineage_guard();

CREATE FUNCTION public.broker_verification_lineage_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE rec public.manager_event_receipts; l public.broker_manager_event_lineage;
BEGIN
  SELECT * INTO rec FROM public.manager_event_receipts
     WHERE tenant_id=NEW.tenant_id AND event_id=NEW.event_id;
  SELECT * INTO l FROM public.broker_manager_event_lineage
     WHERE tenant_id=NEW.tenant_id AND event_id=NEW.event_id;
  IF NOT FOUND OR rec.job IS NULL
      OR l.claim_id::text IS DISTINCT FROM rec.job ->> 'claimId'
      OR l.attempt_id::text IS DISTINCT FROM rec.job ->> 'attemptId'
      OR l.fence <> NEW.fence
  THEN PERFORM public.manager_int_refuse('unproven_verification_lineage'); END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER manager_verification_requires_broker_lineage
 BEFORE INSERT ON public.manager_verifications
 FOR EACH ROW EXECUTE FUNCTION public.broker_verification_lineage_guard();

CREATE OR REPLACE FUNCTION public.manager_int_claim_proof(rec public.manager_event_receipts)
RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE cl public.execution_claims; a public.execution_attempts;
  binding public.manager_claim_bindings;
BEGIN
  IF rec.status <> 'admitted' OR rec.job IS NULL OR rec.job ->> 'claimId' IS NULL THEN RETURN NULL; END IF;
  SELECT * INTO binding FROM public.manager_claim_bindings
    WHERE tenant_id=rec.tenant_id AND event_id=rec.event_id
      AND claim_id::text=rec.job ->> 'claimId'
      AND attempt_id::text=rec.job ->> 'attemptId';
  IF NOT FOUND THEN RETURN NULL; END IF;
  -- ARN-98 authoritative broker event provenance is mandatory for every duplicate.
  IF NOT EXISTS (
    SELECT 1 FROM public.broker_manager_event_lineage l
    WHERE l.tenant_id=rec.tenant_id AND l.event_id=rec.event_id
      AND l.claim_id=binding.claim_id AND l.attempt_id=binding.attempt_id
      AND l.fence::text=rec.job ->> 'fence'
      AND l.idempotency_key=rec.tenant_id::text || ':' || rec.event_id
  ) THEN RETURN NULL; END IF;
  SELECT * INTO cl FROM public.execution_claims
    WHERE id=binding.claim_id
      AND tenant_id=rec.tenant_id AND command_key=rec.expectation ->> 'claimKey';
  IF NOT FOUND THEN RETURN NULL; END IF;
  -- Duplicate evidence is scoped to the exact immutable attempt admitted
  -- for this event, never a newer claim reclaim at a higher fence.
  SELECT * INTO a FROM public.execution_attempts
    WHERE id = binding.attempt_id AND claim_id = cl.id AND executor = 'acp';
  IF NOT FOUND OR a.fence <> cl.fence OR a.state IS DISTINCT FROM cl.state
     OR cl.state NOT IN ('claimed','dispatched','unknown','settled')
     OR a.fence::text IS DISTINCT FROM rec.job ->> 'fence'
  THEN RETURN NULL; END IF;
  -- The idempotency_key is independently written in the broker-lineage row by the
  -- atomic claim wrapper and compared to the immutable receipt above.
  RETURN jsonb_build_object(
    'verified', true, 'claimId', cl.id::text, 'tenantId', rec.tenant_id::text,
    'claimKey', cl.command_key,
    'idempotencyKey', rec.tenant_id::text || ':' || rec.event_id,
    'executor', rec.expectation ->> 'executor', 'brokerExecutor', a.executor);
END;
$$;


ALTER FUNCTION public.manager_int_wallclock_grant_fresh(text) OWNER TO broker_owner;
ALTER FUNCTION public.manager_admission_wallclock_guard() OWNER TO broker_owner;
ALTER FUNCTION public.broker_claim_manager_event(uuid,text,text,uuid,uuid,integer,integer,integer) OWNER TO broker_owner;
ALTER FUNCTION public.broker_manager_lineage_guard() OWNER TO broker_owner;
ALTER FUNCTION public.broker_verification_lineage_guard() OWNER TO broker_owner;
-- Replaced helper remains owned by broker_owner.
REVOKE ALL ON FUNCTION
 public.broker_claim_manager_event(uuid,text,text,uuid,uuid,integer,integer,integer),
 public.broker_manager_lineage_guard(),public.broker_verification_lineage_guard(),
 public.manager_int_wallclock_grant_fresh(text),public.manager_admission_wallclock_guard()
 FROM PUBLIC,anon,authenticated,service_role,broker_caller,broker_intake,
 broker_gateway,manager_verifier;
GRANT EXECUTE ON FUNCTION
 public.broker_claim_manager_event(uuid,text,text,uuid,uuid,integer,integer,integer)
 TO broker_caller;

COMMENT ON TABLE public.broker_manager_event_lineage IS
 'ARN-98 immutable broker-issued event-to-claim-and-attempt binding; no legacy backfill or activation';
COMMIT;
