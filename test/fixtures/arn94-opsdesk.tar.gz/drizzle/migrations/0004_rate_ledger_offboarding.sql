CREATE INDEX IF NOT EXISTS proposed_actions_rate_idx ON public.proposed_actions (tenant_id, capability, created_at DESC);

-- Authoritative rolling one-hour attempt count. SECURITY INVOKER: RLS applies, and the
-- explicit tenant filter keeps counts tenant-scoped. Counts every attempt/proposal
-- (any decision, shadow or live) except synthetic test-suite proposals.
CREATE OR REPLACE FUNCTION public.count_recent_action_attempts(p_tenant uuid, p_capability text, p_as_of timestamptz DEFAULT now())
RETURNS integer LANGUAGE sql STABLE SET search_path = public AS $$
  SELECT count(*)::int FROM public.proposed_actions
  WHERE tenant_id = p_tenant AND capability = p_capability
    AND created_at > p_as_of - interval '1 hour' AND created_at <= p_as_of
    AND NOT (payload ? 'test_case');
$$;
GRANT EXECUTE ON FUNCTION public.count_recent_action_attempts(uuid, text, timestamptz) TO authenticated;

CREATE TABLE public.offboarding_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  status text NOT NULL DEFAULT 'draft',
  mode text NOT NULL DEFAULT 'record_only',
  reason text,
  steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT offboarding_mode_record_only CHECK (mode = 'record_only'),
  CONSTRAINT offboarding_status_valid CHECK (status IN ('draft','in_progress','completed','cancelled'))
);
GRANT SELECT ON public.offboarding_plans TO authenticated;
GRANT ALL ON public.offboarding_plans TO service_role;
ALTER TABLE public.offboarding_plans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner reads offboarding plans" ON public.offboarding_plans FOR SELECT TO authenticated USING (public.is_platform_admin());
CREATE POLICY "Auditors read offboarding plans" ON public.offboarding_plans FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'auditor'));