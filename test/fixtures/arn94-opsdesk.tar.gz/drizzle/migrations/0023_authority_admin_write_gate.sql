-- Restrict authority-matrix writes to tenant admins and prevent
-- capability live-enable configuration before the global Limited Live gate.

CREATE OR REPLACE FUNCTION public.is_tenant_admin(_tenant_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.is_platform_admin()
      OR EXISTS (
        SELECT 1
        FROM public.memberships m
        WHERE m.tenant_id = _tenant_id
          AND m.user_id = auth.uid()
          AND m.role IN ('owner_admin','client_admin')
      );
$$;

REVOKE ALL ON FUNCTION public.is_tenant_admin(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_tenant_admin(uuid) TO authenticated;

DROP POLICY IF EXISTS authority_policies_insert ON public.authority_policies;
DROP POLICY IF EXISTS authority_policies_update ON public.authority_policies;

CREATE POLICY authority_policies_insert
ON public.authority_policies
FOR INSERT
TO authenticated
WITH CHECK (public.is_tenant_admin(tenant_id));

CREATE POLICY authority_policies_update
ON public.authority_policies
FOR UPDATE
TO authenticated
USING (public.is_tenant_admin(tenant_id))
WITH CHECK (public.is_tenant_admin(tenant_id));

CREATE OR REPLACE FUNCTION public.authority_policy_limited_live_guard()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE limited_ready boolean;
BEGIN
  IF NEW.live_enabled THEN
    SELECT bool_value INTO limited_ready
    FROM public.system_flags
    WHERE key = 'limited_live_ready';

    IF limited_ready IS DISTINCT FROM true THEN
      RAISE EXCEPTION 'live authority refused: limited_live_ready is not true';
    END IF;
  END IF;
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS authority_policy_limited_live_guard ON public.authority_policies;
CREATE TRIGGER authority_policy_limited_live_guard
BEFORE INSERT OR UPDATE OF live_enabled
ON public.authority_policies
FOR EACH ROW
EXECUTE FUNCTION public.authority_policy_limited_live_guard();

COMMENT ON FUNCTION public.is_tenant_admin(uuid) IS
  'True only for platform owner or client_admin/owner_admin membership in the tenant. Used for authority/configuration writes.';

COMMENT ON FUNCTION public.authority_policy_limited_live_guard() IS
  'Fails closed if an authority policy is live-enabled before the global limited_live_ready gate is true.';
