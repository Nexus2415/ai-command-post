-- ARN-88 / ARN-78 gate 2: synthetic Postgres execution broker (atomic claim + lease + idempotency +
-- budget reservation + audit), implementing docs/rfcs/acp-eve-execution-broker.md (ARN-62, PR #176 at 8cdc5d5).
--
-- SOURCE ONLY. This migration is not applied to any Supabase project, branch database or production. It is
-- tested only against a throwaway local Postgres (tests/sql/arn-88-run.sh). Caps are never seeded: with no
-- execution_budgets row every claim is refused (RFC A13). It adds no secret, flag change or activation.
--
-- Roles are NOLOGIN groups. Mapping real logins/JWT issuers to broker_caller / broker_intake / broker_gateway is
-- owner gate 3 and is not done here. The reversible down-migration is drizzle/rollbacks/0030_execution_broker_down.sql.
--
-- Money is integer micro-USD everywhere. Provider prices are model_cost_rates USD per million tokens, which is
-- exactly micro-USD per token, so cost = ceil(tokens * price) with no float.

-- ---------------------------------------------------------------------------------------------------------
-- 0. Preconditions: the definer helpers below read RLS-protected tables as their owner, which only works if
--    none of those tables forces row-level security on its owner.
-- ---------------------------------------------------------------------------------------------------------
DO $pre$
DECLARE v_bad text;
BEGIN
  SELECT string_agg(c.relname, ', ') INTO v_bad
  FROM pg_catalog.pg_class c
  JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public'
    AND c.relname IN ('tenants','proposed_actions','approvals','authority_policies','system_flags','audit_events','model_cost_rates')
    AND c.relforcerowsecurity;
  IF v_bad IS NOT NULL THEN
    RAISE EXCEPTION 'broker migration refused: FORCE ROW LEVEL SECURITY is set on %; add an owner-scoped policy first', v_bad;
  END IF;
END
$pre$;

-- ---------------------------------------------------------------------------------------------------------
-- 1. Roles (RFC 5.0). broker_owner is not a superuser and has no BYPASSRLS.
-- ---------------------------------------------------------------------------------------------------------
DO $roles$
DECLARE r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['broker_owner','broker_caller','broker_intake','broker_gateway'] LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = r) THEN
      EXECUTE format('CREATE ROLE %I NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS', r);
    END IF;
  END LOOP;
  -- The migration runner must be able to hand objects to broker_owner. No-op for a superuser.
  IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = current_user AND rolsuper) THEN
    EXECUTE format('GRANT broker_owner TO %I', current_user);
  END IF;
END
$roles$;

GRANT USAGE ON SCHEMA public TO broker_owner, broker_caller, broker_intake, broker_gateway;

-- The composite key lets acp_commands point only at an action of its own tenant (RFC 4).
ALTER TABLE public.proposed_actions
  ADD CONSTRAINT proposed_actions_tenant_id_id_key UNIQUE (tenant_id, id);

-- ---------------------------------------------------------------------------------------------------------
-- 2. Tables (RFC 4). Owned by broker_owner, RLS on, no policies, no grants.
-- ---------------------------------------------------------------------------------------------------------
CREATE TABLE public.execution_budgets (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope            text NOT NULL CHECK (scope IN ('global','tenant')),
  tenant_id        uuid REFERENCES public.tenants(id),
  period           date NOT NULL,
  cap_micros       bigint NOT NULL CHECK (cap_micros >= 0),
  settled_micros   bigint NOT NULL DEFAULT 0 CHECK (settled_micros >= 0),
  reserved_micros  bigint NOT NULL DEFAULT 0 CHECK (reserved_micros >= 0),
  overrun_micros   bigint NOT NULL DEFAULT 0 CHECK (overrun_micros >= 0),
  frozen           boolean NOT NULL DEFAULT false,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT execution_budgets_scope_tenant CHECK
    ((scope = 'global' AND tenant_id IS NULL) OR (scope = 'tenant' AND tenant_id IS NOT NULL)),
  CONSTRAINT execution_budgets_period_is_month_start CHECK (extract(day FROM period) = 1),
  CONSTRAINT execution_budgets_scope_period_key UNIQUE NULLS NOT DISTINCT (scope, tenant_id, period)
);
-- No "settled + reserved <= cap" constraint on purpose: a real overrun must be recordable (RFC 4).

CREATE TABLE public.acp_commands (
  id                           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id                    uuid NOT NULL REFERENCES public.tenants(id),
  command_key                  text NOT NULL CHECK (length(command_key) BETWEEN 1 AND 200),
  source_ref                   text NOT NULL CHECK (length(source_ref) BETWEEN 1 AND 200),
  source_title_hash            text NOT NULL CHECK (source_title_hash ~ '^[0-9a-f]{64}$'),
  kind                         text NOT NULL CHECK (kind IN ('command','question')),
  proposed_action_id           uuid,
  hard_max_input_tokens        integer NOT NULL DEFAULT 0 CHECK (hard_max_input_tokens >= 0),
  hard_max_cached_input_tokens integer NOT NULL DEFAULT 0 CHECK (hard_max_cached_input_tokens >= 0),
  hard_max_output_tokens       integer NOT NULL DEFAULT 0 CHECK (hard_max_output_tokens >= 0),
  created_at                   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT acp_commands_tenant_key UNIQUE (tenant_id, command_key),
  CONSTRAINT acp_commands_tenant_id_id_key UNIQUE (tenant_id, id),
  CONSTRAINT acp_commands_action_fk FOREIGN KEY (tenant_id, proposed_action_id)
    REFERENCES public.proposed_actions (tenant_id, id),
  CONSTRAINT acp_commands_question_has_no_action CHECK (kind = 'command' OR proposed_action_id IS NULL)
);

CREATE TABLE public.execution_claims (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    uuid NOT NULL REFERENCES public.tenants(id),
  command_key  text NOT NULL,
  action_ref   uuid NOT NULL,
  fence        bigint NOT NULL DEFAULT 0 CHECK (fence >= 0),
  lease_until  timestamptz NOT NULL,
  state        text NOT NULL CHECK (state IN ('claimed','dispatched','unknown','settled','released','failed')),
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT execution_claims_tenant_key UNIQUE (tenant_id, command_key),
  CONSTRAINT execution_claims_action_fk FOREIGN KEY (tenant_id, action_ref)
    REFERENCES public.acp_commands (tenant_id, id)
);

CREATE TABLE public.execution_attempts (
  id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id                uuid NOT NULL REFERENCES public.execution_claims(id),
  attempt_no              integer NOT NULL CHECK (attempt_no >= 1),
  fence                   bigint NOT NULL CHECK (fence >= 1),
  operation_id            text NOT NULL UNIQUE,
  executor                text NOT NULL CHECK (executor IN ('acp','eve')),
  budget_period           date NOT NULL CHECK (extract(day FROM budget_period) = 1),
  tariff_ref              uuid NOT NULL REFERENCES public.model_cost_rates(id),
  max_input_tokens        integer NOT NULL CHECK (max_input_tokens >= 0),
  max_cached_input_tokens integer NOT NULL CHECK (max_cached_input_tokens >= 0),
  max_output_tokens       integer NOT NULL CHECK (max_output_tokens >= 1),
  approval_ref            uuid NOT NULL REFERENCES public.approvals(id),
  policy_hash             text NOT NULL,
  action_fingerprint      text NOT NULL,
  mode                    text NOT NULL CHECK (mode IN ('shadow','live')),
  reserved_micros         bigint NOT NULL CHECK (reserved_micros >= 0),
  actual_micros           bigint CHECK (actual_micros IS NULL OR actual_micros >= 0),
  usage_evidence_hash     text,
  state                   text NOT NULL CHECK (state IN ('claimed','dispatched','unknown','settled','released','failed')),
  created_at              timestamptz NOT NULL DEFAULT now(),
  dispatched_at           timestamptz,
  forwarded_at            timestamptz,
  settled_at              timestamptz,
  resolution              text CHECK (resolution IS NULL OR resolution IN ('settle','failed_no_charge')),
  resolved_by             uuid,
  resolution_evidence_hash text,
  CONSTRAINT execution_attempts_claim_no_key UNIQUE (claim_id, attempt_no),
  CONSTRAINT execution_attempts_evidence_required CHECK (actual_micros IS NULL OR usage_evidence_hash IS NOT NULL),
  CONSTRAINT execution_attempts_cached_within_input CHECK (max_cached_input_tokens <= max_input_tokens)
);

CREATE TABLE public.execution_usage (
  attempt_id           uuid PRIMARY KEY REFERENCES public.execution_attempts(id),
  provider_request_id  text NOT NULL CHECK (length(provider_request_id) BETWEEN 1 AND 200),
  input_tokens         bigint NOT NULL CHECK (input_tokens >= 0),
  cached_input_tokens  bigint NOT NULL,
  output_tokens        bigint NOT NULL CHECK (output_tokens >= 0),
  raw_usage_hash       text NOT NULL CHECK (raw_usage_hash ~ '^[0-9a-f]{64}$'),
  captured_at          timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT execution_usage_cached_within_input CHECK (cached_input_tokens BETWEEN 0 AND input_tokens)
);

-- Frozen state must survive a month rollover: a new period's row starts frozen if an earlier row of the
-- same scope and tenant is still frozen (RFC 4, A46).
CREATE FUNCTION public.broker_budget_inherit_freeze() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.execution_budgets b
    WHERE b.scope = NEW.scope AND b.tenant_id IS NOT DISTINCT FROM NEW.tenant_id
      AND b.period < NEW.period AND b.frozen
  ) THEN
    NEW.frozen := true;
  END IF;
  RETURN NEW;
END
$$;
CREATE TRIGGER execution_budgets_inherit_freeze BEFORE INSERT ON public.execution_budgets
  FOR EACH ROW EXECUTE FUNCTION public.broker_budget_inherit_freeze();

-- Columns that bind an attempt/claim/command at insert are never updated (RFC 4); no broker row is deleted.
CREATE FUNCTION public.broker_forbid_delete() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
BEGIN RAISE EXCEPTION '% rows are never deleted', TG_TABLE_NAME; END
$$;

CREATE FUNCTION public.broker_attempt_binding_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
BEGIN
  IF (NEW.id, NEW.claim_id, NEW.attempt_no, NEW.fence, NEW.operation_id, NEW.executor, NEW.budget_period,
      NEW.tariff_ref, NEW.max_input_tokens, NEW.max_cached_input_tokens, NEW.max_output_tokens,
      NEW.approval_ref, NEW.policy_hash, NEW.action_fingerprint, NEW.mode, NEW.reserved_micros, NEW.created_at)
     IS DISTINCT FROM
     (OLD.id, OLD.claim_id, OLD.attempt_no, OLD.fence, OLD.operation_id, OLD.executor, OLD.budget_period,
      OLD.tariff_ref, OLD.max_input_tokens, OLD.max_cached_input_tokens, OLD.max_output_tokens,
      OLD.approval_ref, OLD.policy_hash, OLD.action_fingerprint, OLD.mode, OLD.reserved_micros, OLD.created_at) THEN
    RAISE EXCEPTION 'execution_attempts binding columns are immutable';
  END IF;
  IF OLD.actual_micros IS NOT NULL AND (NEW.actual_micros IS DISTINCT FROM OLD.actual_micros
     OR NEW.usage_evidence_hash IS DISTINCT FROM OLD.usage_evidence_hash) THEN
    RAISE EXCEPTION 'a recorded settlement is immutable';
  END IF;
  RETURN NEW;
END
$$;
CREATE TRIGGER execution_attempts_binding BEFORE UPDATE ON public.execution_attempts
  FOR EACH ROW EXECUTE FUNCTION public.broker_attempt_binding_guard();

CREATE FUNCTION public.broker_claim_binding_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
BEGIN
  IF (NEW.id, NEW.tenant_id, NEW.command_key, NEW.action_ref, NEW.created_at)
     IS DISTINCT FROM (OLD.id, OLD.tenant_id, OLD.command_key, OLD.action_ref, OLD.created_at) THEN
    RAISE EXCEPTION 'execution_claims binding columns are immutable';
  END IF;
  RETURN NEW;
END
$$;
CREATE TRIGGER execution_claims_binding BEFORE UPDATE ON public.execution_claims
  FOR EACH ROW EXECUTE FUNCTION public.broker_claim_binding_guard();

CREATE TRIGGER acp_commands_immutable BEFORE UPDATE ON public.acp_commands
  FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();
CREATE TRIGGER execution_usage_immutable BEFORE UPDATE ON public.execution_usage
  FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();
CREATE TRIGGER acp_commands_no_delete BEFORE DELETE ON public.acp_commands
  FOR EACH ROW EXECUTE FUNCTION public.broker_forbid_delete();
CREATE TRIGGER execution_claims_no_delete BEFORE DELETE ON public.execution_claims
  FOR EACH ROW EXECUTE FUNCTION public.broker_forbid_delete();
CREATE TRIGGER execution_attempts_no_delete BEFORE DELETE ON public.execution_attempts
  FOR EACH ROW EXECUTE FUNCTION public.broker_forbid_delete();
CREATE TRIGGER execution_usage_no_delete BEFORE DELETE ON public.execution_usage
  FOR EACH ROW EXECUTE FUNCTION public.broker_forbid_delete();
CREATE TRIGGER execution_budgets_no_delete BEFORE DELETE ON public.execution_budgets
  FOR EACH ROW EXECUTE FUNCTION public.broker_forbid_delete();

ALTER TABLE public.execution_budgets OWNER TO broker_owner;
ALTER TABLE public.acp_commands      OWNER TO broker_owner;
ALTER TABLE public.execution_claims  OWNER TO broker_owner;
ALTER TABLE public.execution_attempts OWNER TO broker_owner;
ALTER TABLE public.execution_usage   OWNER TO broker_owner;

ALTER TABLE public.execution_budgets  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.acp_commands       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.execution_claims   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.execution_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.execution_usage    ENABLE ROW LEVEL SECURITY;

-- service_role is revoked too: the broker exists so that no key can write spend state outside the RPCs.
REVOKE ALL ON TABLE public.execution_budgets, public.acp_commands, public.execution_claims,
  public.execution_attempts, public.execution_usage
  FROM PUBLIC, anon, authenticated, service_role, broker_caller, broker_intake, broker_gateway;

ALTER FUNCTION public.broker_budget_inherit_freeze() OWNER TO broker_owner;
ALTER FUNCTION public.broker_forbid_delete() OWNER TO broker_owner;
ALTER FUNCTION public.broker_attempt_binding_guard() OWNER TO broker_owner;
ALTER FUNCTION public.broker_claim_binding_guard() OWNER TO broker_owner;
REVOKE EXECUTE ON FUNCTION public.broker_budget_inherit_freeze(), public.broker_forbid_delete(),
  public.broker_attempt_binding_guard(), public.broker_claim_binding_guard()
  FROM PUBLIC, anon, authenticated, service_role;

-- ---------------------------------------------------------------------------------------------------------
-- 3. Definer helpers for existing tables (RFC 5.0). Owned by the existing tables' owner (the migration
--    runner), single statement each, EXECUTE only for broker_owner. broker_owner gets NO table grants.
-- ---------------------------------------------------------------------------------------------------------
CREATE FUNCTION public.broker_read_tenant(p_tenant uuid)
RETURNS TABLE (id uuid, status text, tenant_kind text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT t.id, t.status, t.tenant_kind FROM public.tenants t WHERE t.id = p_tenant
$$;

CREATE FUNCTION public.broker_lock_tenant(p_tenant uuid)
RETURNS TABLE (id uuid, status text, tenant_kind text)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT t.id, t.status, t.tenant_kind FROM public.tenants t WHERE t.id = p_tenant FOR SHARE
$$;

CREATE FUNCTION public.broker_lock_action(p_action uuid)
RETURNS TABLE (id uuid, tenant_id uuid, decision text, mode text, capability text,
               proposal_version integer, payload_fingerprint text, policy_version text)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT a.id, a.tenant_id, a.decision::text, a.mode::text, a.capability,
         a.proposal_version, a.payload_fingerprint, a.policy_version
  FROM public.proposed_actions a WHERE a.id = p_action FOR SHARE
$$;

-- With p_approval NULL: the newest approval row of the action (a later rejection supersedes an earlier approval;
-- on an exact timestamp tie the non-approving row wins, i.e. fail closed).
-- With p_approval set: exactly that row.
CREATE FUNCTION public.broker_lock_approval(p_action uuid, p_approval uuid)
RETURNS TABLE (id uuid, tenant_id uuid, decision text, invalidated boolean,
               proposal_version integer, payload_fingerprint text, policy_version text)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT p.id, p.tenant_id, p.decision, (p.invalidated_at IS NOT NULL),
         p.proposal_version, p.payload_fingerprint, p.policy_version
  FROM public.approvals p
  WHERE p.proposed_action_id = p_action AND (p_approval IS NULL OR p.id = p_approval)
  ORDER BY p.decided_at DESC, (p.decision = 'approved' AND p.invalidated_at IS NULL) ASC, p.id DESC
  LIMIT 1
  FOR SHARE
$$;

-- The policy hash covers every column that changes what an approval may authorize (not notes or timestamps).
CREATE FUNCTION public.broker_lock_policy(p_tenant uuid, p_capability text)
RETURNS TABLE (policy_hash text)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT encode(sha256(convert_to(jsonb_build_array(
           p.risk::text, p.live_enabled, p.requires_secondary_validation, p.amount_threshold_cents,
           p.permitted_domains, p.permitted_recipients, p.rate_limit_per_hour, p.min_confidence)::text, 'UTF8')), 'hex')
  FROM public.authority_policies p
  WHERE p.tenant_id = p_tenant AND p.capability = p_capability
  FOR SHARE
$$;

-- Both flag rows, locked in key order (kill switch, then limited_live_ready). A missing row is returned as
-- missing so the caller can fail closed.
CREATE FUNCTION public.broker_lock_flags()
RETURNS TABLE (key text, bool_value boolean)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT f.key, f.bool_value FROM public.system_flags f
  WHERE f.key IN ('global_kill_switch','limited_live_ready')
  ORDER BY f.key
  FOR SHARE
$$;

CREATE FUNCTION public.broker_read_tariff(p_tariff uuid)
RETURNS TABLE (id uuid, provider text, model text, rate_version text, input_usd_per_million numeric,
               cached_input_usd_per_million numeric, output_usd_per_million numeric, effective_from timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT r.id, r.provider, r.model, r.rate_version, r.input_usd_per_million,
         r.cached_input_usd_per_million, r.output_usd_per_million, r.effective_from
  FROM public.model_cost_rates r WHERE r.id = p_tariff
$$;

CREATE FUNCTION public.broker_read_tariff_by_name(p_provider text, p_model text, p_rate_version text)
RETURNS TABLE (id uuid, provider text, model text, rate_version text, input_usd_per_million numeric,
               cached_input_usd_per_million numeric, output_usd_per_million numeric, effective_from timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT r.id, r.provider, r.model, r.rate_version, r.input_usd_per_million,
         r.cached_input_usd_per_million, r.output_usd_per_million, r.effective_from
  FROM public.model_cost_rates r
  WHERE r.provider = p_provider AND r.model = p_model AND r.rate_version = p_rate_version
$$;

CREATE FUNCTION public.broker_write_audit(
  p_tenant uuid, p_actor text, p_actor_type text, p_actor_user uuid, p_action text, p_inputs jsonb,
  p_decision text, p_outcome text, p_mode text, p_correlation text)
RETURNS void
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  INSERT INTO public.audit_events (tenant_id, actor, actor_type, actor_user_id, action, inputs, decision,
                                   policy_rule, intended_side_effect, outcome, mode, correlation_key)
  VALUES (p_tenant, p_actor, p_actor_type, p_actor_user, p_action, p_inputs, p_decision,
          'execution_broker', 'none (broker bookkeeping only)', p_outcome, p_mode::public.exec_mode, p_correlation)
$$;

-- auth.uid() through a definer so broker_owner needs no grant on the auth schema.
CREATE FUNCTION public.broker_auth_uid() RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT auth.uid()
$$;

REVOKE EXECUTE ON FUNCTION
  public.broker_read_tenant(uuid), public.broker_lock_tenant(uuid), public.broker_lock_action(uuid),
  public.broker_lock_approval(uuid, uuid), public.broker_lock_policy(uuid, text), public.broker_lock_flags(),
  public.broker_read_tariff(uuid), public.broker_read_tariff_by_name(text, text, text),
  public.broker_write_audit(uuid, text, text, uuid, text, jsonb, text, text, text, text), public.broker_auth_uid()
  FROM PUBLIC, anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION
  public.broker_read_tenant(uuid), public.broker_lock_tenant(uuid), public.broker_lock_action(uuid),
  public.broker_lock_approval(uuid, uuid), public.broker_lock_policy(uuid, text), public.broker_lock_flags(),
  public.broker_read_tariff(uuid), public.broker_read_tariff_by_name(text, text, text),
  public.broker_write_audit(uuid, text, text, uuid, text, jsonb, text, text, text, text), public.broker_auth_uid()
  TO broker_owner;

-- RFC 5.0 admin helper: the nested check runs as broker_owner, so it needs EXECUTE and nothing more.
GRANT EXECUTE ON FUNCTION public.is_platform_admin() TO broker_owner;

-- ---------------------------------------------------------------------------------------------------------
-- 4. Internal functions (owned by broker_owner, callable only from the RPCs below).
-- ---------------------------------------------------------------------------------------------------------
-- A refusal is an exception with this SQLSTATE; each RPC catches it around its writes, so the writes roll
-- back to the savepoint and the RPC returns {"ok": false, "reason": ...}. Anything else aborts the call.
CREATE FUNCTION public.broker_int_refuse(p_reason text) RETURNS void
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
BEGIN RAISE EXCEPTION '%', p_reason USING ERRCODE = 'BRK01'; END
$$;

CREATE FUNCTION public.broker_int_claims() RETURNS jsonb
LANGUAGE plpgsql STABLE SET search_path = pg_catalog, public, pg_temp AS $$
BEGIN
  RETURN coalesce(nullif(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
EXCEPTION WHEN others THEN
  RETURN '{}'::jsonb;
END
$$;

-- The verified executor identity of the broker_caller session; never an argument.
CREATE FUNCTION public.broker_int_executor() RETURNS text
LANGUAGE plpgsql STABLE SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE v text := public.broker_int_claims() ->> 'executor';
BEGIN
  IF v IS NULL OR v NOT IN ('acp','eve') THEN PERFORM public.broker_int_refuse('unauthorized'); END IF;
  RETURN v;
END
$$;

CREATE FUNCTION public.broker_int_tenant_allowed(p_tenant uuid) RETURNS boolean
LANGUAGE sql STABLE SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT coalesce(jsonb_typeof(c -> 'tenant_ids') = 'array' AND (c -> 'tenant_ids') @> to_jsonb(p_tenant::text), false)
  FROM (SELECT public.broker_int_claims() AS c) s
$$;

CREATE FUNCTION public.broker_int_period() RETURNS date
LANGUAGE sql STABLE SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT date_trunc('month', now() AT TIME ZONE 'UTC')::date
$$;

CREATE FUNCTION public.broker_int_claim_key(p_tenant uuid, p_key text) RETURNS bigint
LANGUAGE sql IMMUTABLE SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT hashtextextended(p_tenant::text || ':' || p_key, 0)
$$;

-- Cost of measured usage: uncached input, cached input and output, each at its own price, rounded up.
CREATE FUNCTION public.broker_int_cost(p_input bigint, p_cached bigint, p_output bigint,
                                       p_in_price numeric, p_cached_price numeric, p_out_price numeric) RETURNS bigint
LANGUAGE sql IMMUTABLE SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT ceil((p_input - p_cached) * p_in_price + p_cached * p_cached_price + p_output * p_out_price)::bigint
$$;

-- Worst-case reservation (RFC 5.2 step 1.2): the sum over categories of bound x price, rounded up.
CREATE FUNCTION public.broker_int_worst_case(p_input bigint, p_cached bigint, p_output bigint,
                                             p_in_price numeric, p_cached_price numeric, p_out_price numeric) RETURNS bigint
LANGUAGE sql IMMUTABLE SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT ceil(p_input * p_in_price + p_cached * p_cached_price + p_output * p_out_price)::bigint
$$;

CREATE FUNCTION public.broker_int_admin() RETURNS uuid
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE v uuid := public.broker_auth_uid();
BEGIN
  IF v IS NULL OR NOT public.is_platform_admin() THEN PERFORM public.broker_int_refuse('forbidden'); END IF;
  RETURN v;
END
$$;

-- Budget rows are locked global first, then tenant (RFC 5.1). Missing rows refuse; duplicates cannot exist.
CREATE FUNCTION public.broker_int_lock_global(p_period date) RETURNS public.execution_budgets
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE r public.execution_budgets;
BEGIN
  SELECT * INTO r FROM public.execution_budgets WHERE scope = 'global' AND tenant_id IS NULL AND period = p_period FOR UPDATE;
  IF NOT FOUND THEN PERFORM public.broker_int_refuse('budget_unavailable'); END IF;
  RETURN r;
END
$$;

CREATE FUNCTION public.broker_int_lock_tenant_budget(p_tenant uuid, p_period date) RETURNS public.execution_budgets
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE r public.execution_budgets;
BEGIN
  SELECT * INTO r FROM public.execution_budgets WHERE scope = 'tenant' AND tenant_id = p_tenant AND period = p_period FOR UPDATE;
  IF NOT FOUND THEN PERFORM public.broker_int_refuse('budget_unavailable'); END IF;
  RETURN r;
END
$$;

-- Audit helper: ids and integers only. Never a prompt, payload, title or client data.
CREATE FUNCTION public.broker_int_audit(p_tenant uuid, p_actor text, p_actor_type text, p_actor_user uuid,
                                        p_action text, p_inputs jsonb, p_decision text, p_outcome text,
                                        p_mode text, p_correlation text) RETURNS void
LANGUAGE sql SET search_path = pg_catalog, public, pg_temp AS $$
  SELECT public.broker_write_audit(p_tenant, p_actor, p_actor_type, p_actor_user, p_action, p_inputs,
                                   p_decision, p_outcome, p_mode, p_correlation)
$$;

-- Recompute overrun from the row, never increment it (RFC 5.2 item 3), and optionally freeze.
CREATE FUNCTION public.broker_int_recompute(p_ids uuid[], p_freeze boolean) RETURNS void
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE n integer;
BEGIN
  UPDATE public.execution_budgets
  SET overrun_micros = greatest(0, settled_micros + reserved_micros - cap_micros),
      frozen = frozen OR p_freeze,
      updated_at = now()
  WHERE id = ANY (p_ids);
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n <> cardinality(p_ids) THEN RAISE EXCEPTION 'broker invariant: budget row count % <> %', n, cardinality(p_ids); END IF;
END
$$;

-- On an overrun or late charge in an earlier period, the current period's rows are frozen too, so the
-- historical overrun blocks current reservations at once. Skipped when those rows do not exist yet: the
-- any-period frozen check and frozen-on-creation cover every later reservation (RFC 5.2 item 3, A46).
CREATE FUNCTION public.broker_int_freeze_current(p_tenant uuid, p_period date) RETURNS void
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE v_cur date := public.broker_int_period(); g public.execution_budgets; t public.execution_budgets;
BEGIN
  IF v_cur = p_period THEN RETURN; END IF;
  SELECT * INTO g FROM public.execution_budgets WHERE scope = 'global' AND tenant_id IS NULL AND period = v_cur FOR UPDATE;
  IF FOUND THEN PERFORM public.broker_int_recompute(ARRAY[g.id], true); END IF;
  SELECT * INTO t FROM public.execution_budgets WHERE scope = 'tenant' AND tenant_id = p_tenant AND period = v_cur FOR UPDATE;
  IF FOUND THEN PERFORM public.broker_int_recompute(ARRAY[t.id], true); END IF;
END
$$;

ALTER FUNCTION public.broker_int_refuse(text) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_claims() OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_executor() OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_tenant_allowed(uuid) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_period() OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_claim_key(uuid, text) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_cost(bigint, bigint, bigint, numeric, numeric, numeric) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_worst_case(bigint, bigint, bigint, numeric, numeric, numeric) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_admin() OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_lock_global(date) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_lock_tenant_budget(uuid, date) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_audit(uuid, text, text, uuid, text, jsonb, text, text, text, text) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_recompute(uuid[], boolean) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_freeze_current(uuid, date) OWNER TO broker_owner;

-- ---------------------------------------------------------------------------------------------------------
-- 5. RPCs (RFC 5.2). SECURITY DEFINER as broker_owner, pg_temp searched last, every object schema-qualified.
--    Each returns jsonb: {"ok": true, ...} or {"ok": false, "reason": ...}. Refusals roll their writes back.
-- ---------------------------------------------------------------------------------------------------------

-- 5.0 intake: the only way a command record is created. Kind comes from the title the intake job fetched.
CREATE FUNCTION public.broker_record_command(
  p_tenant uuid, p_command_key text, p_source_ref text, p_title text, p_proposed_action uuid,
  p_hard_max_input integer, p_hard_max_cached integer, p_hard_max_output integer)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_kind text; v_hash text; v_id uuid; c public.acp_commands; ac record; tn record;
BEGIN
  BEGIN
    IF p_tenant IS NULL OR p_command_key IS NULL OR p_source_ref IS NULL OR p_title IS NULL THEN
      PERFORM public.broker_int_refuse('invalid_input');
    END IF;
    IF NOT public.broker_int_tenant_allowed(p_tenant) THEN PERFORM public.broker_int_refuse('forbidden_tenant'); END IF;
    SELECT * INTO tn FROM public.broker_read_tenant(p_tenant);
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('unknown_tenant'); END IF;
    v_kind := CASE WHEN p_title LIKE '[Question]%' THEN 'question' ELSE 'command' END;
    v_hash := encode(sha256(convert_to(p_title, 'UTF8')), 'hex');
    IF v_kind = 'question' AND p_proposed_action IS NOT NULL THEN PERFORM public.broker_int_refuse('question_has_action'); END IF;
    IF coalesce(p_hard_max_input, -1) < 0 OR coalesce(p_hard_max_cached, -1) < 0 OR coalesce(p_hard_max_output, -1) < 0
       OR p_hard_max_cached > p_hard_max_input THEN
      PERFORM public.broker_int_refuse('invalid_input');
    END IF;
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(p_tenant, p_command_key));
    IF p_proposed_action IS NOT NULL THEN
      SELECT * INTO ac FROM public.broker_lock_action(p_proposed_action);
      IF NOT FOUND OR ac.tenant_id <> p_tenant THEN PERFORM public.broker_int_refuse('binding_conflict'); END IF;
    END IF;
    SELECT * INTO c FROM public.acp_commands WHERE tenant_id = p_tenant AND command_key = p_command_key;
    IF FOUND THEN
      -- Idempotent only for the identical record; a reclassification is a new command_key.
      IF c.source_ref = p_source_ref AND c.source_title_hash = v_hash AND c.kind = v_kind
         AND c.proposed_action_id IS NOT DISTINCT FROM p_proposed_action THEN
        RETURN jsonb_build_object('ok', true, 'created', false, 'command_id', c.id, 'kind', c.kind);
      END IF;
      PERFORM public.broker_int_refuse('command_conflict');
    END IF;
    INSERT INTO public.acp_commands (tenant_id, command_key, source_ref, source_title_hash, kind, proposed_action_id,
                                     hard_max_input_tokens, hard_max_cached_input_tokens, hard_max_output_tokens)
    VALUES (p_tenant, p_command_key, p_source_ref, v_hash, v_kind, p_proposed_action,
            p_hard_max_input, p_hard_max_cached, p_hard_max_output)
    RETURNING id INTO v_id;
    PERFORM public.broker_int_audit(p_tenant, 'intake', 'agent', NULL, 'broker_record_command',
      jsonb_build_object('command_id', v_id, 'kind', v_kind, 'proposed_action_id', p_proposed_action),
      'allow', 'command recorded', 'shadow', 'broker-cmd-' || v_id::text);
    RETURN jsonb_build_object('ok', true, 'created', true, 'command_id', v_id, 'kind', v_kind);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- 5.2.1 claim_and_reserve. One transaction; also the takeover path when the latest attempt is released/failed.
CREATE FUNCTION public.broker_claim_and_reserve(
  p_tenant uuid, p_command_key text, p_action_ref uuid, p_tariff_ref uuid,
  p_max_input integer, p_max_cached integer, p_max_output integer)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_exec text; v_period date := public.broker_int_period();
  cl public.execution_claims; la public.execution_attempts; cmd public.acp_commands;
  tn record; ac record; ap record; tf record; fl record;
  v_kill boolean; v_kill_seen boolean := false; v_live boolean; v_live_seen boolean := false;
  v_policy_hash text; v_fingerprint text; v_worst bigint; v_fence bigint; v_no integer; v_attempt uuid;
  v_created boolean := false; g public.execution_budgets; t public.execution_budgets; v_op text; n integer;
BEGIN
  BEGIN
    IF p_tenant IS NULL OR p_command_key IS NULL OR p_action_ref IS NULL OR p_tariff_ref IS NULL THEN
      PERFORM public.broker_int_refuse('invalid_input');
    END IF;
    v_exec := public.broker_int_executor();
    IF NOT public.broker_int_tenant_allowed(p_tenant) THEN PERFORM public.broker_int_refuse('forbidden_tenant'); END IF;

    -- Lock order (RFC 5.1): claim-key advisory lock -> claim -> latest attempt -> tenant -> action -> approval
    -- -> policy -> flags -> global budget -> tenant budget.
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(p_tenant, p_command_key));
    SELECT * INTO cl FROM public.execution_claims WHERE tenant_id = p_tenant AND command_key = p_command_key FOR UPDATE;
    IF FOUND THEN
      SELECT * INTO la FROM public.execution_attempts WHERE claim_id = cl.id ORDER BY attempt_no DESC LIMIT 1 FOR UPDATE;
      IF NOT FOUND OR la.state <> cl.state THEN
        RAISE EXCEPTION 'broker invariant: claim % state % does not follow its latest attempt', cl.id, cl.state;
      END IF;
    END IF;

    SELECT * INTO tn FROM public.broker_lock_tenant(p_tenant);
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('unknown_tenant'); END IF;
    IF tn.status NOT IN ('shadow_testing','active') THEN PERFORM public.broker_int_refuse('tenant_inactive'); END IF;

    SELECT * INTO cmd FROM public.acp_commands WHERE id = p_action_ref AND tenant_id = p_tenant;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('unknown_action'); END IF;
    IF cmd.command_key <> p_command_key THEN PERFORM public.broker_int_refuse('binding_conflict'); END IF;
    IF cl.id IS NOT NULL AND cl.action_ref <> p_action_ref THEN PERFORM public.broker_int_refuse('binding_conflict'); END IF;
    IF cmd.kind <> 'command' THEN PERFORM public.broker_int_refuse('not_executable'); END IF;
    IF cmd.proposed_action_id IS NULL THEN PERFORM public.broker_int_refuse('approval_required'); END IF;

    SELECT * INTO ac FROM public.broker_lock_action(cmd.proposed_action_id);
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('unknown_action'); END IF;
    IF ac.tenant_id <> p_tenant THEN PERFORM public.broker_int_refuse('binding_conflict'); END IF;
    SELECT * INTO ap FROM public.broker_lock_approval(ac.id, NULL);
    IF ac.capability IS NOT NULL THEN
      SELECT x.policy_hash INTO v_policy_hash FROM public.broker_lock_policy(p_tenant, ac.capability) x;
    END IF;
    FOR fl IN SELECT * FROM public.broker_lock_flags() LOOP
      IF fl.key = 'global_kill_switch' THEN v_kill := fl.bool_value; v_kill_seen := true; END IF;
      IF fl.key = 'limited_live_ready' THEN v_live := fl.bool_value; v_live_seen := true; END IF;
    END LOOP;

    -- Authority. A flag row that is missing or unreadable is treated as the kill switch being on.
    IF NOT v_kill_seen OR v_kill IS DISTINCT FROM false THEN PERFORM public.broker_int_refuse('kill_switch'); END IF;
    IF ac.decision = 'blocked' THEN PERFORM public.broker_int_refuse('not_executable'); END IF;
    IF ap.id IS NULL OR ap.decision <> 'approved' OR ap.invalidated
       OR ap.tenant_id <> p_tenant
       OR ap.proposal_version IS DISTINCT FROM ac.proposal_version
       OR ap.payload_fingerprint IS DISTINCT FROM ac.payload_fingerprint
       OR ap.policy_version IS DISTINCT FROM ac.policy_version
       OR v_policy_hash IS NULL THEN
      PERFORM public.broker_int_refuse('approval_required');
    END IF;
    IF ac.mode = 'live' AND (NOT v_live_seen OR v_live IS DISTINCT FROM true) THEN
      PERFORM public.broker_int_refuse('live_not_enabled');
    END IF;
    v_fingerprint := ac.payload_fingerprint || '#' || ac.proposal_version::text;

    -- The broker derives the reservation from the tariff and token bounds; the caller supplies no amount.
    SELECT * INTO tf FROM public.broker_read_tariff(p_tariff_ref);
    IF NOT FOUND OR tf.effective_from > now() THEN PERFORM public.broker_int_refuse('unknown_tariff'); END IF;
    IF tf.input_usd_per_million IS NULL OR tf.output_usd_per_million IS NULL OR tf.cached_input_usd_per_million IS NULL
       OR tf.input_usd_per_million < 0 OR tf.output_usd_per_million < 0 OR tf.cached_input_usd_per_million < 0 THEN
      PERFORM public.broker_int_refuse('invalid_tariff');
    END IF;
    IF p_max_input IS NULL OR p_max_cached IS NULL OR p_max_output IS NULL
       OR p_max_input < 0 OR p_max_cached < 0 OR p_max_output < 1 OR p_max_cached > p_max_input THEN
      PERFORM public.broker_int_refuse('invalid_bounds');
    END IF;
    IF p_max_input > cmd.hard_max_input_tokens OR p_max_cached > cmd.hard_max_cached_input_tokens
       OR p_max_output > cmd.hard_max_output_tokens THEN
      PERFORM public.broker_int_refuse('above_action_limit');
    END IF;
    v_worst := public.broker_int_worst_case(p_max_input, p_max_cached, p_max_output,
                 tf.input_usd_per_million, tf.cached_input_usd_per_million, tf.output_usd_per_million);
    -- Zero is allowed: an eligible free executor (all-zero tariff) reserves 0 and still needs budget rows (ARN-86).
    IF v_worst IS NULL OR v_worst < 0 THEN PERFORM public.broker_int_refuse('invalid_worst_case'); END IF;

    -- Existing claim: only released/failed is reclaimable; anything else returns its id and charges nothing.
    IF cl.id IS NOT NULL AND cl.state NOT IN ('released','failed') THEN
      RETURN jsonb_build_object('ok', true, 'created', false, 'claim_id', cl.id, 'state', cl.state);
    END IF;

    -- Budgets are checked before the claim row is written, but still under the claim-key lock.
    g := public.broker_int_lock_global(v_period);
    t := public.broker_int_lock_tenant_budget(p_tenant, v_period);
    IF EXISTS (SELECT 1 FROM public.execution_budgets b
               WHERE b.frozen AND (b.scope = 'global' OR b.tenant_id = p_tenant)) THEN
      PERFORM public.broker_int_refuse('frozen');
    END IF;
    IF g.settled_micros + g.reserved_micros + v_worst > g.cap_micros
       OR t.settled_micros + t.reserved_micros + v_worst > t.cap_micros THEN
      PERFORM public.broker_int_refuse('insufficient_budget');
    END IF;

    IF cl.id IS NULL THEN
      INSERT INTO public.execution_claims (tenant_id, command_key, action_ref, fence, lease_until, state)
      VALUES (p_tenant, p_command_key, p_action_ref, 0, now() + interval '15 minutes', 'claimed')
      RETURNING * INTO cl;
      v_created := true;
      v_no := 1;
    ELSE
      v_no := la.attempt_no + 1;
    END IF;
    v_fence := cl.fence + 1;
    v_op := 'op:' || cl.id::text || ':' || v_fence::text;

    INSERT INTO public.execution_attempts (claim_id, attempt_no, fence, operation_id, executor, budget_period, tariff_ref,
        max_input_tokens, max_cached_input_tokens, max_output_tokens, approval_ref, policy_hash, action_fingerprint,
        mode, reserved_micros, state)
    VALUES (cl.id, v_no, v_fence, v_op, v_exec, v_period, p_tariff_ref, p_max_input, p_max_cached, p_max_output,
            ap.id, v_policy_hash, v_fingerprint, ac.mode, v_worst, 'claimed')
    RETURNING id INTO v_attempt;

    UPDATE public.execution_budgets SET reserved_micros = reserved_micros + v_worst, updated_at = now()
      WHERE id IN (g.id, t.id);
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n <> 2 THEN RAISE EXCEPTION 'broker invariant: reserved % budget rows', n; END IF;

    UPDATE public.execution_claims SET fence = v_fence, state = 'claimed', lease_until = now() + interval '15 minutes',
      updated_at = now() WHERE id = cl.id;
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n <> 1 THEN RAISE EXCEPTION 'broker invariant: claim update row count %', n; END IF;

    PERFORM public.broker_int_audit(p_tenant, v_exec, 'agent', NULL, 'broker_reserve',
      jsonb_build_object('claim_id', cl.id, 'attempt_id', v_attempt, 'fence', v_fence, 'attempt_no', v_no,
                         'reserved_micros', v_worst, 'budget_period', v_period, 'takeover', NOT v_created),
      'allow', 'reservation made', ac.mode, v_op);

    RETURN jsonb_build_object('ok', true, 'created', v_created, 'claim_id', cl.id, 'attempt_id', v_attempt,
      'operation_id', v_op, 'fence', v_fence, 'reserved_micros', v_worst, 'budget_period', v_period);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- 5.2.2 mark_dispatched: grants execution authority, so it re-checks every binding under the locks.
CREATE FUNCTION public.broker_mark_dispatched(p_attempt uuid, p_fence bigint)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_exec text; v_claim uuid; v_tenant uuid; v_key text; v_fail text; n integer;
  cl public.execution_claims; a public.execution_attempts; cmd public.acp_commands;
  tn record; ac record; ap record; tf record; fl record; v_policy_hash text;
  v_kill boolean; v_kill_seen boolean := false; v_live boolean; v_live_seen boolean := false;
  g public.execution_budgets; t public.execution_budgets;
BEGIN
  BEGIN
    IF p_attempt IS NULL OR p_fence IS NULL THEN PERFORM public.broker_int_refuse('invalid_input'); END IF;
    v_exec := public.broker_int_executor();
    SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;
    IF NOT public.broker_int_tenant_allowed(v_tenant) THEN PERFORM public.broker_int_refuse('not_found'); END IF;

    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
    SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
    SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;
    IF a.executor <> v_exec THEN PERFORM public.broker_int_refuse('not_owner'); END IF;
    -- A stale fence or a state other than claimed (e.g. a concurrent duplicate already dispatched) changes nothing.
    IF p_fence <> a.fence OR p_fence <> cl.fence OR a.state <> 'claimed' THEN
      RETURN jsonb_build_object('ok', false, 'reason', 'stale');
    END IF;

    SELECT * INTO tn FROM public.broker_lock_tenant(v_tenant);
    SELECT * INTO cmd FROM public.acp_commands WHERE id = cl.action_ref;
    SELECT * INTO ac FROM public.broker_lock_action(cmd.proposed_action_id);
    SELECT * INTO ap FROM public.broker_lock_approval(ac.id, a.approval_ref);
    IF ac.capability IS NOT NULL THEN
      SELECT x.policy_hash INTO v_policy_hash FROM public.broker_lock_policy(v_tenant, ac.capability) x;
    END IF;
    FOR fl IN SELECT * FROM public.broker_lock_flags() LOOP
      IF fl.key = 'global_kill_switch' THEN v_kill := fl.bool_value; v_kill_seen := true; END IF;
      IF fl.key = 'limited_live_ready' THEN v_live := fl.bool_value; v_live_seen := true; END IF;
    END LOOP;

    v_fail := CASE
      WHEN NOT v_kill_seen OR v_kill IS DISTINCT FROM false THEN 'kill_switch'
      WHEN tn.id IS NULL OR tn.status NOT IN ('shadow_testing','active') THEN 'tenant_inactive'
      WHEN ac.id IS NULL OR ac.decision = 'blocked' THEN 'not_executable'
      WHEN ac.payload_fingerprint || '#' || ac.proposal_version::text <> a.action_fingerprint
           OR ac.mode <> a.mode OR v_policy_hash IS DISTINCT FROM a.policy_hash THEN 'binding_changed'
      WHEN ap.id IS NULL OR ap.decision <> 'approved' OR ap.invalidated
           OR ap.proposal_version IS DISTINCT FROM ac.proposal_version
           OR ap.payload_fingerprint IS DISTINCT FROM ac.payload_fingerprint
           OR ap.policy_version IS DISTINCT FROM ac.policy_version THEN 'approval_revoked'
      WHEN a.mode = 'live' AND (NOT v_live_seen OR v_live IS DISTINCT FROM true) THEN 'live_not_enabled'
      ELSE NULL END;

    IF v_fail IS NOT NULL THEN
      -- It provably never dispatched: return the whole reservation and record why. This commits.
      g := public.broker_int_lock_global(a.budget_period);
      t := public.broker_int_lock_tenant_budget(v_tenant, a.budget_period);
      UPDATE public.execution_budgets SET reserved_micros = reserved_micros - a.reserved_micros, updated_at = now()
        WHERE id IN (g.id, t.id);
      GET DIAGNOSTICS n = ROW_COUNT;
      IF n <> 2 THEN RAISE EXCEPTION 'broker invariant: released % budget rows', n; END IF;
      UPDATE public.execution_attempts SET state = 'released' WHERE id = a.id;
      UPDATE public.execution_claims SET state = 'released', updated_at = now() WHERE id = cl.id;
      PERFORM public.broker_int_audit(v_tenant, v_exec, 'agent', NULL, 'broker_dispatch_refused',
        jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'fence', a.fence, 'reason', v_fail,
                           'released_micros', a.reserved_micros),
        'blocked', v_fail, a.mode, a.operation_id);
      RETURN jsonb_build_object('ok', false, 'reason', v_fail, 'released', true);
    END IF;

    SELECT * INTO tf FROM public.broker_read_tariff(a.tariff_ref);
    UPDATE public.execution_attempts SET state = 'dispatched', dispatched_at = now() WHERE id = a.id;
    UPDATE public.execution_claims SET state = 'dispatched', lease_until = now() + interval '15 minutes',
      updated_at = now() WHERE id = cl.id;
    PERFORM public.broker_int_audit(v_tenant, v_exec, 'agent', NULL, 'broker_dispatch',
      jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'fence', a.fence),
      'allow', 'dispatch authorized', a.mode, a.operation_id);
    RETURN jsonb_build_object('ok', true, 'attempt_id', a.id, 'operation_id', a.operation_id, 'fence', a.fence,
      'provider', tf.provider, 'model', tf.model, 'rate_version', tf.rate_version,
      'max_input_tokens', a.max_input_tokens, 'max_cached_input_tokens', a.max_cached_input_tokens,
      'max_output_tokens', a.max_output_tokens);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- 5.2.4 mark_unknown: timeout, lost response, or a 5xx after possible acceptance. The reservation is kept.
CREATE FUNCTION public.broker_mark_unknown(p_attempt uuid, p_fence bigint)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_exec text; v_claim uuid; v_tenant uuid; v_key text;
  cl public.execution_claims; a public.execution_attempts;
BEGIN
  BEGIN
    IF p_attempt IS NULL OR p_fence IS NULL THEN PERFORM public.broker_int_refuse('invalid_input'); END IF;
    v_exec := public.broker_int_executor();
    SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;
    IF NOT public.broker_int_tenant_allowed(v_tenant) THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
    SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
    SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;
    IF a.executor <> v_exec THEN PERFORM public.broker_int_refuse('not_owner'); END IF;
    IF p_fence <> a.fence OR p_fence <> cl.fence THEN RETURN jsonb_build_object('ok', false, 'reason', 'stale'); END IF;
    IF a.state <> 'dispatched' THEN PERFORM public.broker_int_refuse('invalid_state'); END IF;
    UPDATE public.execution_attempts SET state = 'unknown' WHERE id = a.id;
    UPDATE public.execution_claims SET state = 'unknown', updated_at = now() WHERE id = cl.id;
    PERFORM public.broker_int_audit(v_tenant, v_exec, 'agent', NULL, 'broker_mark_unknown',
      jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'fence', a.fence, 'held_micros', a.reserved_micros),
      'allow', 'outcome unknown; reservation kept', a.mode, a.operation_id);
    RETURN jsonb_build_object('ok', true, 'changed', true);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- 5.2.5 release: only an attempt that provably never dispatched. Returns the full reservation.
CREATE FUNCTION public.broker_release(p_attempt uuid, p_fence bigint, p_reason text)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_exec text; v_claim uuid; v_tenant uuid; v_key text; n integer;
  cl public.execution_claims; a public.execution_attempts; g public.execution_budgets; t public.execution_budgets;
BEGIN
  BEGIN
    IF p_attempt IS NULL OR p_fence IS NULL THEN PERFORM public.broker_int_refuse('invalid_input'); END IF;
    v_exec := public.broker_int_executor();
    SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;
    IF NOT public.broker_int_tenant_allowed(v_tenant) THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
    SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
    SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;
    IF a.executor <> v_exec THEN PERFORM public.broker_int_refuse('not_owner'); END IF;
    IF p_fence <> a.fence OR p_fence <> cl.fence THEN RETURN jsonb_build_object('ok', false, 'reason', 'stale'); END IF;
    IF a.state <> 'claimed' OR a.dispatched_at IS NOT NULL THEN PERFORM public.broker_int_refuse('invalid_state'); END IF;
    g := public.broker_int_lock_global(a.budget_period);
    t := public.broker_int_lock_tenant_budget(v_tenant, a.budget_period);
    UPDATE public.execution_budgets SET reserved_micros = reserved_micros - a.reserved_micros, updated_at = now()
      WHERE id IN (g.id, t.id);
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n <> 2 THEN RAISE EXCEPTION 'broker invariant: released % budget rows', n; END IF;
    UPDATE public.execution_attempts SET state = 'released' WHERE id = a.id;
    UPDATE public.execution_claims SET state = 'released', updated_at = now() WHERE id = cl.id;
    PERFORM public.broker_int_audit(v_tenant, v_exec, 'agent', NULL, 'broker_release',
      jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'fence', a.fence,
                         'released_micros', a.reserved_micros, 'reason', left(coalesce(p_reason, ''), 80)),
      'allow', 'reservation released', a.mode, a.operation_id);
    RETURN jsonb_build_object('ok', true, 'changed', true);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- Shared settlement accounting (RFC 5.2 item 3). Locks claim -> attempt -> budget rows. Callers have already
-- checked who may settle. p_evidence is the measured usage (tokens, and optionally the tariff it names).
-- Returns jsonb; refusals that must leave an audit row return 'persist' = true so the caller writes it outside
-- the rolled-back block.
CREATE FUNCTION public.broker_int_settle(
  p_attempt uuid, p_operation text, p_actual numeric, p_evidence jsonb, p_hash text,
  p_actor text, p_actor_type text, p_actor_user uuid, p_owner_path boolean)
RETURNS jsonb
LANGUAGE plpgsql SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_claim uuid; v_tenant uuid; v_key text; n integer; v_in bigint; v_cached bigint; v_out bigint; v_cost bigint;
  cl public.execution_claims; a public.execution_attempts; tf record; ev record; g public.execution_budgets;
  t public.execution_budgets; v_prov text; v_model text; v_rate text; v_other boolean := false;
  v_current boolean; v_held boolean; v_over boolean; v_late boolean := false; v_ids uuid[];
BEGIN
  SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
  IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
  SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;
  PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
  SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
  SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;

  -- Shape checks, before any mutation.
  IF p_actual IS NULL OR p_actual < 0 OR p_actual > 9007199254740991 OR p_actual <> trunc(p_actual) THEN PERFORM public.broker_int_refuse('invalid_amount'); END IF;
  IF p_operation IS NULL OR p_operation <> a.operation_id THEN PERFORM public.broker_int_refuse('operation_mismatch'); END IF;
  IF p_hash IS NULL OR p_hash = '' OR p_evidence IS NULL THEN PERFORM public.broker_int_refuse('missing_evidence'); END IF;

  -- Already settled (whatever the state): checked first, so a repeat always reaches it.
  IF a.actual_micros IS NOT NULL THEN
    IF a.actual_micros = p_actual::bigint AND a.usage_evidence_hash = p_hash THEN
      RETURN jsonb_build_object('ok', true, 'changed', false, 'actual_micros', a.actual_micros);
    END IF;
    RETURN jsonb_build_object('ok', false, 'reason', 'settlement_conflict', 'persist', true, 'tenant', v_tenant,
      'attempt', a.id, 'mode', a.mode, 'operation', a.operation_id);
  END IF;

  BEGIN
    v_in := (p_evidence ->> 'input_tokens')::bigint;
    v_cached := (p_evidence ->> 'cached_input_tokens')::bigint;
    v_out := (p_evidence ->> 'output_tokens')::bigint;
  EXCEPTION WHEN others THEN
    PERFORM public.broker_int_refuse('invalid_evidence');
  END;
  IF v_in IS NULL OR v_cached IS NULL OR v_out IS NULL OR v_in < 0 OR v_cached < 0 OR v_out < 0 OR v_cached > v_in THEN
    PERFORM public.broker_int_refuse('invalid_evidence');
  END IF;

  -- Price with the tariff the evidence names (owner path), else the attempt's bound tariff.
  v_prov := p_evidence ->> 'provider'; v_model := p_evidence ->> 'model'; v_rate := p_evidence ->> 'rate_version';
  IF v_prov IS NOT NULL OR v_model IS NOT NULL OR v_rate IS NOT NULL THEN
    SELECT * INTO tf FROM public.broker_read_tariff_by_name(v_prov, v_model, v_rate);
    IF FOUND THEN v_other := tf.id <> a.tariff_ref; END IF;
  ELSE
    SELECT * INTO tf FROM public.broker_read_tariff(a.tariff_ref);
  END IF;

  -- Eligibility: accounting is allowed for every attempt that was ever dispatched.
  IF a.dispatched_at IS NULL OR a.state IN ('claimed','released') THEN PERFORM public.broker_int_refuse('invalid_state'); END IF;

  v_current := a.attempt_no = (SELECT max(attempt_no) FROM public.execution_attempts WHERE claim_id = cl.id);

  -- Unpriceable evidence: nothing is settled and no balance moves.
  IF tf.id IS NULL THEN
    IF a.state = 'dispatched' AND v_current THEN
      UPDATE public.execution_attempts SET state = 'unknown' WHERE id = a.id;
      UPDATE public.execution_claims SET state = 'unknown', updated_at = now() WHERE id = cl.id;
      PERFORM public.broker_int_audit(v_tenant, p_actor, p_actor_type, p_actor_user, 'broker_unpriced_evidence',
        jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'evidence_hash', p_hash, 'moved_to', 'unknown'),
        'blocked', 'unpriced evidence; reservation kept', a.mode, a.operation_id);
    ELSE
      g := public.broker_int_lock_global(a.budget_period);
      t := public.broker_int_lock_tenant_budget(v_tenant, a.budget_period);
      PERFORM public.broker_int_recompute(ARRAY[g.id, t.id], true);
      PERFORM public.broker_int_audit(v_tenant, p_actor, p_actor_type, p_actor_user, 'broker_unpriced_evidence',
        jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'evidence_hash', p_hash, 'state', a.state, 'frozen', true),
        'blocked', 'unpriced evidence; period frozen', a.mode, a.operation_id);
    END IF;
    RETURN jsonb_build_object('ok', false, 'reason', 'unpriced_evidence', 'committed', true);
  END IF;

  IF tf.input_usd_per_million IS NULL OR tf.output_usd_per_million IS NULL OR tf.cached_input_usd_per_million IS NULL THEN
    PERFORM public.broker_int_refuse('invalid_tariff');
  END IF;
  v_cost := public.broker_int_cost(v_in, v_cached, v_out, tf.input_usd_per_million,
                                   tf.cached_input_usd_per_million, tf.output_usd_per_million);
  IF v_cost <> p_actual::bigint THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'amount_mismatch', 'persist', true, 'tenant', v_tenant,
      'attempt', a.id, 'mode', a.mode, 'operation', a.operation_id, 'expected', v_cost, 'got', p_actual::bigint);
  END IF;

  -- Accounting. Rows are those of the period the reservation was made in, even after a month change.
  v_held := a.state IN ('dispatched','unknown');
  v_late := a.state = 'failed';
  g := public.broker_int_lock_global(a.budget_period);
  t := public.broker_int_lock_tenant_budget(v_tenant, a.budget_period);
  v_over := p_actual::bigint > a.reserved_micros;
  UPDATE public.execution_budgets
  SET settled_micros = settled_micros + p_actual::bigint,
      reserved_micros = reserved_micros - CASE WHEN v_held THEN a.reserved_micros ELSE 0 END,
      updated_at = now()
  WHERE id IN (g.id, t.id);
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n <> 2 THEN RAISE EXCEPTION 'broker invariant: settled % budget rows', n; END IF;
  -- A settled amount above the reservation, a late charge after failed_no_charge, or evidence priced by a
  -- different tariff than the attempt's is a contract violation: freeze (RFC 5.2 item 3, A34).
  PERFORM public.broker_int_recompute(ARRAY[g.id, t.id], v_over OR v_late OR v_other);
  IF v_over OR v_late OR v_other THEN PERFORM public.broker_int_freeze_current(v_tenant, a.budget_period); END IF;

  UPDATE public.execution_attempts
  SET actual_micros = p_actual::bigint, usage_evidence_hash = p_hash, settled_at = now(),
      state = CASE WHEN a.state = 'failed' THEN 'failed' ELSE 'settled' END
  WHERE id = a.id;
  IF a.state <> 'failed' AND v_current THEN
    UPDATE public.execution_claims SET state = 'settled', updated_at = now() WHERE id = cl.id;
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n <> 1 THEN RAISE EXCEPTION 'broker invariant: claim update row count %', n; END IF;
  END IF;

  PERFORM public.broker_int_audit(v_tenant, p_actor, p_actor_type, p_actor_user,
    CASE WHEN v_late THEN 'late_charge_after_no_charge' ELSE 'broker_settle' END,
    jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'actual_micros', p_actual::bigint,
                       'reserved_micros', a.reserved_micros, 'evidence_hash', p_hash, 'overrun', v_over,
                       'other_tariff', v_other, 'owner_path', p_owner_path),
    CASE WHEN v_over OR v_late OR v_other THEN 'blocked' ELSE 'allow' END,
    CASE WHEN v_late THEN 'late charge recorded; period frozen'
         WHEN v_over THEN 'overrun settled; scope frozen' ELSE 'settled' END,
    a.mode, a.operation_id);
  RETURN jsonb_build_object('ok', true, 'changed', true, 'actual_micros', p_actual::bigint, 'frozen', v_over OR v_late OR v_other);
END
$$;

-- 5.2.3 settle. Token counts and the evidence hash come from the gateway's execution_usage row, never from the caller.
CREATE FUNCTION public.broker_settle(p_attempt uuid, p_operation_id text, p_actual numeric, p_usage_evidence text)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_exec text; v_tenant uuid; v_claim uuid; a_exec text; u public.execution_usage; r jsonb;
  v_ev jsonb; v_act text;
BEGIN
  BEGIN
    IF p_attempt IS NULL THEN PERFORM public.broker_int_refuse('invalid_input'); END IF;
    v_exec := public.broker_int_executor();
    SELECT x.claim_id, x.executor INTO v_claim, a_exec FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id INTO v_tenant FROM public.execution_claims x WHERE x.id = v_claim;
    IF NOT public.broker_int_tenant_allowed(v_tenant) THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    IF a_exec <> v_exec THEN PERFORM public.broker_int_refuse('not_owner'); END IF;
    IF p_usage_evidence IS NULL OR btrim(p_usage_evidence) = '' THEN PERFORM public.broker_int_refuse('missing_evidence'); END IF;

    SELECT * INTO u FROM public.execution_usage WHERE attempt_id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('no_usage_evidence'); END IF;
    IF u.raw_usage_hash <> p_usage_evidence THEN
      -- A repeat of an already recorded settlement with other evidence is a conflict, not a mismatch.
      IF EXISTS (SELECT 1 FROM public.execution_attempts WHERE id = p_attempt AND actual_micros IS NOT NULL) THEN
        v_ev := '{}'::jsonb;
      ELSE
        PERFORM public.broker_int_refuse('evidence_mismatch');
      END IF;
    END IF;
    v_ev := jsonb_build_object('input_tokens', u.input_tokens, 'cached_input_tokens', u.cached_input_tokens,
                               'output_tokens', u.output_tokens);
    r := public.broker_int_settle(p_attempt, p_operation_id, p_actual, v_ev, p_usage_evidence,
                                  v_exec, 'agent', NULL, false);
    IF coalesce((r ->> 'persist')::boolean, false) THEN
      -- Roll this block back (nothing was written) and record the refusal below.
      PERFORM public.broker_int_refuse(r ->> 'reason');
    END IF;
    RETURN r;
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    IF v_reason IN ('settlement_conflict','amount_mismatch') AND v_tenant IS NOT NULL THEN
      PERFORM public.broker_int_audit(v_tenant, v_exec, 'agent', NULL, 'broker_' || v_reason,
        jsonb_build_object('attempt_id', p_attempt), 'blocked', v_reason, 'shadow',
        'broker-' || v_reason || '-' || p_attempt::text);
    END IF;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- 5.2.6 resolve_unknown: owner only. settle(actual) with the owner's evidence, or failed_no_charge.
CREATE FUNCTION public.broker_resolve_unknown(p_attempt uuid, p_decision text, p_actual numeric, p_evidence jsonb)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_uid uuid; v_claim uuid; v_tenant uuid; v_key text; v_hash text; n integer; r jsonb;
  cl public.execution_claims; a public.execution_attempts; g public.execution_budgets; t public.execution_budgets;
  v_op text; v_mode text; v_cur boolean;
BEGIN
  BEGIN
    v_uid := public.broker_int_admin();
    IF p_attempt IS NULL OR p_decision IS NULL OR p_decision NOT IN ('settle','failed_no_charge') OR p_evidence IS NULL
       OR jsonb_typeof(p_evidence) <> 'object' OR p_evidence = '{}'::jsonb THEN
      PERFORM public.broker_int_refuse('invalid_input');
    END IF;
    v_hash := encode(sha256(convert_to(p_evidence::text, 'UTF8')), 'hex');
    SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;

    IF p_decision = 'settle' THEN
      SELECT x.operation_id INTO v_op FROM public.execution_attempts x WHERE x.id = p_attempt;
      r := public.broker_int_settle(p_attempt, v_op, p_actual, p_evidence, v_hash,
                                    'Platform Owner', 'human', v_uid, true);
      IF coalesce((r ->> 'persist')::boolean, false) THEN PERFORM public.broker_int_refuse(r ->> 'reason'); END IF;
      IF (r ->> 'ok')::boolean AND coalesce((r ->> 'changed')::boolean, false) THEN
        UPDATE public.execution_attempts SET resolution = 'settle', resolved_by = v_uid,
          resolution_evidence_hash = v_hash WHERE id = p_attempt;
      END IF;
      RETURN r;
    END IF;

    -- failed_no_charge: only an unknown attempt; releases the reservation; the claim becomes reclaimable.
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
    SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
    SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;
    IF a.state <> 'unknown' THEN PERFORM public.broker_int_refuse('invalid_state'); END IF;
    g := public.broker_int_lock_global(a.budget_period);
    t := public.broker_int_lock_tenant_budget(v_tenant, a.budget_period);
    UPDATE public.execution_budgets SET reserved_micros = reserved_micros - a.reserved_micros, updated_at = now()
      WHERE id IN (g.id, t.id);
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n <> 2 THEN RAISE EXCEPTION 'broker invariant: released % budget rows', n; END IF;
    UPDATE public.execution_attempts SET state = 'failed', resolution = 'failed_no_charge', resolved_by = v_uid,
      resolution_evidence_hash = v_hash WHERE id = a.id;
    v_cur := a.attempt_no = (SELECT max(attempt_no) FROM public.execution_attempts WHERE claim_id = cl.id);
    IF v_cur THEN UPDATE public.execution_claims SET state = 'failed', updated_at = now() WHERE id = cl.id; END IF;
    PERFORM public.broker_int_audit(v_tenant, 'Platform Owner', 'human', v_uid, 'broker_resolve_unknown',
      jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'decision', 'failed_no_charge',
                         'released_micros', a.reserved_micros, 'evidence_hash', v_hash),
      'allow', 'unknown attempt resolved without charge', a.mode, a.operation_id);
    RETURN jsonb_build_object('ok', true, 'changed', true);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    IF v_reason IN ('settlement_conflict','amount_mismatch') AND v_tenant IS NOT NULL THEN
      PERFORM public.broker_int_audit(v_tenant, 'Platform Owner', 'human', v_uid, 'broker_' || v_reason,
        jsonb_build_object('attempt_id', p_attempt), 'blocked', v_reason, 'shadow',
        'broker-' || v_reason || '-' || p_attempt::text);
    END IF;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- Owner reconciliation of a freeze. For the global scope p_tenant only attributes the audit row.
CREATE FUNCTION public.broker_reconcile_freeze(p_scope text, p_tenant uuid, p_period date, p_note text)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_uid uuid; b public.execution_budgets; n integer;
BEGIN
  BEGIN
    v_uid := public.broker_int_admin();
    IF p_scope IS NULL OR p_scope NOT IN ('global','tenant') OR p_tenant IS NULL OR p_period IS NULL OR p_note IS NULL OR btrim(p_note) = '' THEN
      PERFORM public.broker_int_refuse('invalid_input');
    END IF;
    IF p_scope = 'global' THEN b := public.broker_int_lock_global(p_period);
    ELSE b := public.broker_int_lock_tenant_budget(p_tenant, p_period); END IF;
    UPDATE public.execution_budgets
    SET frozen = false, overrun_micros = greatest(0, settled_micros + reserved_micros - cap_micros), updated_at = now()
    WHERE id = b.id;
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n <> 1 THEN RAISE EXCEPTION 'broker invariant: reconcile row count %', n; END IF;
    PERFORM public.broker_int_audit(p_tenant, 'Platform Owner', 'human', v_uid, 'broker_reconcile_freeze',
      jsonb_build_object('scope', p_scope, 'period', p_period, 'budget_id', b.id, 'was_frozen', b.frozen,
                         'note_hash', encode(sha256(convert_to(p_note, 'UTF8')), 'hex')),
      'allow', 'freeze reconciled by owner', 'shadow', 'broker-reconcile-' || b.id::text);
    RETURN jsonb_build_object('ok', true, 'changed', b.frozen);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- Gateway-only (RFC 5.2.2, 5.0): forward at most once, then capture the provider's own usage once.
CREATE FUNCTION public.broker_mark_forwarded(p_attempt uuid)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_claim uuid; v_tenant uuid; v_key text; cl public.execution_claims; a public.execution_attempts;
BEGIN
  BEGIN
    IF p_attempt IS NULL THEN PERFORM public.broker_int_refuse('invalid_input'); END IF;
    SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
    SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
    SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;
    IF a.state <> 'dispatched' THEN PERFORM public.broker_int_refuse('invalid_state'); END IF;
    IF a.forwarded_at IS NOT NULL THEN
      RETURN jsonb_build_object('ok', true, 'forward', false, 'operation_id', a.operation_id);
    END IF;
    UPDATE public.execution_attempts SET forwarded_at = now() WHERE id = a.id;
    PERFORM public.broker_int_audit(v_tenant, 'gateway', 'agent', NULL, 'broker_forwarded',
      jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'fence', a.fence),
      'allow', 'forwarded once', a.mode, a.operation_id);
    RETURN jsonb_build_object('ok', true, 'forward', true, 'operation_id', a.operation_id);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

CREATE FUNCTION public.broker_capture_usage(
  p_attempt uuid, p_provider_request_id text, p_input bigint, p_cached bigint, p_output bigint, p_raw_hash text)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_claim uuid; v_tenant uuid; v_key text; cl public.execution_claims; a public.execution_attempts;
  u public.execution_usage; n integer;
BEGIN
  BEGIN
    IF p_attempt IS NULL OR p_provider_request_id IS NULL OR p_input IS NULL OR p_cached IS NULL OR p_output IS NULL
       OR p_raw_hash IS NULL OR p_input < 0 OR p_cached < 0 OR p_output < 0 OR p_cached > p_input THEN
      PERFORM public.broker_int_refuse('invalid_input');
    END IF;
    SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
    SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
    SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;
    IF a.state <> 'dispatched' OR a.forwarded_at IS NULL THEN PERFORM public.broker_int_refuse('invalid_state'); END IF;
    INSERT INTO public.execution_usage (attempt_id, provider_request_id, input_tokens, cached_input_tokens, output_tokens, raw_usage_hash)
    VALUES (p_attempt, p_provider_request_id, p_input, p_cached, p_output, p_raw_hash)
    ON CONFLICT (attempt_id) DO NOTHING;
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n = 1 THEN
      PERFORM public.broker_int_audit(v_tenant, 'gateway', 'agent', NULL, 'broker_usage_captured',
        jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'raw_usage_hash', p_raw_hash),
        'allow', 'usage captured', a.mode, a.operation_id);
      RETURN jsonb_build_object('ok', true, 'created', true);
    END IF;
    SELECT * INTO u FROM public.execution_usage WHERE attempt_id = p_attempt;
    IF (u.provider_request_id, u.input_tokens, u.cached_input_tokens, u.output_tokens, u.raw_usage_hash)
       IS NOT DISTINCT FROM (p_provider_request_id, p_input, p_cached, p_output, p_raw_hash) THEN
      RETURN jsonb_build_object('ok', true, 'created', false);
    END IF;
    PERFORM public.broker_int_refuse('usage_conflict');
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    IF v_reason = 'usage_conflict' THEN
      PERFORM public.broker_int_audit(v_tenant, 'gateway', 'agent', NULL, 'broker_usage_conflict',
        jsonb_build_object('attempt_id', p_attempt), 'blocked', 'usage conflict', 'shadow',
        'broker-usage-conflict-' || p_attempt::text);
    END IF;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- Caller failure finalization (ACP manager `markFailed`): verification rejected the result, or the work was
-- stopped. Idempotent for an attempt already failed. What it charges depends on whether the provider was reached:
--   never forwarded by the gateway (claimed, or dispatched/unknown without forwarded_at): no charge, reservation
--   released;
--   forwarded with captured usage: the measured cost is settled exactly as broker_settle would, then the attempt
--   is failed;
--   forwarded with a zero reservation (free tariff): no charge;
--   forwarded without usage and a non-zero reservation: refused (usage_pending), nothing changes; the attempt
--   stays for broker_settle after capture, or for the owner via mark_unknown + broker_resolve_unknown.
-- A failed claim is reclaimable (takeover mints the next fence), like released.
CREATE FUNCTION public.broker_mark_failed(p_attempt uuid, p_fence bigint, p_reason text)
RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_exec text; v_claim uuid; v_tenant uuid; v_key text; n integer; r jsonb; v_cost bigint;
  v_charge bigint := 0; v_settled boolean := false; cl public.execution_claims; a public.execution_attempts; u public.execution_usage;
  tf record; g public.execution_budgets; t public.execution_budgets;
BEGIN
  BEGIN
    IF p_attempt IS NULL OR p_fence IS NULL THEN PERFORM public.broker_int_refuse('invalid_input'); END IF;
    v_exec := public.broker_int_executor();
    SELECT x.claim_id INTO v_claim FROM public.execution_attempts x WHERE x.id = p_attempt;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT x.tenant_id, x.command_key INTO v_tenant, v_key FROM public.execution_claims x WHERE x.id = v_claim;
    IF NOT public.broker_int_tenant_allowed(v_tenant) THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    PERFORM pg_advisory_xact_lock(public.broker_int_claim_key(v_tenant, v_key));
    SELECT * INTO cl FROM public.execution_claims WHERE id = v_claim FOR UPDATE;
    SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt FOR UPDATE;
    IF a.executor <> v_exec THEN PERFORM public.broker_int_refuse('not_owner'); END IF;
    IF p_fence <> a.fence THEN RETURN jsonb_build_object('ok', false, 'reason', 'stale'); END IF;
    -- Replay: already failed (by this RPC or the owner), even after a takeover moved the claim's fence on.
    IF a.state = 'failed' THEN RETURN jsonb_build_object('ok', true, 'changed', false); END IF;
    IF p_fence <> cl.fence THEN RETURN jsonb_build_object('ok', false, 'reason', 'stale'); END IF;
    IF a.state NOT IN ('claimed','dispatched','unknown') THEN PERFORM public.broker_int_refuse('invalid_state'); END IF;

    IF a.forwarded_at IS NOT NULL THEN
      SELECT * INTO u FROM public.execution_usage WHERE attempt_id = a.id;
      IF FOUND THEN
        SELECT * INTO tf FROM public.broker_read_tariff(a.tariff_ref);
        v_cost := public.broker_int_cost(u.input_tokens, u.cached_input_tokens, u.output_tokens,
                    tf.input_usd_per_million, tf.cached_input_usd_per_million, tf.output_usd_per_million);
        r := public.broker_int_settle(a.id, a.operation_id, v_cost,
               jsonb_build_object('input_tokens', u.input_tokens, 'cached_input_tokens', u.cached_input_tokens,
                                  'output_tokens', u.output_tokens),
               u.raw_usage_hash, v_exec, 'agent', NULL, false);
        IF NOT coalesce((r ->> 'ok')::boolean, false) THEN PERFORM public.broker_int_refuse(coalesce(r ->> 'reason', 'settle_refused')); END IF;
        v_charge := v_cost; v_settled := true;
      ELSIF a.reserved_micros > 0 THEN
        PERFORM public.broker_int_refuse('usage_pending');
      END IF;
    END IF;

    IF NOT v_settled THEN
      -- No charge: hand the whole reservation back (a settlement above already released it).
      g := public.broker_int_lock_global(a.budget_period);
      t := public.broker_int_lock_tenant_budget(v_tenant, a.budget_period);
      UPDATE public.execution_budgets SET reserved_micros = reserved_micros - a.reserved_micros, updated_at = now()
        WHERE id IN (g.id, t.id);
      GET DIAGNOSTICS n = ROW_COUNT;
      IF n <> 2 THEN RAISE EXCEPTION 'broker invariant: released % budget rows', n; END IF;
    END IF;
    UPDATE public.execution_attempts SET state = 'failed' WHERE id = a.id;
    UPDATE public.execution_claims SET state = 'failed', updated_at = now() WHERE id = cl.id;
    PERFORM public.broker_int_audit(v_tenant, v_exec, 'agent', NULL, 'broker_mark_failed',
      jsonb_build_object('claim_id', cl.id, 'attempt_id', a.id, 'fence', a.fence, 'from_state', a.state,
                         'charged_micros', v_charge, 'reserved_micros', a.reserved_micros,
                         'reason', left(coalesce(p_reason, ''), 80)),
      'allow', 'attempt failed', a.mode, a.operation_id);
    RETURN jsonb_build_object('ok', true, 'changed', true, 'charged_micros', v_charge);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- Read-only status of a claim's latest attempt, for restart recovery (ACP manager `claimStatus`). Takes no lock
-- and writes nothing; the caller decides what to do with the state. Same audience and refusals as the
-- lifecycle RPCs: the session's executor must own the latest attempt and the claim's tenant must be in its claims.
CREATE FUNCTION public.broker_claim_status(p_claim uuid)
RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE
  v_reason text; v_exec text; cl public.execution_claims; a public.execution_attempts;
BEGIN
  BEGIN
    IF p_claim IS NULL THEN PERFORM public.broker_int_refuse('invalid_input'); END IF;
    v_exec := public.broker_int_executor();
    SELECT * INTO cl FROM public.execution_claims WHERE id = p_claim;
    IF NOT FOUND OR NOT public.broker_int_tenant_allowed(cl.tenant_id) THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    SELECT * INTO a FROM public.execution_attempts WHERE claim_id = cl.id ORDER BY attempt_no DESC LIMIT 1;
    IF NOT FOUND THEN PERFORM public.broker_int_refuse('not_found'); END IF;
    IF a.executor <> v_exec THEN PERFORM public.broker_int_refuse('not_owner'); END IF;
    IF a.fence <> cl.fence THEN RAISE EXCEPTION 'broker invariant: claim % fence % <> latest attempt fence %', cl.id, cl.fence, a.fence; END IF;
    RETURN jsonb_build_object('ok', true, 'claim_id', cl.id, 'attempt_id', a.id, 'attempt_no', a.attempt_no,
                              'fence', a.fence, 'operation_id', a.operation_id, 'state', a.state);
  EXCEPTION WHEN SQLSTATE 'BRK01' THEN
    GET STACKED DIAGNOSTICS v_reason = MESSAGE_TEXT;
    RETURN jsonb_build_object('ok', false, 'reason', v_reason);
  END;
END
$$;

-- ---------------------------------------------------------------------------------------------------------
-- 6. Ownership and grants. Three RPC groups plus the owner-recovery pair (RFC 5.0).
-- ---------------------------------------------------------------------------------------------------------
ALTER FUNCTION public.broker_record_command(uuid, text, text, text, uuid, integer, integer, integer) OWNER TO broker_owner;
ALTER FUNCTION public.broker_claim_and_reserve(uuid, text, uuid, uuid, integer, integer, integer) OWNER TO broker_owner;
ALTER FUNCTION public.broker_mark_dispatched(uuid, bigint) OWNER TO broker_owner;
ALTER FUNCTION public.broker_mark_unknown(uuid, bigint) OWNER TO broker_owner;
ALTER FUNCTION public.broker_release(uuid, bigint, text) OWNER TO broker_owner;
ALTER FUNCTION public.broker_int_settle(uuid, text, numeric, jsonb, text, text, text, uuid, boolean) OWNER TO broker_owner;
ALTER FUNCTION public.broker_settle(uuid, text, numeric, text) OWNER TO broker_owner;
ALTER FUNCTION public.broker_resolve_unknown(uuid, text, numeric, jsonb) OWNER TO broker_owner;
ALTER FUNCTION public.broker_reconcile_freeze(text, uuid, date, text) OWNER TO broker_owner;
ALTER FUNCTION public.broker_mark_forwarded(uuid) OWNER TO broker_owner;
ALTER FUNCTION public.broker_capture_usage(uuid, text, bigint, bigint, bigint, text) OWNER TO broker_owner;
ALTER FUNCTION public.broker_claim_status(uuid) OWNER TO broker_owner;
ALTER FUNCTION public.broker_mark_failed(uuid, bigint, text) OWNER TO broker_owner;

REVOKE EXECUTE ON FUNCTION
  public.broker_int_refuse(text), public.broker_int_claims(), public.broker_int_executor(),
  public.broker_int_tenant_allowed(uuid), public.broker_int_period(), public.broker_int_claim_key(uuid, text),
  public.broker_int_cost(bigint, bigint, bigint, numeric, numeric, numeric),
  public.broker_int_worst_case(bigint, bigint, bigint, numeric, numeric, numeric), public.broker_int_admin(),
  public.broker_int_lock_global(date), public.broker_int_lock_tenant_budget(uuid, date),
  public.broker_int_audit(uuid, text, text, uuid, text, jsonb, text, text, text, text),
  public.broker_int_recompute(uuid[], boolean), public.broker_int_freeze_current(uuid, date),
  public.broker_int_settle(uuid, text, numeric, jsonb, text, text, text, uuid, boolean)
  FROM PUBLIC, anon, authenticated, service_role, broker_caller, broker_intake, broker_gateway;

REVOKE EXECUTE ON FUNCTION
  public.broker_record_command(uuid, text, text, text, uuid, integer, integer, integer),
  public.broker_claim_and_reserve(uuid, text, uuid, uuid, integer, integer, integer),
  public.broker_mark_dispatched(uuid, bigint), public.broker_mark_unknown(uuid, bigint),
  public.broker_release(uuid, bigint, text), public.broker_settle(uuid, text, numeric, text),
  public.broker_resolve_unknown(uuid, text, numeric, jsonb), public.broker_reconcile_freeze(text, uuid, date, text),
  public.broker_mark_forwarded(uuid), public.broker_capture_usage(uuid, text, bigint, bigint, bigint, text),
  public.broker_claim_status(uuid), public.broker_mark_failed(uuid, bigint, text)
  FROM PUBLIC, anon, authenticated, service_role, broker_caller, broker_intake, broker_gateway;

-- Ordinary broker RPCs: the ACP and Eve servers (broker_caller) only.
GRANT EXECUTE ON FUNCTION
  public.broker_claim_and_reserve(uuid, text, uuid, uuid, integer, integer, integer),
  public.broker_mark_dispatched(uuid, bigint), public.broker_mark_unknown(uuid, bigint),
  public.broker_release(uuid, bigint, text), public.broker_settle(uuid, text, numeric, text),
  public.broker_claim_status(uuid), public.broker_mark_failed(uuid, bigint, text)
  TO broker_caller;
-- Intake: the ACP intake job only.
GRANT EXECUTE ON FUNCTION
  public.broker_record_command(uuid, text, text, text, uuid, integer, integer, integer) TO broker_intake;
-- Egress gateway: forward-once and usage capture only.
GRANT EXECUTE ON FUNCTION
  public.broker_mark_forwarded(uuid), public.broker_capture_usage(uuid, text, bigint, bigint, bigint, text)
  TO broker_gateway;
-- Owner recovery: reachable by a signed-in user, then refused inside unless is_platform_admin().
GRANT EXECUTE ON FUNCTION
  public.broker_resolve_unknown(uuid, text, numeric, jsonb), public.broker_reconcile_freeze(text, uuid, date, text)
  TO authenticated;

COMMENT ON TABLE public.execution_budgets IS
  'ARN-88: micro-USD budget per scope and UTC month. Written only by broker RPCs. Rows are created by the owner; none are seeded, so every claim is refused until the owner creates them. At a cap of 0 only zero-cost (free-tariff) claims pass.';
COMMENT ON FUNCTION public.broker_claim_and_reserve(uuid, text, uuid, uuid, integer, integer, integer) IS
  'ARN-88: atomic claim + budget reservation (RFC 5.2.1). Returns jsonb {ok, ...}. Source only; not applied anywhere.';
