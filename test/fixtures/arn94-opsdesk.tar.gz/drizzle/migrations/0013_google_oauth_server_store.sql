-- Native Google OAuth Stage 3 server-side store.
-- This migration is intentionally safe to re-run after a partial failure.

ALTER TABLE public.real_data_sources
  ADD COLUMN IF NOT EXISTS authorized_account_email text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'real_data_sources_gmail_authorized_account'
  ) THEN
    ALTER TABLE public.real_data_sources
      ADD CONSTRAINT real_data_sources_gmail_authorized_account
      CHECK (
        provider <> 'gmail'
        OR NOT approved
        OR (
          authorized_account_email IS NOT NULL
          AND authorized_account_email ~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'
        )
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'real_data_sources_gmail_exact_authorized_scope'
  ) THEN
    ALTER TABLE public.real_data_sources
      ADD CONSTRAINT real_data_sources_gmail_exact_authorized_scope
      CHECK (
        provider <> 'gmail'
        OR NOT approved
        OR (
          requested_scopes = ARRAY['https://www.googleapis.com/auth/gmail.readonly']::text[]
          AND write_scope_enabled = false
        )
      );
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.gmail_authorized_account_guard()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF OLD.provider = 'gmail'
     AND OLD.connection_status = 'connected'
     AND NEW.authorized_account_email IS DISTINCT FROM OLD.authorized_account_email THEN
    RAISE EXCEPTION 'disconnect Gmail before changing the authorized mailbox';
  END IF;
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS gmail_authorized_account_guard ON public.real_data_sources;
CREATE TRIGGER gmail_authorized_account_guard
BEFORE UPDATE ON public.real_data_sources
FOR EACH ROW
EXECUTE FUNCTION public.gmail_authorized_account_guard();

CREATE TABLE IF NOT EXISTS public.google_oauth_states (
  state_hash text PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  pkce_verifier_cipher jsonb NOT NULL,
  redirect_uri text NOT NULL CHECK (redirect_uri ~ '^https://'),
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  CONSTRAINT google_oauth_state_ttl CHECK (
    expires_at > created_at
    AND expires_at <= created_at + interval '15 minutes'
  )
);

ALTER TABLE public.google_oauth_states ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.google_oauth_states FROM PUBLIC, anon, authenticated;
GRANT ALL ON public.google_oauth_states TO service_role;
CREATE INDEX IF NOT EXISTS google_oauth_states_expiry_idx
  ON public.google_oauth_states (expires_at);

CREATE TABLE IF NOT EXISTS public.google_oauth_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'gmail' CHECK (provider = 'gmail'),
  authorized_user_id uuid NOT NULL,
  google_subject text,
  account_email text,
  granted_scopes text[] NOT NULL,
  refresh_token_cipher jsonb NOT NULL,
  connected_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz,
  last_refresh_at timestamptz,
  UNIQUE (tenant_id, provider),
  CONSTRAINT google_oauth_exact_scope CHECK (
    granted_scopes = ARRAY['https://www.googleapis.com/auth/gmail.readonly']::text[]
  )
);

ALTER TABLE public.google_oauth_credentials ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.google_oauth_credentials FROM PUBLIC, anon, authenticated;
GRANT ALL ON public.google_oauth_credentials TO service_role;

CREATE OR REPLACE FUNCTION public.google_oauth_credentials_guard()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.granted_scopes <> ARRAY['https://www.googleapis.com/auth/gmail.readonly']::text[] THEN
    RAISE EXCEPTION 'only exact gmail.readonly scope is allowed';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS google_oauth_credentials_guard ON public.google_oauth_credentials;
CREATE TRIGGER google_oauth_credentials_guard
BEFORE INSERT OR UPDATE ON public.google_oauth_credentials
FOR EACH ROW
EXECUTE FUNCTION public.google_oauth_credentials_guard();

CREATE OR REPLACE VIEW public.google_oauth_connection_metadata
WITH (security_invoker = true)
AS
SELECT
  id,
  tenant_id,
  provider,
  authorized_user_id,
  google_subject,
  account_email,
  granted_scopes,
  connected_at,
  updated_at,
  revoked_at,
  last_refresh_at
FROM public.google_oauth_credentials;

REVOKE ALL ON public.google_oauth_connection_metadata FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.google_oauth_connection_metadata TO service_role;
