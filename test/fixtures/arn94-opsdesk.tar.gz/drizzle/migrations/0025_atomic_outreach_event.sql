-- Atomically record owner-observed outreach events, prospect state, opt-out
-- suppression and platform audit evidence. No email is sent by this function.

CREATE OR REPLACE FUNCTION public.record_owner_outreach_event(
  p_prospect uuid,
  p_event_type text,
  p_minutes integer,
  p_note text DEFAULT NULL,
  p_intake_submission uuid DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_prospect public.platform_prospects%ROWTYPE;
  v_event_id uuid;
  v_stage text;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_platform_admin() THEN
    RAISE EXCEPTION 'forbidden: platform owner only';
  END IF;

  IF p_event_type NOT IN ('reviewed','skipped','manually_sent','reply_received','positive_reply','booked','won','lost','opt_out') THEN
    RAISE EXCEPTION 'unsupported outreach event type';
  END IF;
  IF p_minutes IS NULL OR p_minutes < 0 OR p_minutes > 600 THEN
    RAISE EXCEPTION 'minutes must be between 0 and 600';
  END IF;
  IF p_event_type = 'lost' AND nullif(trim(coalesce(p_note,'')), '') IS NULL THEN
    RAISE EXCEPTION 'loss reason required';
  END IF;

  SELECT * INTO v_prospect
  FROM public.platform_prospects
  WHERE id = p_prospect
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'prospect not found';
  END IF;

  IF p_event_type = 'opt_out' AND v_prospect.email IS NULL AND v_prospect.domain IS NULL THEN
    RAISE EXCEPTION 'prospect has no email/domain to suppress';
  END IF;

  INSERT INTO public.platform_outreach_events (
    prospect_id,event_type,minutes_spent,note,intake_submission_id,created_by
  ) VALUES (
    v_prospect.id,p_event_type,p_minutes,p_note,p_intake_submission,auth.uid()
  )
  RETURNING id INTO v_event_id;

  IF p_event_type = 'opt_out' THEN
    IF v_prospect.email IS NOT NULL THEN
      INSERT INTO public.platform_suppressions (email,reason,source,created_by)
      VALUES (lower(v_prospect.email),'opt_out','prospect reply (recorded by owner)',auth.uid())
      ON CONFLICT DO NOTHING;
    ELSE
      INSERT INTO public.platform_suppressions (domain,reason,source,created_by)
      VALUES (lower(v_prospect.domain),'opt_out','prospect reply (recorded by owner)',auth.uid())
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  v_stage := CASE p_event_type
    WHEN 'manually_sent' THEN 'contacted'
    WHEN 'reply_received' THEN 'replied'
    WHEN 'positive_reply' THEN 'replied'
    WHEN 'booked' THEN 'discovery'
    WHEN 'won' THEN 'won'
    WHEN 'lost' THEN 'lost'
    ELSE NULL
  END;

  UPDATE public.platform_prospects
  SET stage = COALESCE(v_stage, stage),
      loss_reason = CASE WHEN p_event_type = 'lost' THEN p_note ELSE loss_reason END,
      last_touch_at = CASE WHEN p_event_type = 'manually_sent' THEN now() ELSE last_touch_at END,
      intake_submission_id = COALESCE(p_intake_submission, intake_submission_id),
      updated_at = now()
  WHERE id = v_prospect.id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'prospect update matched no row';
  END IF;

  INSERT INTO public.platform_audit_events (
    actor_user_id,action,entity,entity_id,inputs,outcome,side_effect
  ) VALUES (
    auth.uid(),
    'outreach_' || p_event_type || '_recorded',
    'platform_prospects',
    v_prospect.id,
    jsonb_build_object('minutes',p_minutes,'intake',p_intake_submission,'event_id',v_event_id),
    CASE WHEN p_event_type = 'manually_sent'
      THEN 'recorded; sent outside Arnexyia by owner'
      ELSE 'recorded'
    END,
    'none'
  );

  RETURN v_event_id;
END
$$;

REVOKE ALL ON FUNCTION public.record_owner_outreach_event(uuid,text,integer,text,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.record_owner_outreach_event(uuid,text,integer,text,uuid) TO authenticated;

COMMENT ON FUNCTION public.record_owner_outreach_event(uuid,text,integer,text,uuid) IS
  'Owner-only record of externally observed outreach activity. Event, suppression, prospect state and audit evidence are atomic. Never sends email.';
