GRANT SELECT, UPDATE ON public.setup_checklist TO authenticated;
GRANT ALL ON public.setup_checklist TO service_role;
ALTER TABLE public.setup_checklist ENABLE ROW LEVEL SECURITY;
CREATE POLICY setup_checklist_select ON public.setup_checklist FOR SELECT TO authenticated
  USING (tenant_id IS NULL AND public.is_platform_admin() OR tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id));
CREATE POLICY setup_checklist_update ON public.setup_checklist FOR UPDATE TO authenticated
  USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
COMMENT ON FUNCTION public.run_shadow_suite(uuid) IS 'DEPRECATED: always-pass wiring stub. The app uses the deterministic TypeScript engine (runShadowSuite server function) instead.';