-- ARN-67: a newly provisioned customer tenant must get the canonical onboarding steps
-- and real-data source records that the tenant-bound readiness gate requires.
-- Migration 0007 seeded them only for tenants that existed at the time, and
-- provision_tenant (0018) never created them, so a new customer had no completion path.
--
-- Everything seeded here is unapproved: steps are 'pending', sources are not approved,
-- not connected, not tested, have no client authorization, and stay 'unclassified'.
-- Nothing here records client consent or promotes any readiness flag.

CREATE OR REPLACE FUNCTION public.seed_tenant_onboarding_prerequisites(p_tenant uuid)
RETURNS void LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF p_tenant IS NULL OR NOT EXISTS (SELECT 1 FROM public.tenants WHERE id = p_tenant) THEN
    RAISE EXCEPTION 'unknown tenant';
  END IF;

  -- Canonical steps; must match the 0007 seed exactly.
  INSERT INTO public.onboarding_steps (tenant_id, step_order, step_key, label, external_authorization)
  SELECT p_tenant, s.o, s.k, s.l, s.ext FROM (VALUES
    (1,'discovery','Discovery call completed',false),
    (2,'baseline_captured','Baseline metrics captured with evidence',false),
    (3,'contract_signed_externally','Contract reviewed by counsel and signed externally (no in-app signing)',true),
    (4,'tenant_provisioned','Tenant provisioned (shadow, live off)',false),
    (5,'authority_matrix_approved','Authority matrix approved in writing by client',true),
    (6,'read_only_scopes_authorized','Read-only scopes authorized by client',true),
    (7,'synthetic_suite_passed','Synthetic shadow suite passed all gates',false),
    (8,'real_agent_suite_passed','Real-agent shadow suite passed all gates',false),
    (9,'real_data_shadow_started','Real-data read-only shadow started',false),
    (10,'shadow_review_complete','Shadow review completed with client',true),
    (11,'per_capability_live_approval','Per-capability live approval signed (each capability separately)',true)
  ) AS s(o,k,l,ext)
  ON CONFLICT (tenant_id, step_key) DO NOTHING;

  -- Canonical sources; must match the 0007 seed exactly. Approval/connection fields are
  -- spelled out so a later column default change cannot silently approve anything.
  INSERT INTO public.real_data_sources (tenant_id, provider, optional, required_scopes, requested_scopes,
    authorization_basis, approved, connection_status, connection_test_status, write_scope_enabled)
  SELECT p_tenant, p.provider, p.optional, p.scopes, '{}'::text[],
    'unclassified', false, 'not_connected', 'not_tested', false
  FROM (VALUES
    ('gmail', false, ARRAY['https://www.googleapis.com/auth/gmail.readonly']),
    ('google_calendar', false, ARRAY['https://www.googleapis.com/auth/calendar.readonly']),
    ('crm', false, ARRAY['contacts:read','deals:read']),
    ('google_drive', true, ARRAY['https://www.googleapis.com/auth/drive.readonly'])
  ) AS p(provider, optional, scopes)
  ON CONFLICT (tenant_id, provider) DO NOTHING;
END $$;

-- Internal helper: only reachable through provision_tenant (SECURITY DEFINER) or a migration.
REVOKE ALL ON FUNCTION public.seed_tenant_onboarding_prerequisites(uuid) FROM PUBLIC, anon, authenticated, service_role;

-- Same as 0018 except for the PERFORM before the audit row.
CREATE OR REPLACE FUNCTION public.provision_tenant(p_name text, p_slug text, p_industry text, p_timezone text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE new_id uuid; tpl uuid;
BEGIN
  IF NOT public.is_platform_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF p_slug !~ '^[a-z0-9][a-z0-9-]{2,48}$' THEN RAISE EXCEPTION 'invalid slug'; END IF;
  IF length(trim(coalesce(p_name,''))) < 2 THEN RAISE EXCEPTION 'invalid name'; END IF;
  SELECT id INTO tpl FROM public.tenants WHERE tenant_kind = 'synthetic_seed' ORDER BY created_at LIMIT 1;
  IF tpl IS NULL THEN RAISE EXCEPTION 'provisioning template missing'; END IF;

  INSERT INTO public.tenants(name, slug, industry, status, health, mode, timezone, tenant_kind)
  VALUES (trim(p_name), p_slug, p_industry, 'onboarding', 'unknown', 'shadow',
          coalesce(nullif(p_timezone,''),'America/New_York'), 'customer')
  RETURNING id INTO new_id;

  INSERT INTO public.authority_policies(tenant_id, capability, risk, live_enabled, requires_secondary_validation,
    amount_threshold_cents, permitted_domains, permitted_recipients, rate_limit_per_hour, min_confidence, notes)
  SELECT new_id, capability, risk, false, requires_secondary_validation, amount_threshold_cents,
    '{}'::text[], '{}'::text[], rate_limit_per_hour, min_confidence, 'Default matrix; domains must be set per client.'
  FROM public.authority_policies WHERE tenant_id = tpl;

  INSERT INTO public.integrations(tenant_id, provider, category, status, circuit_open, failure_count, required_credentials, setup_notes)
  SELECT new_id, provider, category, 'not_configured', false, 0, required_credentials, setup_notes
  FROM public.integrations WHERE tenant_id = tpl;

  INSERT INTO public.channel_capabilities(tenant_id, channel, research_enabled, draft_enabled, asset_ready, api_connected, publish_enabled, setup_notes)
  SELECT new_id, channel, research_enabled, draft_enabled, false, false, false, 'Not connected.'
  FROM public.channel_capabilities WHERE tenant_id = tpl;

  INSERT INTO public.setup_checklist(tenant_id, item_key, label, category, required_for, status, owner_action_required, notes)
  SELECT DISTINCT ON (item_key) new_id, item_key, label, category, required_for, 'pending', owner_action_required, notes
  FROM public.setup_checklist WHERE tenant_id = tpl ORDER BY item_key;

  INSERT INTO public.billing_accounts(tenant_id, plan, mrr_cents, status, is_placeholder)
  VALUES (new_id, 'unassigned', 0, 'placeholder', true);

  INSERT INTO public.memberships(tenant_id, user_id, role) VALUES (new_id, auth.uid(), 'owner_admin');

  PERFORM public.seed_tenant_onboarding_prerequisites(new_id);

  INSERT INTO public.audit_events(tenant_id, actor, actor_type, actor_user_id, action, inputs, decision, policy_rule,
    intended_side_effect, outcome, mode, correlation_key)
  VALUES (new_id, 'Platform Owner', 'human', auth.uid(), 'provision_tenant',
    jsonb_build_object('name', p_name, 'slug', p_slug, 'tenant_kind', 'customer'), 'allow', 'owner_provisioning',
    'none — internal records only; no external accounts or credentials', 'customer tenant provisioned in shadow mode', 'shadow', 'provision-' || new_id);
  RETURN new_id;
END $$;

-- Backfill customer tenants provisioned after 0007 that never got these rows.
-- Idempotent: existing rows (and any progress on them) are left untouched.
DO $$
DECLARE t uuid;
BEGIN
  FOR t IN SELECT id FROM public.tenants WHERE tenant_kind = 'customer' ORDER BY created_at LOOP
    PERFORM public.seed_tenant_onboarding_prerequisites(t);
  END LOOP;
END $$;
