-- B) prompt/agent versions (immutable)
CREATE TABLE public.prompt_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prompt_key text NOT NULL,
  version text NOT NULL,
  agent_role text NOT NULL,
  prompt_text text NOT NULL,
  prompt_hash text NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (prompt_key, version)
);
GRANT SELECT, INSERT ON public.prompt_versions TO authenticated;
GRANT ALL ON public.prompt_versions TO service_role;
ALTER TABLE public.prompt_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY prompt_versions_select ON public.prompt_versions FOR SELECT TO authenticated USING (public.is_platform_admin());
CREATE POLICY prompt_versions_insert ON public.prompt_versions FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());

CREATE OR REPLACE FUNCTION public.forbid_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION '% rows are immutable', TG_TABLE_NAME; END $$;
CREATE TRIGGER prompt_versions_immutable BEFORE UPDATE OR DELETE ON public.prompt_versions FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

-- B) explicit, versioned cost rates (no values seeded)
CREATE TABLE public.model_cost_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  model text NOT NULL,
  rate_version text NOT NULL,
  input_usd_per_million numeric(12,6) NOT NULL,
  output_usd_per_million numeric(12,6) NOT NULL,
  cached_input_usd_per_million numeric(12,6),
  source_note text NOT NULL,
  effective_from timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, model, rate_version)
);
GRANT SELECT, INSERT ON public.model_cost_rates TO authenticated;
GRANT ALL ON public.model_cost_rates TO service_role;
ALTER TABLE public.model_cost_rates ENABLE ROW LEVEL SECURITY;
CREATE POLICY model_cost_rates_select ON public.model_cost_rates FOR SELECT TO authenticated USING (public.is_platform_admin());
CREATE POLICY model_cost_rates_insert ON public.model_cost_rates FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());
CREATE TRIGGER model_cost_rates_immutable BEFORE UPDATE OR DELETE ON public.model_cost_rates FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

-- B) per-request model usage
CREATE TABLE public.model_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  workflow_key text NOT NULL,
  suite_run_id uuid,
  test_case_id uuid,
  provider text NOT NULL,
  model text NOT NULL,
  prompt_version text NOT NULL,
  policy_version text NOT NULL,
  status text NOT NULL,
  input_tokens integer,
  output_tokens integer,
  cached_input_tokens integer,
  reasoning_tokens integer,
  total_tokens integer,
  latency_ms integer,
  refusal text,
  error text,
  provider_response_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX model_usage_tenant_idx ON public.model_usage(tenant_id, created_at DESC);
GRANT SELECT, INSERT ON public.model_usage TO authenticated;
GRANT ALL ON public.model_usage TO service_role;
ALTER TABLE public.model_usage ENABLE ROW LEVEL SECURITY;
CREATE POLICY model_usage_select ON public.model_usage FOR SELECT TO authenticated USING (public.is_platform_admin());
CREATE POLICY model_usage_insert ON public.model_usage FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());
CREATE TRIGGER model_usage_immutable BEFORE UPDATE OR DELETE ON public.model_usage FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

-- A) distinguish synthetic vs real-agent runs
ALTER TABLE public.test_runs
  ADD COLUMN engine_kind text NOT NULL DEFAULT 'synthetic_deterministic',
  ADD COLUMN model text,
  ADD COLUMN prompt_version text,
  ADD COLUMN policy_version text,
  ADD COLUMN model_output jsonb;
CREATE INDEX test_runs_kind_idx ON public.test_runs(tenant_id, engine_kind, ran_at DESC);

-- C) funnel / attribution
ALTER TABLE public.intake_submissions
  ADD COLUMN utm_source text, ADD COLUMN utm_medium text, ADD COLUMN utm_campaign text,
  ADD COLUMN utm_content text, ADD COLUMN utm_term text,
  ADD COLUMN referrer text, ADD COLUMN landing_path text,
  ADD COLUMN stage text NOT NULL DEFAULT 'new',
  ADD COLUMN qualified boolean NOT NULL DEFAULT false,
  ADD COLUMN loss_reason text, ADD COLUMN owner_notes text,
  ADD COLUMN client_fingerprint text,
  ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.intake_submissions ADD CONSTRAINT intake_stage_chk
  CHECK (stage IN ('new','qualified','discovery','proposal','negotiation','won','lost'));
DROP POLICY IF EXISTS intake_insert_anon ON public.intake_submissions;
DROP POLICY IF EXISTS intake_insert_auth ON public.intake_submissions;
REVOKE INSERT ON public.intake_submissions FROM anon;
GRANT UPDATE ON public.intake_submissions TO authenticated;
CREATE POLICY intake_update_admin ON public.intake_submissions FOR UPDATE TO authenticated
  USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
CREATE INDEX intake_email_idx ON public.intake_submissions(lower(email), created_at DESC);

-- E) approval integrity
ALTER TABLE public.proposed_actions
  ADD COLUMN proposal_version integer NOT NULL DEFAULT 1,
  ADD COLUMN payload_fingerprint text,
  ADD COLUMN policy_version text;
UPDATE public.proposed_actions SET payload_fingerprint = encode(sha256(convert_to(payload::text,'UTF8')),'hex') WHERE payload_fingerprint IS NULL;

ALTER TABLE public.approvals
  ADD COLUMN proposal_version integer,
  ADD COLUMN payload_fingerprint text,
  ADD COLUMN policy_version text,
  ADD COLUMN invalidated_at timestamptz,
  ADD COLUMN invalidated_reason text;

CREATE OR REPLACE FUNCTION public.proposed_action_fingerprint() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    NEW.proposal_version := 1;
    NEW.payload_fingerprint := encode(sha256(convert_to(NEW.payload::text,'UTF8')),'hex');
  ELSIF NEW.payload IS DISTINCT FROM OLD.payload OR NEW.action_type IS DISTINCT FROM OLD.action_type
        OR NEW.capability IS DISTINCT FROM OLD.capability THEN
    NEW.proposal_version := OLD.proposal_version + 1;
    NEW.payload_fingerprint := encode(sha256(convert_to(NEW.payload::text,'UTF8')),'hex');
    UPDATE public.approvals SET invalidated_at = now(), invalidated_reason = 'proposal changed after approval'
      WHERE proposed_action_id = NEW.id AND invalidated_at IS NULL;
  ELSE
    NEW.proposal_version := OLD.proposal_version;
    NEW.payload_fingerprint := OLD.payload_fingerprint;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER proposed_actions_fingerprint BEFORE INSERT OR UPDATE ON public.proposed_actions
  FOR EACH ROW EXECUTE FUNCTION public.proposed_action_fingerprint();

CREATE OR REPLACE FUNCTION public.approval_binding_check() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE pa record;
BEGIN
  SELECT tenant_id, proposal_version, payload_fingerprint INTO pa FROM public.proposed_actions WHERE id = NEW.proposed_action_id;
  IF pa IS NULL THEN RAISE EXCEPTION 'proposal not found'; END IF;
  IF pa.tenant_id <> NEW.tenant_id THEN RAISE EXCEPTION 'approval tenant mismatch'; END IF;
  IF NEW.payload_fingerprint IS NULL OR NEW.proposal_version IS NULL
     OR NEW.payload_fingerprint <> pa.payload_fingerprint OR NEW.proposal_version <> pa.proposal_version THEN
    RAISE EXCEPTION 'approval must reference the current proposal version and payload fingerprint';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER approvals_binding BEFORE INSERT ON public.approvals FOR EACH ROW EXECUTE FUNCTION public.approval_binding_check();

-- D) atomic tenant provisioning (owner only, no external calls)
CREATE OR REPLACE FUNCTION public.provision_tenant(p_name text, p_slug text, p_industry text, p_timezone text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE new_id uuid; tpl uuid;
BEGIN
  IF NOT public.is_platform_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF p_slug !~ '^[a-z0-9][a-z0-9-]{2,48}$' THEN RAISE EXCEPTION 'invalid slug'; END IF;
  IF length(trim(coalesce(p_name,''))) < 2 THEN RAISE EXCEPTION 'invalid name'; END IF;
  SELECT id INTO tpl FROM public.tenants ORDER BY created_at LIMIT 1;

  INSERT INTO public.tenants(name, slug, industry, status, health, mode, timezone)
  VALUES (trim(p_name), p_slug, p_industry, 'onboarding', 'unknown', 'shadow', coalesce(nullif(p_timezone,''),'America/Chicago'))
  RETURNING id INTO new_id;

  INSERT INTO public.authority_policies(tenant_id, capability, risk, live_enabled, requires_secondary_validation,
    amount_threshold_cents, permitted_domains, permitted_recipients, rate_limit_per_hour, min_confidence, notes)
  SELECT new_id, capability, risk, false, requires_secondary_validation, amount_threshold_cents,
    '{}'::text[], '{}'::text[], rate_limit_per_hour, min_confidence, 'Default matrix; domains must be set per client.'
  FROM public.authority_policies WHERE tenant_id = tpl;

  INSERT INTO public.integrations(tenant_id, provider, category, status, circuit_open, failure_count, required_credentials, setup_notes)
  SELECT new_id, provider, category, 'not_configured', false, 0, required_credentials, setup_notes
  FROM public.integrations WHERE tenant_id = tpl;

  INSERT INTO public.channel_capabilities(tenant_id, channel, research_enabled, draft_enabled, asset_ready, api_connected, publish_enabled, setup_notes)
  SELECT new_id, channel, research_enabled, draft_enabled, false, false, false, 'Not connected.'
  FROM public.channel_capabilities WHERE tenant_id = tpl;

  INSERT INTO public.setup_checklist(tenant_id, item_key, label, category, required_for, status, owner_action_required, notes)
  SELECT DISTINCT ON (item_key) new_id, item_key, label, category, required_for, 'pending', owner_action_required, notes
  FROM public.setup_checklist WHERE tenant_id = tpl ORDER BY item_key;

  INSERT INTO public.billing_accounts(tenant_id, plan, mrr_cents, status, is_placeholder)
  VALUES (new_id, 'unassigned', 0, 'placeholder', true);

  INSERT INTO public.memberships(tenant_id, user_id, role) VALUES (new_id, auth.uid(), 'owner_admin');

  INSERT INTO public.audit_events(tenant_id, actor, actor_type, actor_user_id, action, inputs, decision, policy_rule,
    intended_side_effect, outcome, mode, correlation_key)
  VALUES (new_id, 'Platform Owner', 'human', auth.uid(), 'provision_tenant',
    jsonb_build_object('name', p_name, 'slug', p_slug), 'allow', 'owner_provisioning',
    'none — internal records only; no external accounts or credentials', 'tenant provisioned in shadow mode', 'shadow', 'provision-' || new_id);
  RETURN new_id;
END $$;
REVOKE ALL ON FUNCTION public.provision_tenant(text,text,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.provision_tenant(text,text,text,text) TO authenticated;