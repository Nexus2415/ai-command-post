-- Least-privilege hardening for internal public-schema functions.
-- None of these functions are intended as unauthenticated RPC endpoints.
-- Preserve authenticated/service_role compatibility; remove PUBLIC/anon execution.

-- SECURITY DEFINER trigger functions.
REVOKE EXECUTE ON FUNCTION public.approval_binding_check() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.approval_binding_check() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.audit_platform_row() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.audit_platform_row() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.audit_retention_change() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.audit_retention_change() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.audit_row_change() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.audit_row_change() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.outreach_event_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.outreach_event_guard() TO authenticated, service_role;

-- Internal trigger/guard functions.
REVOKE EXECUTE ON FUNCTION public.forbid_mutation() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.forbid_mutation() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.gmail_authorized_account_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.gmail_authorized_account_guard() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.google_oauth_credentials_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.google_oauth_credentials_guard() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.onboarding_order_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.onboarding_order_guard() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.proposal_version_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.proposal_version_guard() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.proposed_action_fingerprint() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.proposed_action_fingerprint() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.real_data_source_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.real_data_source_guard() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.runtime_job_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.runtime_job_guard() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.support_ticket_guard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.support_ticket_guard() TO authenticated, service_role;

-- Internal helper/RPC functions used only after authentication.
REVOKE EXECUTE ON FUNCTION public.count_recent_action_attempts(uuid, text, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.count_recent_action_attempts(uuid, text, timestamptz) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.is_arnexyia_read_only_scope(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_arnexyia_read_only_scope(text) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.run_shadow_suite(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.run_shadow_suite(uuid) TO authenticated, service_role;
