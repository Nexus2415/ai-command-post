-- Store platform-level provider credentials in Supabase Vault instead of relying
-- exclusively on deployment-provider runtime secret configuration.
--
-- SECURITY:
-- - Vault keeps secret values encrypted at rest using the project's managed root key.
-- - The functions below are callable only by service_role.
-- - Authenticated/anon/public callers cannot read or write secret values directly.

CREATE OR REPLACE FUNCTION public.platform_secret_get(p_name text)
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = pg_catalog, vault
AS $$
  SELECT decrypted_secret
  FROM vault.decrypted_secrets
  WHERE name = p_name
  LIMIT 1
$$;

CREATE OR REPLACE FUNCTION public.platform_secret_exists(p_name text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = pg_catalog, vault
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM vault.secrets
    WHERE name = p_name
  )
$$;

CREATE OR REPLACE FUNCTION public.platform_secret_put(
  p_name text,
  p_secret text,
  p_description text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, vault
AS $$
DECLARE
  v_id uuid;
BEGIN
  IF nullif(trim(coalesce(p_name, '')), '') IS NULL THEN
    RAISE EXCEPTION 'secret name required';
  END IF;
  IF nullif(p_secret, '') IS NULL THEN
    RAISE EXCEPTION 'secret value required';
  END IF;

  SELECT id INTO v_id
  FROM vault.secrets
  WHERE name = p_name
  LIMIT 1;

  IF v_id IS NULL THEN
    SELECT vault.create_secret(p_secret, p_name, p_description) INTO v_id;
  ELSE
    PERFORM vault.update_secret(v_id, p_secret, p_name, p_description);
  END IF;

  RETURN v_id;
END
$$;

REVOKE ALL ON FUNCTION public.platform_secret_get(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.platform_secret_exists(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.platform_secret_put(text, text, text) FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.platform_secret_get(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.platform_secret_exists(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.platform_secret_put(text, text, text) TO service_role;

COMMENT ON FUNCTION public.platform_secret_get(text) IS
  'Service-role-only retrieval of an encrypted Supabase Vault secret.';
COMMENT ON FUNCTION public.platform_secret_exists(text) IS
  'Service-role-only existence check that never returns a secret value.';
COMMENT ON FUNCTION public.platform_secret_put(text, text, text) IS
  'Service-role-only create/update of a Supabase Vault secret.';
