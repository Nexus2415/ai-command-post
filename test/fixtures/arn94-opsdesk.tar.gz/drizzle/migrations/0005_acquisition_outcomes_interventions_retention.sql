-- ===== Platform acquisition (owner-only; separate from tenant CRM) =====
CREATE TABLE public.platform_prospects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company text NOT NULL,
  contact_name text,
  email text,
  website text,
  domain text,
  trade text,
  geography text,
  source text NOT NULL,
  source_url text,
  evidence text,
  fit_score integer CHECK (fit_score IS NULL OR fit_score BETWEEN 0 AND 100),
  fit_reasons text[] NOT NULL DEFAULT '{}',
  employee_estimate text,
  employee_estimate_source text,
  employee_estimate_uncertainty text,
  stage text NOT NULL DEFAULT 'researched' CHECK (stage IN ('researched','qualified','draft_ready','contacted','replied','discovery','proposal','won','lost')),
  loss_reason text,
  last_touch_at timestamptz,
  next_action text,
  owner_notes text,
  intake_submission_id uuid REFERENCES public.intake_submissions(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.platform_outreach_sequences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  version integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','retired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (name, version)
);
CREATE TABLE public.platform_outreach_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sequence_id uuid NOT NULL REFERENCES public.platform_outreach_sequences(id),
  step_number integer NOT NULL,
  channel text NOT NULL DEFAULT 'email' CHECK (channel IN ('email','phone','linkedin_manual')),
  wait_days integer NOT NULL DEFAULT 0,
  subject_template text,
  body_template text NOT NULL,
  personalization_fields text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','retired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (sequence_id, step_number)
);
CREATE TABLE public.platform_outreach_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospect_id uuid NOT NULL REFERENCES public.platform_prospects(id),
  step_id uuid REFERENCES public.platform_outreach_steps(id),
  event_type text NOT NULL CHECK (event_type IN ('drafted','reviewed','suppressed','skipped','manually_sent','reply_received','positive_reply','opt_out','booked','won','lost')),
  subject text,
  body text,
  omitted_fields text[] NOT NULL DEFAULT '{}',
  minutes_spent integer NOT NULL DEFAULT 0 CHECK (minutes_spent >= 0),
  note text,
  intake_submission_id uuid REFERENCES public.intake_submissions(id),
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE public.platform_outreach_events IS 'No autonomous send event exists by design; manually_sent records an owner action outside OpsDesk.';
CREATE TABLE public.platform_suppressions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text,
  domain text,
  reason text NOT NULL,
  source text NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (email IS NOT NULL OR domain IS NOT NULL)
);
CREATE UNIQUE INDEX platform_suppressions_email_uq ON public.platform_suppressions (lower(email)) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX platform_suppressions_domain_uq ON public.platform_suppressions (lower(domain)) WHERE domain IS NOT NULL AND email IS NULL;
CREATE TABLE public.platform_acquisition_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period_start date NOT NULL,
  period_end date NOT NULL,
  category text NOT NULL,
  amount_cents bigint NOT NULL CHECK (amount_cents >= 0),
  evidence text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.is_prospect_suppressed(p_prospect uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.platform_prospects p JOIN public.platform_suppressions s
      ON (s.email IS NOT NULL AND lower(s.email) = lower(p.email))
      OR (s.domain IS NOT NULL AND s.email IS NULL AND (
            lower(s.domain) = lower(p.domain) OR lower(s.domain) = lower(split_part(coalesce(p.email,''), '@', 2))))
    WHERE p.id = p_prospect);
$$;

CREATE OR REPLACE FUNCTION public.outreach_event_guard()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.event_type IN ('drafted','reviewed','manually_sent') AND public.is_prospect_suppressed(NEW.prospect_id) THEN
    RAISE EXCEPTION 'prospect is suppressed; drafting and outreach are blocked';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER outreach_event_guard BEFORE INSERT ON public.platform_outreach_events
  FOR EACH ROW EXECUTE FUNCTION public.outreach_event_guard();

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['platform_prospects','platform_outreach_sequences','platform_outreach_steps','platform_outreach_events','platform_suppressions','platform_acquisition_costs'] LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (public.is_platform_admin())', t || '_owner_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin())', t || '_owner_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin())', t || '_owner_update', t);
  END LOOP;
END $$;
-- Events are append-only.
REVOKE UPDATE ON public.platform_outreach_events FROM authenticated;

-- ===== Tenant outcome evidence =====
CREATE TABLE public.outcome_metric_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  metric_key text NOT NULL,
  label text NOT NULL,
  unit text NOT NULL,
  better_direction text NOT NULL DEFAULT 'lower' CHECK (better_direction IN ('lower','higher')),
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, metric_key)
);
CREATE TABLE public.outcome_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  metric_id uuid NOT NULL REFERENCES public.outcome_metric_definitions(id),
  period_kind text NOT NULL CHECK (period_kind IN ('baseline','current')),
  period_start date NOT NULL,
  period_end date NOT NULL,
  value numeric NOT NULL,
  evidence_source text NOT NULL,
  confidence text NOT NULL DEFAULT 'low' CHECK (confidence IN ('low','medium','high')),
  data_quality_note text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (period_end >= period_start)
);
CREATE TABLE public.outcome_economic_assumptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  metric_id uuid NOT NULL REFERENCES public.outcome_metric_definitions(id),
  usd_cents_per_unit bigint NOT NULL,
  client_provided boolean NOT NULL DEFAULT false,
  evidence text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ===== Human intervention burden =====
CREATE TABLE public.human_interventions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  event_type text NOT NULL CHECK (event_type IN ('approval_review','exception_resolution','correction','manual_execution','client_support','setup')),
  workflow_key text,
  proposed_action_id uuid REFERENCES public.proposed_actions(id),
  exception_id uuid REFERENCES public.exceptions(id),
  minutes_spent integer NOT NULL CHECK (minutes_spent >= 0),
  reason text NOT NULL,
  cause text NOT NULL CHECK (cause IN ('required_by_risk_tier','model_failure','workflow_failure','integration_failure','client_request','other')),
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['outcome_metric_definitions','outcome_observations','outcome_economic_assumptions','human_interventions'] LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (public.is_tenant_member(tenant_id))', t || '_member_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (public.is_tenant_editor(tenant_id))', t || '_editor_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (public.is_tenant_editor(tenant_id)) WITH CHECK (public.is_tenant_editor(tenant_id))', t || '_editor_update', t);
  END LOOP;
END $$;
CREATE INDEX human_interventions_tenant_idx ON public.human_interventions (tenant_id, created_at DESC);
CREATE INDEX outcome_observations_metric_idx ON public.outcome_observations (metric_id, period_kind);

-- ===== Retention placeholders (no automatic deletion) =====
CREATE TABLE public.retention_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL UNIQUE,
  description text NOT NULL,
  retention_days integer,
  status text NOT NULL DEFAULT 'tbd' CHECK (status IN ('tbd','approved')),
  auto_delete_enabled boolean NOT NULL DEFAULT false CHECK (auto_delete_enabled = false),
  notes text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE public.retention_policies IS 'Placeholder. Nothing deletes data automatically; auto_delete_enabled is constrained false.';
GRANT SELECT, UPDATE ON public.retention_policies TO authenticated;
GRANT ALL ON public.retention_policies TO service_role;
ALTER TABLE public.retention_policies ENABLE ROW LEVEL SECURITY;
CREATE POLICY retention_owner_select ON public.retention_policies FOR SELECT TO authenticated USING (public.is_platform_admin() OR public.has_role(auth.uid(),'auditor'));
CREATE POLICY retention_owner_update ON public.retention_policies FOR UPDATE TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());