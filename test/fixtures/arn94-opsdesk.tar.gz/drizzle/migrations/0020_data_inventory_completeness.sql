-- Make data-inventory drift visible and fail closed.
-- Every public application table must be represented. Newly discovered tables
-- are added conservatively as personal/unclassified until explicitly reviewed.

INSERT INTO public.data_inventory (
  table_name,
  data_category,
  contains_personal_data,
  tenant_scoped,
  retention_category,
  subprocessors,
  notes
)
SELECT
  t.table_name,
  'Unclassified application data — review required',
  true,
  EXISTS (
    SELECT 1
    FROM information_schema.columns c
    WHERE c.table_schema = 'public'
      AND c.table_name = t.table_name
      AND c.column_name = 'tenant_id'
  ),
  'unclassified',
  ARRAY['Lovable Cloud (Supabase)']::text[],
  'Migration 0020: auto-added conservatively because this public table was missing from the data inventory. Review classification before first-customer readiness.'
FROM information_schema.tables t
WHERE t.table_schema = 'public'
  AND t.table_type = 'BASE TABLE'
ON CONFLICT (table_name) DO NOTHING;

CREATE OR REPLACE FUNCTION public.data_inventory_status()
RETURNS TABLE (
  total_public_tables integer,
  inventoried_tables integer,
  missing_tables text[],
  unclassified_tables text[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL
     OR NOT (public.is_platform_admin() OR public.has_role(auth.uid(), 'auditor')) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  RETURN QUERY
  WITH public_tables AS (
    SELECT t.table_name::text
    FROM information_schema.tables t
    WHERE t.table_schema = 'public'
      AND t.table_type = 'BASE TABLE'
  ),
  missing AS (
    SELECT p.table_name
    FROM public_tables p
    LEFT JOIN public.data_inventory d ON d.table_name = p.table_name
    WHERE d.table_name IS NULL
  ),
  unclassified AS (
    SELECT d.table_name
    FROM public.data_inventory d
    WHERE d.retention_category = 'unclassified'
       OR d.data_category = 'Unclassified application data — review required'
  )
  SELECT
    (SELECT count(*)::integer FROM public_tables),
    (SELECT count(*)::integer FROM public.data_inventory),
    COALESCE((SELECT array_agg(m.table_name ORDER BY m.table_name) FROM missing m), ARRAY[]::text[]),
    COALESCE((SELECT array_agg(u.table_name ORDER BY u.table_name) FROM unclassified u), ARRAY[]::text[]);
END
$$;

REVOKE ALL ON FUNCTION public.data_inventory_status() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.data_inventory_status() TO authenticated;

COMMENT ON FUNCTION public.data_inventory_status() IS
  'Owner/auditor-only completeness check for the public-table data inventory. Unclassified rows block commercial readiness.';
