-- ---------- generic audit trigger for tenant-scoped control tables ----------
CREATE OR REPLACE FUNCTION public.audit_row_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.audit_events(tenant_id, actor, actor_type, actor_user_id, action, inputs, decision, policy_rule, intended_side_effect, outcome, mode)
  VALUES (NEW.tenant_id, coalesce((SELECT email FROM public.profiles WHERE id = auth.uid()), 'system'),
          CASE WHEN auth.uid() IS NULL THEN 'system' ELSE 'human' END, auth.uid(),
          TG_TABLE_NAME || '_' || lower(TG_OP), to_jsonb(NEW), 'allow', 'internal_record_change',
          'none — internal record only', 'recorded', 'shadow');
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.flag_on(p_key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce((SELECT bool_value FROM public.system_flags WHERE key = p_key), false);
$$;

-- ---------- 1. outcome framework (extends existing tables) ----------
ALTER TABLE public.outcome_observations
  ADD COLUMN IF NOT EXISTS is_synthetic boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS evidence_ref text,
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS verified boolean NOT NULL DEFAULT false;
CREATE OR REPLACE VIEW public.baseline_metrics WITH (security_invoker = true) AS
  SELECT d.*, o.id AS observation_id, o.value, o.period_start, o.period_end, o.evidence_source, o.evidence_ref, o.is_synthetic, o.verified
  FROM public.outcome_metric_definitions d JOIN public.outcome_observations o ON o.metric_id = d.id AND o.period_kind = 'baseline';
CREATE OR REPLACE VIEW public.metric_observations WITH (security_invoker = true) AS
  SELECT * FROM public.outcome_observations;
GRANT SELECT ON public.baseline_metrics, public.metric_observations TO authenticated;

-- ---------- 2. customer success ----------
CREATE TABLE public.client_health_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  rule_version text NOT NULL,
  setup_completeness_pct numeric,
  exception_burden numeric,
  workflow_failure_rate numeric,
  intervention_minutes_30d integer,
  unresolved_incidents integer,
  activity_count_30d integer,
  billing_status text NOT NULL DEFAULT 'placeholder',
  renewal_risk text NOT NULL CHECK (renewal_risk IN ('green','yellow','red','insufficient_data')),
  reasons jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.renewal_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  renewal_date date,
  status text NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming','in_discussion','renewed_externally','not_renewing','churned')),
  churn_reason text,
  owner_notes text,
  contract_reference text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT renewal_churn_reason CHECK (status NOT IN ('not_renewing','churned') OR churn_reason IS NOT NULL)
);
COMMENT ON TABLE public.renewal_records IS 'No automatic contract acceptance: renewed_externally records an owner-confirmed signature made outside OpsDesk.';
ALTER TABLE public.offboarding_plans ADD COLUMN IF NOT EXISTS churn_reason text;

-- ---------- 3. support tickets ----------
CREATE TABLE public.support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  category text NOT NULL CHECK (category IN ('routine','workflow_failure','data_issue','suspected_security_incident','financial_legal')),
  severity text NOT NULL DEFAULT 'sev3' CHECK (severity IN ('sev1','sev2','sev3','sev4')),
  risk risk_level NOT NULL DEFAULT 'green',
  human_only boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','triaged','in_progress','waiting_client','resolved','closed')),
  title text NOT NULL,
  description text,
  owner_user_id uuid,
  linked_workflow_run_id uuid REFERENCES public.workflow_runs(id),
  linked_integration_id uuid REFERENCES public.integrations(id),
  linked_exception_id uuid REFERENCES public.exceptions(id),
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE OR REPLACE FUNCTION public.support_ticket_guard()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.category IN ('suspected_security_incident','financial_legal') THEN
    NEW.risk := 'red'; NEW.human_only := true;
    IF NEW.category = 'suspected_security_incident' AND NEW.severity IN ('sev3','sev4') THEN NEW.severity := 'sev2'; END IF;
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF OLD.human_only AND NOT NEW.human_only THEN RAISE EXCEPTION 'human_only cannot be cleared'; END IF;
    NEW.updated_at := now();
    IF NEW.status IN ('resolved','closed') AND OLD.status NOT IN ('resolved','closed') THEN NEW.resolved_at := now(); END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER support_ticket_guard BEFORE INSERT OR UPDATE ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.support_ticket_guard();

-- ---------- 4. retention / data requests ----------
ALTER TABLE public.retention_policies ADD COLUMN IF NOT EXISTS tenant_id uuid REFERENCES public.tenants(id);
ALTER TABLE public.retention_policies DROP CONSTRAINT IF EXISTS retention_policies_category_key;
CREATE UNIQUE INDEX IF NOT EXISTS retention_policies_scope_uq ON public.retention_policies (coalesce(tenant_id, '00000000-0000-0000-0000-000000000000'::uuid), category);
CREATE POLICY retention_member_select ON public.retention_policies FOR SELECT TO authenticated USING (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id));
CREATE POLICY retention_owner_insert ON public.retention_policies FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin());
GRANT INSERT ON public.retention_policies TO authenticated;
INSERT INTO public.retention_policies (tenant_id, category, description, notes)
SELECT t.id, r.category, r.description, 'TBD / not approved' FROM public.tenants t CROSS JOIN public.retention_policies r WHERE r.tenant_id IS NULL
ON CONFLICT DO NOTHING;

CREATE TABLE public.data_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  request_type text NOT NULL CHECK (request_type IN ('export','access','correction','deletion')),
  data_categories text[] NOT NULL DEFAULT '{}',
  requester text NOT NULL,
  details text,
  status text NOT NULL DEFAULT 'received' CHECK (status IN ('received','in_review','plan_drafted','plan_approved','completed_manually','rejected')),
  plan jsonb NOT NULL DEFAULT '{}'::jsonb,
  approved_by uuid,
  approved_at timestamptz,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT data_request_plan_nondestructive CHECK (coalesce((plan->>'auto_execute')::boolean, false) = false)
);
COMMENT ON TABLE public.data_requests IS 'Record/plan only. Nothing executes deletion; completed_manually is recorded by a human after out-of-band action.';

-- ---------- 5. real-data shadow sources ----------
CREATE TABLE public.real_data_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  provider text NOT NULL CHECK (provider IN ('gmail','google_calendar','crm','google_drive')),
  crm_name text,
  optional boolean NOT NULL DEFAULT false,
  required_scopes text[] NOT NULL DEFAULT '{}',
  requested_scopes text[] NOT NULL DEFAULT '{}',
  client_authorization_date date,
  authorization_doc_ref text,
  approved boolean NOT NULL DEFAULT false,
  connection_status text NOT NULL DEFAULT 'not_connected' CHECK (connection_status IN ('not_connected','connected')),
  connection_test_status text NOT NULL DEFAULT 'not_tested' CHECK (connection_test_status IN ('not_tested','passed_read_only','failed')),
  write_scope_enabled boolean NOT NULL DEFAULT false,
  connection_verified_by text,
  last_tested_at timestamptz,
  notes text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, provider),
  CONSTRAINT rds_approval_needs_authorization CHECK (NOT approved OR (client_authorization_date IS NOT NULL AND authorization_doc_ref IS NOT NULL)),
  CONSTRAINT rds_connected_needs_approval CHECK (connection_status = 'not_connected' OR approved),
  CONSTRAINT rds_not_plugin_state CHECK (connection_verified_by IS NULL OR connection_verified_by NOT ILIKE '%chatgpt%' AND connection_verified_by NOT ILIKE '%plugin%')
);
CREATE OR REPLACE FUNCTION public.real_data_source_guard()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM unnest(NEW.requested_scopes) s
             WHERE s !~* '(readonly|read\.only|\.read$|:read$|read_only)') THEN
    NEW.write_scope_enabled := true;
  END IF;
  IF NEW.connection_status = 'connected' AND NEW.connection_verified_by IS NULL THEN
    RAISE EXCEPTION 'connected requires a verified OpsDesk-side connection (none exists yet)';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER real_data_source_guard BEFORE INSERT OR UPDATE ON public.real_data_sources FOR EACH ROW EXECUTE FUNCTION public.real_data_source_guard();
INSERT INTO public.real_data_sources (tenant_id, provider, optional, required_scopes)
SELECT t.id, p.provider, p.optional, p.scopes FROM public.tenants t CROSS JOIN (VALUES
  ('gmail', false, ARRAY['https://www.googleapis.com/auth/gmail.readonly']),
  ('google_calendar', false, ARRAY['https://www.googleapis.com/auth/calendar.readonly']),
  ('crm', false, ARRAY['contacts:read','deals:read']),
  ('google_drive', true, ARRAY['https://www.googleapis.com/auth/drive.readonly'])
) AS p(provider, optional, scopes);

-- ---------- 6. runtime outbox + observability ----------
CREATE TABLE public.runtime_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  workflow_key text NOT NULL,
  idempotency_key text NOT NULL,
  mode exec_mode NOT NULL DEFAULT 'shadow',
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','running','succeeded','failed','dead_lettered','cancelled')),
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  max_attempts integer NOT NULL DEFAULT 3 CHECK (max_attempts BETWEEN 1 AND 10),
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  dead_lettered boolean NOT NULL DEFAULT false,
  last_error text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  correlation_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, idempotency_key)
);
CREATE OR REPLACE FUNCTION public.runtime_job_guard()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.mode = 'live' AND NOT public.flag_on('limited_live_ready') THEN
    RAISE EXCEPTION 'live jobs refused: limited_live_ready is false';
  END IF;
  IF NEW.attempts >= NEW.max_attempts AND NEW.status = 'failed' THEN
    NEW.status := 'dead_lettered'; NEW.dead_lettered := true;
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER runtime_job_guard BEFORE INSERT OR UPDATE ON public.runtime_jobs FOR EACH ROW EXECUTE FUNCTION public.runtime_job_guard();
CREATE INDEX runtime_jobs_due_idx ON public.runtime_jobs (status, next_attempt_at);

CREATE TABLE public.observability_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id),
  severity text NOT NULL CHECK (severity IN ('debug','info','warning','error','critical')),
  category text NOT NULL,
  correlation_id text,
  message text NOT NULL,
  context jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX observability_events_idx ON public.observability_events (created_at DESC);

-- ---------- 7. economics ----------
CREATE TABLE public.tenant_economics_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  period_month date NOT NULL,
  category text NOT NULL CHECK (category IN ('mrr_contracted','setup_fee','credit','model_api_cost','support_labor_minutes','contractor_cost','payment_fee','ad_attribution_cost')),
  amount_cents bigint,
  minutes integer,
  is_actual boolean NOT NULL DEFAULT false,
  evidence text NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT econ_value_shape CHECK ((category = 'support_labor_minutes' AND minutes IS NOT NULL AND minutes >= 0 AND amount_cents IS NULL)
                                  OR (category <> 'support_labor_minutes' AND amount_cents IS NOT NULL AND minutes IS NULL))
);
ALTER TABLE public.platform_acquisition_costs
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS campaign text,
  ADD COLUMN IF NOT EXISTS prospect_id uuid REFERENCES public.platform_prospects(id),
  ADD COLUMN IF NOT EXISTS intake_submission_id uuid REFERENCES public.intake_submissions(id);

-- ---------- 8. onboarding ----------
CREATE TABLE public.onboarding_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id),
  step_order integer NOT NULL,
  step_key text NOT NULL,
  label text NOT NULL,
  manual_only boolean NOT NULL DEFAULT true,
  external_authorization boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','blocked')),
  evidence_ref text,
  completed_by uuid,
  completed_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, step_key),
  CONSTRAINT onboarding_external_needs_evidence CHECK (NOT external_authorization OR status <> 'done' OR evidence_ref IS NOT NULL)
);
CREATE OR REPLACE FUNCTION public.onboarding_order_guard()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'done' AND EXISTS (SELECT 1 FROM public.onboarding_steps
      WHERE tenant_id = NEW.tenant_id AND step_order < NEW.step_order AND status <> 'done') THEN
    RAISE EXCEPTION 'earlier onboarding steps must be completed first';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER onboarding_order_guard BEFORE UPDATE ON public.onboarding_steps FOR EACH ROW EXECUTE FUNCTION public.onboarding_order_guard();
INSERT INTO public.onboarding_steps (tenant_id, step_order, step_key, label, external_authorization)
SELECT t.id, s.o, s.k, s.l, s.ext FROM public.tenants t CROSS JOIN (VALUES
  (1,'discovery','Discovery call completed',false),
  (2,'baseline_captured','Baseline metrics captured with evidence',false),
  (3,'contract_signed_externally','Contract reviewed by counsel and signed externally (no in-app signing)',true),
  (4,'tenant_provisioned','Tenant provisioned (shadow, live off)',false),
  (5,'authority_matrix_approved','Authority matrix approved in writing by client',true),
  (6,'read_only_scopes_authorized','Read-only scopes authorized by client',true),
  (7,'synthetic_suite_passed','Synthetic shadow suite passed all gates',false),
  (8,'real_agent_suite_passed','Real-agent shadow suite passed all gates',false),
  (9,'real_data_shadow_started','Real-data read-only shadow started',false),
  (10,'shadow_review_complete','Shadow review completed with client',true),
  (11,'per_capability_live_approval','Per-capability live approval signed (each capability separately)',true)
) AS s(o,k,l,ext);

INSERT INTO public.system_flags (key, bool_value, text_value) VALUES ('limited_live_ready', false, 'Stage 4 gate; set only when all limited-live requirements are met')
ON CONFLICT (key) DO NOTHING;

-- ---------- grants + RLS ----------
DO $$ DECLARE t text; BEGIN
  -- owner-write, member-read
  FOREACH t IN ARRAY ARRAY['client_health_snapshots','real_data_sources','onboarding_steps','observability_events'] LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (public.is_platform_admin() OR (tenant_id IS NOT NULL AND public.is_tenant_member(tenant_id)))', t||'_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin())', t||'_owner_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin())', t||'_owner_update', t);
  END LOOP;
  -- owner-only
  FOREACH t IN ARRAY ARRAY['renewal_records','runtime_jobs','tenant_economics_entries'] LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (public.is_platform_admin())', t||'_owner_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin())', t||'_owner_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin())', t||'_owner_update', t);
  END LOOP;
  -- member-read, editor-create, owner-update
  FOREACH t IN ARRAY ARRAY['support_tickets','data_requests'] LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (public.is_tenant_member(tenant_id))', t||'_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (public.is_tenant_editor(tenant_id))', t||'_editor_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin())', t||'_owner_update', t);
  END LOOP;
  -- audit every change
  FOREACH t IN ARRAY ARRAY['client_health_snapshots','renewal_records','support_tickets','data_requests','real_data_sources','runtime_jobs','tenant_economics_entries','onboarding_steps','outcome_observations'] LOOP
    EXECUTE format('CREATE TRIGGER %I AFTER INSERT OR UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.audit_row_change()', t||'_audit', t);
  END LOOP;
END $$;
-- nothing in these tables is deletable by app users
REVOKE DELETE ON public.data_requests, public.support_tickets, public.retention_policies FROM authenticated;