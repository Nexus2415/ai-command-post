-- Least-privilege hardening for SECURITY DEFINER helper functions.
-- RLS policies that depend on these helpers are authenticated-only.
-- Remove default PUBLIC/anon RPC execution while preserving authenticated + service_role.

REVOKE EXECUTE ON FUNCTION public.flag_on(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.flag_on(text) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.is_platform_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_platform_admin() TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.is_tenant_editor(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_tenant_editor(uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.is_tenant_member(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_tenant_member(uuid) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.can_manage_invite(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_manage_invite(uuid, public.app_role) TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.is_prospect_suppressed(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_prospect_suppressed(uuid) TO authenticated, service_role;
