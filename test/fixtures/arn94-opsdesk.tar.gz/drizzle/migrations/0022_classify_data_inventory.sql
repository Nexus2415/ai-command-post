-- Classify the fail-closed data-inventory backlog using table/schema purpose.
-- This is an engineering taxonomy only. It does not approve retention periods,
-- legal basis, DPA coverage, or pilot readiness. Auto-added rows remain
-- conservative on contains_personal_data unless separately reviewed.

WITH classifications(table_name, data_category, retention_category, subprocessors) AS (
  VALUES
    ('approvals','Human approval decisions and evidence','audit_evidence',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('authority_policies','Tenant authority and execution policy configuration','workflow_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('channel_capabilities','Tenant channel capability configuration','workflow_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('client_health_snapshots','Client health and renewal-risk operational snapshots','support',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('commercial_evidence','Commercial readiness evidence references','commercial',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('content_metrics','Content performance metrics','content',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('data_inventory','Compliance data inventory metadata','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('data_requests','Privacy/data request workflow records','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('exceptions','Workflow exception evidence and resolution records','audit_evidence',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('google_oauth_credentials','Encrypted provider credentials and connection identity metadata','provider_credentials',ARRAY['Lovable Cloud (Supabase)','Google (Gmail / Calendar / Drive)']::text[]),
    ('google_oauth_states','Ephemeral OAuth state and encrypted PKCE verifier records','provider_credentials',ARRAY['Lovable Cloud (Supabase)','Google (Gmail / Calendar / Drive)']::text[]),
    ('human_interventions','Human intervention effort and cause records','workflow_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('integrations','Tenant integration configuration and health metadata','workflow_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('memberships','Tenant access-control memberships','access_control',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('model_cost_rates','Model provider cost-rate reference data','usage_metering',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('observability_events','Runtime observability and diagnostic events','observability',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('offboarding_plans','Tenant offboarding workflow and evidence','onboarding_offboarding',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('onboarding_steps','Tenant onboarding workflow and evidence','onboarding_offboarding',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('outbound_preflight_results','Outbound safety preflight evidence','audit_evidence',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('outcome_economic_assumptions','Client-provided outcome economic assumptions','outcome_measurement',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('outcome_metric_definitions','Pilot outcome metric definitions','outcome_measurement',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('outcome_observations','Pilot outcome observations and evidence','outcome_measurement',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_acquisition_costs','Platform acquisition cost records','commercial',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_audit_events','Platform-level audit evidence','audit_evidence',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_outreach_events','Prospect outreach activity records','sales_prospecting',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_outreach_sequences','Prospect outreach sequence definitions','sales_prospecting',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_outreach_steps','Prospect outreach step templates','sales_prospecting',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_recipient_blocks','Recipient/domain outbound block records','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_sender_config','Platform sender identity/compliance configuration','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_suppressions','Prospect suppression and opt-out records','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('platform_unsubscribe_tokens','Hashed unsubscribe token records','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('profiles','Authenticated user profile metadata','access_control',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('prompt_versions','Versioned agent prompt configuration','workflow_records',ARRAY['Lovable Cloud (Supabase)','OpenAI']::text[]),
    ('prospect_discovery_answers','Prospect discovery evidence','sales_prospecting',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('prospect_qualifications','Prospect qualification evidence','sales_prospecting',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('real_data_sources','Provider authorization provenance and connection metadata','provider_credentials',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('reliability_events','Integration/runtime reliability incidents','observability',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('renewal_records','Customer renewal and churn records','commercial',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('retention_policies','Retention policy configuration metadata','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('runtime_jobs','Durable runtime job state and bounded payload','workflow_records',ARRAY['Lovable Cloud (Supabase)','Inngest']::text[]),
    ('setup_checklist','Tenant setup readiness records','onboarding_offboarding',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('subprocessors','Subprocessor compliance register','compliance',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('system_flags','Platform safety/release configuration flags','workflow_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('tasks','Tenant operational task records','tenant_operational_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('tenant_economics_entries','Tenant delivery economics evidence','commercial',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('tenants','Tenant account and operational configuration','tenant_operational_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('test_cases','Synthetic/adversarial safety test definitions','audit_evidence',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('test_runs','Synthetic/real-agent safety test evidence','audit_evidence',ARRAY['Lovable Cloud (Supabase)','OpenAI']::text[]),
    ('user_roles','Platform access-control roles','access_control',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('workflow_runs','Durable workflow run state and evidence','workflow_records',ARRAY['Lovable Cloud (Supabase)']::text[]),
    ('workflows','Tenant workflow definitions','workflow_records',ARRAY['Lovable Cloud (Supabase)']::text[])
)
UPDATE public.data_inventory d
SET data_category = c.data_category,
    retention_category = c.retention_category,
    subprocessors = c.subprocessors,
    notes = concat_ws(E'\n', nullif(d.notes, ''),
      'Migration 0022: engineering classification applied from reviewed table/schema purpose. contains_personal_data remains conservative until separate field-level review.')
FROM classifications c
WHERE d.table_name = c.table_name
  AND d.retention_category = 'unclassified'
  AND d.data_category = 'Unclassified application data — review required';

-- Make every inventory category actionable in the retention register without
-- inventing a duration or approval. Missing policy rows start explicitly TBD.
INSERT INTO public.retention_policies (
  category,
  description,
  retention_days,
  status,
  auto_delete_enabled,
  notes,
  tenant_id
)
SELECT DISTINCT
  d.retention_category,
  'Retention policy placeholder for data inventory category: ' || d.retention_category,
  NULL::integer,
  'tbd',
  false,
  'Migration 0022: category discovered from data inventory. Duration and approval require owner/counsel review.',
  NULL::uuid
FROM public.data_inventory d
WHERE NOT EXISTS (
  SELECT 1
  FROM public.retention_policies rp
  WHERE rp.tenant_id IS NULL
    AND rp.category = d.retention_category
);
