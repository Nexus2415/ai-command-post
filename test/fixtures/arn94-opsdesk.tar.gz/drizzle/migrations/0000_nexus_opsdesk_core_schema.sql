-- ============================================================
-- Nexus OpsDesk — core multi-tenant schema
-- ============================================================

CREATE TYPE public.app_role AS ENUM ('owner_admin','client_admin','client_member','auditor');
CREATE TYPE public.risk_level AS ENUM ('green','yellow','red');
CREATE TYPE public.exec_mode AS ENUM ('shadow','live');
CREATE TYPE public.action_decision AS ENUM ('allow','needs_approval','blocked');
CREATE TYPE public.integration_status AS ENUM ('not_configured','connected','read_only','shadow','live');

-- ---------- profiles ----------
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  email TEXT,
  full_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ---------- user_roles (platform-level) ----------
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.is_platform_admin()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'owner_admin');
$$;

-- ---------- tenants ----------
CREATE TABLE public.tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  industry TEXT,
  status TEXT NOT NULL DEFAULT 'onboarding',
  health TEXT NOT NULL DEFAULT 'unknown',
  mode public.exec_mode NOT NULL DEFAULT 'shadow',
  brand_voice TEXT,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tenants TO authenticated;
GRANT ALL ON public.tenants TO service_role;
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

-- ---------- memberships ----------
CREATE TABLE public.memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  role public.app_role NOT NULL DEFAULT 'client_member',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.memberships TO authenticated;
GRANT ALL ON public.memberships TO service_role;
ALTER TABLE public.memberships ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_tenant_member(_tenant_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_platform_admin()
      OR EXISTS (SELECT 1 FROM public.memberships m
                 WHERE m.tenant_id = _tenant_id AND m.user_id = auth.uid());
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_editor(_tenant_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_platform_admin()
      OR EXISTS (SELECT 1 FROM public.memberships m
                 WHERE m.tenant_id = _tenant_id AND m.user_id = auth.uid()
                   AND m.role IN ('owner_admin','client_admin','client_member'));
$$;

-- ---------- system flags (global kill switch) ----------
CREATE TABLE public.system_flags (
  key TEXT PRIMARY KEY,
  bool_value BOOLEAN NOT NULL DEFAULT false,
  text_value TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by UUID
);
GRANT SELECT, INSERT, UPDATE ON public.system_flags TO authenticated;
GRANT ALL ON public.system_flags TO service_role;
ALTER TABLE public.system_flags ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- Tenant-scoped operational tables
-- ============================================================

CREATE TABLE public.integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  category TEXT NOT NULL,
  status public.integration_status NOT NULL DEFAULT 'not_configured',
  circuit_open BOOLEAN NOT NULL DEFAULT false,
  failure_count INT NOT NULL DEFAULT 0,
  required_credentials TEXT[] NOT NULL DEFAULT '{}',
  setup_notes TEXT,
  last_error TEXT,
  last_checked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, provider)
);

CREATE TABLE public.authority_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  capability TEXT NOT NULL,
  risk public.risk_level NOT NULL DEFAULT 'red',
  live_enabled BOOLEAN NOT NULL DEFAULT false,
  requires_secondary_validation BOOLEAN NOT NULL DEFAULT true,
  amount_threshold_cents BIGINT,
  permitted_domains TEXT[] NOT NULL DEFAULT '{}',
  permitted_recipients TEXT[] NOT NULL DEFAULT '{}',
  rate_limit_per_hour INT,
  min_confidence NUMERIC(4,3) NOT NULL DEFAULT 0.850,
  notes TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, capability)
);

CREATE TABLE public.workflows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  name TEXT NOT NULL,
  agent_role TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  mode public.exec_mode NOT NULL DEFAULT 'shadow',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.workflow_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  workflow_id UUID REFERENCES public.workflows(id) ON DELETE SET NULL,
  mode public.exec_mode NOT NULL DEFAULT 'shadow',
  status TEXT NOT NULL DEFAULT 'queued',
  trigger_source TEXT,
  input JSONB NOT NULL DEFAULT '{}',
  output JSONB NOT NULL DEFAULT '{}',
  attempts INT NOT NULL DEFAULT 0,
  max_attempts INT NOT NULL DEFAULT 3,
  dead_lettered BOOLEAN NOT NULL DEFAULT false,
  correlation_key TEXT,
  error TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);

CREATE TABLE public.proposed_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  workflow_run_id UUID REFERENCES public.workflow_runs(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL,
  capability TEXT,
  payload JSONB NOT NULL DEFAULT '{}',
  expected_outcome TEXT,
  risk public.risk_level NOT NULL DEFAULT 'red',
  decision public.action_decision NOT NULL DEFAULT 'needs_approval',
  policy_rule TEXT,
  guardrail_results JSONB NOT NULL DEFAULT '{}',
  confidence NUMERIC(4,3),
  mode public.exec_mode NOT NULL DEFAULT 'shadow',
  side_effect_executed BOOLEAN NOT NULL DEFAULT false,
  idempotency_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'proposed',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, idempotency_key)
);

CREATE TABLE public.approvals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  proposed_action_id UUID NOT NULL REFERENCES public.proposed_actions(id) ON DELETE CASCADE,
  decided_by UUID,
  decision TEXT NOT NULL,
  reason TEXT,
  decided_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.exceptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  workflow_run_id UUID REFERENCES public.workflow_runs(id) ON DELETE SET NULL,
  severity TEXT NOT NULL DEFAULT 'medium',
  category TEXT,
  title TEXT NOT NULL,
  detail TEXT,
  evidence JSONB NOT NULL DEFAULT '{}',
  recommended_action TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  resolved_by UUID,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  actor TEXT NOT NULL,
  actor_type TEXT NOT NULL DEFAULT 'agent',
  actor_user_id UUID,
  action TEXT NOT NULL,
  capability TEXT,
  inputs JSONB NOT NULL DEFAULT '{}',
  decision TEXT,
  policy_rule TEXT,
  confidence NUMERIC(4,3),
  intended_side_effect TEXT,
  outcome TEXT,
  mode public.exec_mode NOT NULL DEFAULT 'shadow',
  correlation_key TEXT,
  idempotency_key TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  company TEXT,
  source TEXT,
  service_type TEXT,
  estimated_value_cents BIGINT,
  stage TEXT NOT NULL DEFAULT 'new',
  score INT,
  opted_out BOOLEAN NOT NULL DEFAULT false,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  company TEXT,
  role_title TEXT,
  tags TEXT[] NOT NULL DEFAULT '{}',
  opted_out BOOLEAN NOT NULL DEFAULT false,
  last_touch_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.inbox_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  channel TEXT NOT NULL DEFAULT 'email',
  from_name TEXT,
  from_email TEXT,
  subject TEXT,
  body TEXT,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  classification TEXT,
  intent TEXT,
  urgency TEXT,
  status TEXT NOT NULL DEFAULT 'unprocessed',
  duplicate_of UUID REFERENCES public.inbox_items(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  due_at TIMESTAMPTZ,
  priority TEXT NOT NULL DEFAULT 'normal',
  status TEXT NOT NULL DEFAULT 'open',
  owner TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.calendar_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  location TEXT,
  attendees JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'proposed',
  has_conflict BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.channel_capabilities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  channel TEXT NOT NULL,
  research_enabled BOOLEAN NOT NULL DEFAULT true,
  draft_enabled BOOLEAN NOT NULL DEFAULT true,
  asset_ready BOOLEAN NOT NULL DEFAULT false,
  api_connected BOOLEAN NOT NULL DEFAULT false,
  publish_enabled BOOLEAN NOT NULL DEFAULT false,
  setup_notes TEXT,
  UNIQUE (tenant_id, channel)
);

CREATE TABLE public.content_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  channel TEXT NOT NULL,
  stage TEXT NOT NULL DEFAULT 'idea',
  topic TEXT NOT NULL,
  topic_score INT,
  body TEXT,
  variants JSONB NOT NULL DEFAULT '[]',
  source_urls TEXT[] NOT NULL DEFAULT '{}',
  claims JSONB NOT NULL DEFAULT '[]',
  hashtags TEXT[] NOT NULL DEFAULT '{}',
  cta TEXT,
  asset_brief TEXT,
  fact_check_status TEXT NOT NULL DEFAULT 'pending',
  brand_check_status TEXT NOT NULL DEFAULT 'pending',
  scheduled_at TIMESTAMPTZ,
  published_at TIMESTAMPTZ,
  platform_status TEXT NOT NULL DEFAULT 'not_submitted',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.content_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  content_item_id UUID NOT NULL REFERENCES public.content_items(id) ON DELETE CASCADE,
  impressions INT NOT NULL DEFAULT 0,
  engagements INT NOT NULL DEFAULT 0,
  clicks INT NOT NULL DEFAULT 0,
  is_synthetic BOOLEAN NOT NULL DEFAULT true,
  captured_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.billing_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  plan TEXT NOT NULL DEFAULT 'founding_pilot',
  mrr_cents BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'placeholder',
  external_ref TEXT,
  is_placeholder BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id)
);

CREATE TABLE public.test_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  fixture JSONB NOT NULL DEFAULT '{}',
  expected_action_type TEXT,
  expected_decision public.action_decision NOT NULL DEFAULT 'blocked',
  expected_classification TEXT,
  dimensions TEXT[] NOT NULL DEFAULT '{}',
  is_attack BOOLEAN NOT NULL DEFAULT false,
  is_synthetic BOOLEAN NOT NULL DEFAULT true,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, code)
);

CREATE TABLE public.test_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  suite_run_id UUID NOT NULL,
  test_case_id UUID NOT NULL REFERENCES public.test_cases(id) ON DELETE CASCADE,
  passed BOOLEAN NOT NULL DEFAULT false,
  dimension_results JSONB NOT NULL DEFAULT '{}',
  expected_action JSONB NOT NULL DEFAULT '{}',
  proposed_action JSONB NOT NULL DEFAULT '{}',
  engine TEXT NOT NULL DEFAULT 'deterministic_local',
  notes TEXT,
  ran_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.reliability_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  integration_id UUID REFERENCES public.integrations(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info',
  detail TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- public marketing intake ----------
CREATE TABLE public.intake_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  trade TEXT,
  team_size TEXT,
  current_tools TEXT,
  biggest_bottleneck TEXT,
  plan_interest TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT INSERT ON public.intake_submissions TO anon;
GRANT INSERT, SELECT ON public.intake_submissions TO authenticated;
GRANT ALL ON public.intake_submissions TO service_role;
ALTER TABLE public.intake_submissions ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- Grants + RLS for tenant-scoped tables
-- ============================================================
DO $$
DECLARE t TEXT;
  tabs TEXT[] := ARRAY[
    'integrations','authority_policies','workflows','workflow_runs','proposed_actions',
    'approvals','exceptions','audit_events','leads','contacts','inbox_items','tasks',
    'calendar_items','channel_capabilities','content_items','content_metrics',
    'billing_accounts','test_cases','test_runs','reliability_events'
  ];
BEGIN
  FOREACH t IN ARRAY tabs LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format($f$CREATE POLICY %I ON public.%I FOR SELECT TO authenticated
      USING (tenant_id IS NULL OR public.is_tenant_member(tenant_id))$f$, t||'_select', t);
    EXECUTE format($f$CREATE POLICY %I ON public.%I FOR INSERT TO authenticated
      WITH CHECK (public.is_tenant_editor(tenant_id))$f$, t||'_insert', t);
    EXECUTE format($f$CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated
      USING (public.is_tenant_editor(tenant_id)) WITH CHECK (public.is_tenant_editor(tenant_id))$f$, t||'_update', t);
    EXECUTE format($f$CREATE POLICY %I ON public.%I FOR DELETE TO authenticated
      USING (public.is_platform_admin())$f$, t||'_delete', t);
    EXECUTE format('CREATE INDEX %I ON public.%I (tenant_id)', 'idx_'||t||'_tenant', t);
  END LOOP;
END $$;

-- ---------- policies for platform tables ----------
CREATE POLICY profiles_select ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_platform_admin());
CREATE POLICY profiles_insert ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());
CREATE POLICY profiles_update ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());

CREATE POLICY user_roles_select ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_platform_admin());

CREATE POLICY tenants_select ON public.tenants FOR SELECT TO authenticated
  USING (public.is_tenant_member(id));
CREATE POLICY tenants_insert ON public.tenants FOR INSERT TO authenticated
  WITH CHECK (public.is_platform_admin());
CREATE POLICY tenants_update ON public.tenants FOR UPDATE TO authenticated
  USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());
CREATE POLICY tenants_delete ON public.tenants FOR DELETE TO authenticated
  USING (public.is_platform_admin());

CREATE POLICY memberships_select ON public.memberships FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_platform_admin());
CREATE POLICY memberships_write ON public.memberships FOR ALL TO authenticated
  USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());

CREATE POLICY system_flags_select ON public.system_flags FOR SELECT TO authenticated USING (true);
CREATE POLICY system_flags_insert ON public.system_flags FOR INSERT TO authenticated
  WITH CHECK (public.is_platform_admin());
CREATE POLICY system_flags_update ON public.system_flags FOR UPDATE TO authenticated
  USING (public.is_platform_admin()) WITH CHECK (public.is_platform_admin());

CREATE POLICY intake_insert_anon ON public.intake_submissions FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY intake_insert_auth ON public.intake_submissions FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY intake_select_admin ON public.intake_submissions FOR SELECT TO authenticated
  USING (public.is_platform_admin());

-- ---------- profile bootstrap ----------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END $$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

INSERT INTO public.system_flags (key, bool_value, text_value)
VALUES ('global_kill_switch', false, 'When enabled, all autonomous execution halts immediately.'),
       ('default_mode', false, 'shadow');
