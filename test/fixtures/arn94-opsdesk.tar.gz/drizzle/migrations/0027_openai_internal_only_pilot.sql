-- Founding-pilot processor minimization:
-- OpenAI is allowed only for synthetic_seed/internal_test shadow evaluation.
-- Customer tenants are blocked in server code before any OpenAI client/model call.
-- If a future change permits customer tenant data to reach OpenAI, this register
-- must be changed back to handles_tenant_data=true and the processor/DPA gate rerun.

UPDATE public.subprocessors
SET handles_tenant_data = false,
    notes = concat_ws(E'\n', nullif(notes, ''),
      '2026-10-01 founding-pilot fence: OpenAI model-backed evaluation is restricted in code to synthetic_seed/internal_test tenants. Customer/unclassified tenants fail before the OpenAI client is created. Reclassify as tenant-data processor before any future customer-data model path.'),
    updated_at = now()
WHERE provider = 'OpenAI';
