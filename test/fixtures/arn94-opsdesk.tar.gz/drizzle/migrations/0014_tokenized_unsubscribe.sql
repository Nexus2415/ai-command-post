-- Public unsubscribe token redemption without exposing recipient email addresses in URLs.
-- Raw tokens are never stored; only SHA-256 hashes are persisted.

CREATE TABLE public.platform_unsubscribe_tokens (
  token_hash text PRIMARY KEY,
  email text NOT NULL CHECK (email ~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'),
  prospect_id uuid REFERENCES public.platform_prospects(id) ON DELETE SET NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  used_at timestamptz
);

ALTER TABLE public.platform_unsubscribe_tokens ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.platform_unsubscribe_tokens FROM PUBLIC, anon, authenticated;
GRANT ALL ON public.platform_unsubscribe_tokens TO service_role;

CREATE OR REPLACE FUNCTION public.redeem_unsubscribe_token(p_token_hash text)
RETURNS TABLE(suppressed_email text, already_suppressed boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_existing boolean;
BEGIN
  UPDATE public.platform_unsubscribe_tokens
  SET used_at = COALESCE(used_at, now())
  WHERE token_hash = p_token_hash
  RETURNING lower(platform_unsubscribe_tokens.email) INTO v_email;

  IF v_email IS NULL THEN
    RAISE EXCEPTION 'invalid unsubscribe token';
  END IF;

  SELECT EXISTS (
    SELECT 1 FROM public.platform_suppressions s
    WHERE s.email IS NOT NULL AND lower(s.email) = v_email
  ) INTO v_existing;

  IF NOT v_existing THEN
    INSERT INTO public.platform_suppressions (email, reason, source)
    VALUES (v_email, 'recipient unsubscribe request', 'public_unsubscribe_token')
    ON CONFLICT DO NOTHING;
  END IF;

  INSERT INTO public.platform_audit_events
    (action, entity, entity_id, inputs, outcome, side_effect)
  VALUES
    ('public_unsubscribe_redeemed', 'platform_suppressions', NULL,
     jsonb_build_object('token_hash_prefix', left(p_token_hash, 16)),
     'recipient email suppressed from future outreach',
     'internal suppression only');

  RETURN QUERY SELECT v_email, v_existing;
END
$$;

REVOKE ALL ON FUNCTION public.redeem_unsubscribe_token(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.redeem_unsubscribe_token(text) TO service_role;
