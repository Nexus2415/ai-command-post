-- Reduce active processor exposure for founding-pilot launch readiness.
-- PostHog delivery is disabled in code; Inngest receives only an opaque runtime job UUID.

UPDATE public.subprocessors
SET active = false,
    handles_tenant_data = false,
    data_categories = ARRAY[]::text[],
    notes = concat_ws(E'\n', nullif(notes,''),
      '2026-10-01: external PostHog telemetry is hard-disabled in application code pending DPA approval. Database observability remains authoritative.'),
    updated_at = now()
WHERE provider = 'PostHog';

UPDATE public.subprocessors
SET handles_tenant_data = false,
    data_categories = ARRAY['opaque_runtime_job_id']::text[],
    notes = concat_ws(E'\n', nullif(notes,''),
      '2026-10-01: Inngest event contract reduced to a single opaque runtime job UUID. Tenant ID, idempotency key, workflow key and customer payload remain in Arnexyia/Supabase and are resolved only after the worker loads the job row.'),
    updated_at = now()
WHERE provider = 'Inngest';

UPDATE public.data_inventory
SET subprocessors = ARRAY['Lovable Cloud (Supabase)']::text[],
    notes = concat_ws(E'\n', nullif(notes,''),
      '2026-10-01: Inngest no longer receives runtime_jobs row data; only an opaque job UUID is dispatched.')
WHERE table_name = 'runtime_jobs';
