CREATE TABLE public.platform_audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id uuid,
  action text NOT NULL,
  entity text NOT NULL,
  entity_id uuid,
  inputs jsonb NOT NULL DEFAULT '{}'::jsonb,
  outcome text,
  side_effect text NOT NULL DEFAULT 'none',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.platform_audit_events TO authenticated;
GRANT ALL ON public.platform_audit_events TO service_role;
ALTER TABLE public.platform_audit_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY platform_audit_owner_select ON public.platform_audit_events FOR SELECT TO authenticated USING (public.is_platform_admin() OR public.has_role(auth.uid(),'auditor'));
CREATE POLICY platform_audit_owner_insert ON public.platform_audit_events FOR INSERT TO authenticated WITH CHECK (public.is_platform_admin() AND actor_user_id = auth.uid());
CREATE TRIGGER platform_audit_immutable BEFORE UPDATE OR DELETE ON public.platform_audit_events FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();