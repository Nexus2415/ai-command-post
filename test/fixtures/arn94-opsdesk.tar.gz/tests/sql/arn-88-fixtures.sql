-- ARN-88 synthetic fixtures. Test-only helper schema `arn88_test`, created in the throwaway database after the
-- migrations are replayed. Synthetic data only; never run against a real project.
\set ON_ERROR_STOP 1
\set QUIET 1
\o /dev/null
DROP SCHEMA IF EXISTS arn88_test CASCADE;
CREATE SCHEMA arn88_test;
GRANT USAGE ON SCHEMA arn88_test TO PUBLIC;

-- Failing assertion helper (same idea as the ARN-67 suite).
CREATE FUNCTION arn88_test.check(ok boolean, what text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF ok IS NOT TRUE THEN RAISE EXCEPTION 'FAILED: %', what; END IF; END $$;

CREATE FUNCTION arn88_test.eq(got anyelement, want anyelement, what text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF got IS DISTINCT FROM want THEN RAISE EXCEPTION 'FAILED: % (got %, want %)', what, got, want; END IF; END $$;

CREATE FUNCTION arn88_test.mk_tenant(p_slug text, p_status text DEFAULT 'shadow_testing') RETURNS uuid
LANGUAGE sql AS $$
  INSERT INTO public.tenants(name, slug, status, tenant_kind)
  VALUES (p_slug, p_slug || '-' || substr(md5(random()::text), 1, 6), p_status, 'internal_test') RETURNING id
$$;

-- One policy + one proposed action + one matching approval + one broker command, for a tenant.
-- Returns {tenant, action, approval, command, key}.
CREATE FUNCTION arn88_test.mk_command(
  p_tenant uuid, p_key text, p_mode text DEFAULT 'shadow', p_capability text DEFAULT 'email.reply',
  p_decision text DEFAULT 'needs_approval', p_approve boolean DEFAULT true,
  p_hard_in int DEFAULT 1000, p_hard_cached int DEFAULT 500, p_hard_out int DEFAULT 400,
  p_title text DEFAULT 'Synthetic command') RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE v_action uuid; v_appr uuid; v_cmd jsonb; v_prev text := current_setting('request.jwt.claims', true);
BEGIN
  INSERT INTO public.authority_policies(tenant_id, capability, risk, live_enabled, requires_secondary_validation)
    VALUES (p_tenant, p_capability, 'yellow', false, true) ON CONFLICT DO NOTHING;
  INSERT INTO public.proposed_actions(tenant_id, action_type, capability, payload, risk, decision, mode, idempotency_key, status)
    VALUES (p_tenant, 'synthetic', p_capability, jsonb_build_object('k', p_key), 'yellow', p_decision::public.action_decision,
            p_mode::public.exec_mode, 'arn88:' || p_key, 'proposed')
    RETURNING id INTO v_action;
  IF p_approve THEN
    INSERT INTO public.approvals(tenant_id, proposed_action_id, decision, proposal_version, payload_fingerprint, policy_version)
      SELECT tenant_id, id, 'approved', proposal_version, payload_fingerprint, policy_version
      FROM public.proposed_actions WHERE id = v_action
      RETURNING id INTO v_appr;
  END IF;
  PERFORM set_config('request.jwt.claims', jsonb_build_object('tenant_ids', jsonb_build_array(p_tenant::text))::text, false);
  v_cmd := public.broker_record_command(p_tenant, p_key, 'LIN-' || p_key, p_title, v_action, p_hard_in, p_hard_cached, p_hard_out);
  PERFORM set_config('request.jwt.claims', coalesce(v_prev, ''), false);
  IF NOT (v_cmd ->> 'ok')::boolean THEN RAISE EXCEPTION 'fixture: record_command refused %', v_cmd; END IF;
  RETURN jsonb_build_object('tenant', p_tenant, 'action', v_action, 'approval', v_appr,
                            'command', v_cmd ->> 'command_id', 'key', p_key);
END $$;

-- USD per million tokens; micro-USD per token. Defaults: input 2, cached 1, output 10.
CREATE FUNCTION arn88_test.mk_tariff(p_name text, p_in numeric DEFAULT 2, p_cached numeric DEFAULT 1, p_out numeric DEFAULT 10,
                                     p_version text DEFAULT 'v1', p_exact boolean DEFAULT false) RETURNS uuid
LANGUAGE sql AS $$
  INSERT INTO public.model_cost_rates(provider, model, rate_version, input_usd_per_million, output_usd_per_million,
                                      cached_input_usd_per_million, source_note, effective_from)
  VALUES ('synthetic', CASE WHEN p_exact THEN p_name ELSE p_name || '-' || substr(md5(random()::text), 1, 6) END,
          p_version, p_in, p_out, p_cached, 'synthetic test tariff', now() - interval '1 day')
  RETURNING id
$$;

CREATE FUNCTION arn88_test.mk_budgets(p_tenant uuid, p_global_cap bigint, p_tenant_cap bigint, p_period date DEFAULT NULL)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE v_p date := coalesce(p_period, date_trunc('month', now() AT TIME ZONE 'UTC')::date);
BEGIN
  INSERT INTO public.execution_budgets(scope, tenant_id, period, cap_micros)
    VALUES ('global', NULL, v_p, p_global_cap) ON CONFLICT DO NOTHING;
  INSERT INTO public.execution_budgets(scope, tenant_id, period, cap_micros)
    VALUES ('tenant', p_tenant, v_p, p_tenant_cap) ON CONFLICT DO NOTHING;
END $$;

-- Session identity as the broker would see it from a verified JWT.
CREATE FUNCTION arn88_test.as_exec(p_exec text, p_tenants uuid[]) RETURNS void LANGUAGE sql AS $$
  SELECT set_config('request.jwt.claims',
    jsonb_build_object('executor', p_exec, 'tenant_ids', to_jsonb(p_tenants::text[]))::text, false)
$$;

CREATE FUNCTION arn88_test.budget(p_scope text, p_tenant uuid, p_period date DEFAULT NULL) RETURNS public.execution_budgets
LANGUAGE sql STABLE AS $$
  SELECT b FROM public.execution_budgets b
  WHERE b.scope = p_scope AND b.tenant_id IS NOT DISTINCT FROM p_tenant
    AND b.period = coalesce(p_period, date_trunc('month', now() AT TIME ZONE 'UTC')::date)
$$;

-- Money invariant that must hold after every committed change on a budget pair.
CREATE FUNCTION arn88_test.assert_invariants(p_label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  PERFORM arn88_test.check(NOT EXISTS (
    SELECT 1 FROM public.execution_budgets b
    WHERE b.reserved_micros < 0 OR b.settled_micros < 0 OR b.overrun_micros < 0), p_label || ': no negative balance');
  -- Every held reservation on the books equals the sum of live attempts' reservations, per budget row.
  PERFORM arn88_test.check(NOT EXISTS (
    SELECT 1 FROM public.execution_budgets b
    WHERE b.reserved_micros <> coalesce((
      SELECT sum(a.reserved_micros) FROM public.execution_attempts a
      JOIN public.execution_claims c ON c.id = a.claim_id
      WHERE a.budget_period = b.period AND a.state IN ('claimed','dispatched','unknown')
        AND (b.scope = 'global' OR c.tenant_id = b.tenant_id)), 0)), p_label || ': reserved equals live attempt reservations');
  PERFORM arn88_test.check(NOT EXISTS (
    SELECT 1 FROM public.execution_budgets b
    WHERE b.settled_micros <> coalesce((
      SELECT sum(a.actual_micros) FROM public.execution_attempts a
      JOIN public.execution_claims c ON c.id = a.claim_id
      WHERE a.budget_period = b.period AND a.actual_micros IS NOT NULL
        AND (b.scope = 'global' OR c.tenant_id = b.tenant_id)), 0)), p_label || ': settled equals recorded actuals');
  PERFORM arn88_test.check(NOT EXISTS (
    SELECT 1 FROM public.execution_claims c
    JOIN LATERAL (SELECT state FROM public.execution_attempts WHERE claim_id = c.id ORDER BY attempt_no DESC LIMIT 1) a ON true
    WHERE c.state <> a.state AND NOT (a.state = 'failed' AND c.state = 'failed')), p_label || ': claim state follows its latest attempt');
END $$;

-- Count of all broker audit rows (the audit table holds only broker rows in the throwaway database).
CREATE FUNCTION arn88_test.audit_count(p_action text DEFAULT NULL) RETURNS bigint LANGUAGE sql STABLE AS $$
  SELECT count(*) FROM public.audit_events WHERE policy_rule = 'execution_broker' AND (p_action IS NULL OR action = p_action)
$$;

-- Snapshot of every broker table, for "a refusal changes nothing" assertions.
CREATE FUNCTION arn88_test.snapshot() RETURNS text LANGUAGE sql STABLE AS $$
  SELECT md5(
    coalesce((SELECT string_agg(b::text, '|' ORDER BY b.id) FROM public.execution_budgets b), '') || '#' ||
    coalesce((SELECT string_agg(c::text, '|' ORDER BY c.id) FROM public.execution_claims c), '') || '#' ||
    coalesce((SELECT string_agg(a::text, '|' ORDER BY a.id) FROM public.execution_attempts a), '') || '#' ||
    coalesce((SELECT string_agg(u::text, '|' ORDER BY u.attempt_id) FROM public.execution_usage u), '') || '#' ||
    arn88_test.audit_count())
$$;

-- Cost of usage under a tariff, for expected values in assertions.
CREATE FUNCTION arn88_test.cost(p_tariff uuid, p_in bigint, p_cached bigint, p_out bigint) RETURNS bigint LANGUAGE sql STABLE AS $$
  SELECT ceil((p_in - p_cached) * input_usd_per_million + p_cached * cached_input_usd_per_million + p_out * output_usd_per_million)::bigint
  FROM public.model_cost_rates WHERE id = p_tariff
$$;

-- Service-role stand-in uid for the admin sessions.
INSERT INTO auth.users(id, email) VALUES
  ('00000000-0000-4000-8000-0000000088a1', 'broker-admin@example.test'),
  ('00000000-0000-4000-8000-0000000088b2', 'broker-member@example.test') ON CONFLICT DO NOTHING;
INSERT INTO public.user_roles(user_id, role) VALUES ('00000000-0000-4000-8000-0000000088a1', 'owner_admin') ON CONFLICT DO NOTHING;

-- ---------------------------------------------------------------------------------------------------------
-- Role-switching wrappers. Each runs one RPC as the real broker role with the identity claims a verified JWT
-- would carry, then returns to the superuser fixture role. They return the RPC's jsonb unchanged.
-- ---------------------------------------------------------------------------------------------------------
CREATE FUNCTION arn88_test.claim(p_exec text, p_tenant uuid, p_key text, p_cmd jsonb, p_tf uuid,
    p_in int DEFAULT 100, p_cached int DEFAULT 50, p_out int DEFAULT 40, p_jwt_tenants uuid[] DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM arn88_test.as_exec(p_exec, coalesce(p_jwt_tenants, ARRAY[p_tenant]));
  SET LOCAL ROLE broker_caller;
  r := public.broker_claim_and_reserve(p_tenant, p_key, (p_cmd ->> 'command')::uuid, p_tf, p_in, p_cached, p_out);
  RESET ROLE;
  RETURN r;
END $$;

CREATE FUNCTION arn88_test.dispatch(p_exec text, p_tenant uuid, p_attempt uuid, p_fence bigint) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM arn88_test.as_exec(p_exec, ARRAY[p_tenant]);
  SET LOCAL ROLE broker_caller;
  r := public.broker_mark_dispatched(p_attempt, p_fence);
  RESET ROLE;
  RETURN r;
END $$;

CREATE FUNCTION arn88_test.unknown(p_exec text, p_tenant uuid, p_attempt uuid, p_fence bigint) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM arn88_test.as_exec(p_exec, ARRAY[p_tenant]);
  SET LOCAL ROLE broker_caller;
  r := public.broker_mark_unknown(p_attempt, p_fence);
  RESET ROLE;
  RETURN r;
END $$;

CREATE FUNCTION arn88_test.release(p_exec text, p_tenant uuid, p_attempt uuid, p_fence bigint) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM arn88_test.as_exec(p_exec, ARRAY[p_tenant]);
  SET LOCAL ROLE broker_caller;
  r := public.broker_release(p_attempt, p_fence, 'test');
  RESET ROLE;
  RETURN r;
END $$;

CREATE FUNCTION arn88_test.fail(p_exec text, p_tenant uuid, p_attempt uuid, p_fence bigint) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM arn88_test.as_exec(p_exec, ARRAY[p_tenant]);
  SET LOCAL ROLE broker_caller;
  r := public.broker_mark_failed(p_attempt, p_fence, 'test');
  RESET ROLE;
  RETURN r;
END $$;

-- Gateway forward only (the provider was reached), without usage capture.
CREATE FUNCTION arn88_test.forward(p_attempt uuid) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  SET LOCAL ROLE broker_gateway;
  r := public.broker_mark_forwarded(p_attempt);
  RESET ROLE;
  RETURN r;
END $$;

CREATE FUNCTION arn88_test.status(p_exec text, p_tenant uuid, p_claim uuid) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM arn88_test.as_exec(p_exec, ARRAY[p_tenant]);
  SET LOCAL ROLE broker_caller;
  r := public.broker_claim_status(p_claim);
  RESET ROLE;
  RETURN r;
END $$;

CREATE FUNCTION arn88_test.settle(p_exec text, p_tenant uuid, p_attempt uuid, p_op text, p_actual numeric, p_evidence text) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM arn88_test.as_exec(p_exec, ARRAY[p_tenant]);
  SET LOCAL ROLE broker_caller;
  r := public.broker_settle(p_attempt, p_op, p_actual, p_evidence);
  RESET ROLE;
  RETURN r;
END $$;

-- Gateway: forward once, capture the provider's usage, as the broker_gateway role. Returns the evidence hash.
CREATE OR REPLACE FUNCTION arn88_test.gateway_capture(p_attempt uuid, p_in bigint, p_cached bigint, p_out bigint,
                                                      p_label text DEFAULT 'r') RETURNS text
LANGUAGE plpgsql AS $$
DECLARE v_hash text := encode(sha256(convert_to(p_label || ':' || p_attempt::text || ':' || p_in || ':' || p_cached || ':' || p_out, 'UTF8')), 'hex');
        r jsonb;
BEGIN
  SET LOCAL ROLE broker_gateway;
  r := public.broker_mark_forwarded(p_attempt);
  IF NOT (r ->> 'ok')::boolean THEN RESET ROLE; RAISE EXCEPTION 'fixture: forward refused %', r; END IF;
  r := public.broker_capture_usage(p_attempt, 'prov-' || p_label || '-' || p_attempt::text, p_in, p_cached, p_out, v_hash);
  RESET ROLE;
  IF NOT (r ->> 'ok')::boolean THEN RAISE EXCEPTION 'fixture: capture refused %', r; END IF;
  RETURN v_hash;
END $$;

-- Owner path, as a signed-in user (uid) of the `authenticated` role.
CREATE FUNCTION arn88_test.resolve(p_uid uuid, p_attempt uuid, p_decision text, p_actual numeric, p_evidence jsonb) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM set_config('test.uid', coalesce(p_uid::text, ''), false);
  SET LOCAL ROLE authenticated;
  r := public.broker_resolve_unknown(p_attempt, p_decision, p_actual, p_evidence);
  RESET ROLE;
  RETURN r;
END $$;

CREATE FUNCTION arn88_test.reconcile(p_uid uuid, p_scope text, p_tenant uuid, p_period date, p_note text) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  PERFORM set_config('test.uid', coalesce(p_uid::text, ''), false);
  SET LOCAL ROLE authenticated;
  r := public.broker_reconcile_freeze(p_scope, p_tenant, p_period, p_note);
  RESET ROLE;
  RETURN r;
END $$;

-- Convenience: a dispatched attempt with captured usage. Returns {claim, attempt, op, fence, hash}.
CREATE FUNCTION arn88_test.dispatched(p_exec text, p_tenant uuid, p_key text, p_cmd jsonb, p_tf uuid,
    p_in int DEFAULT 100, p_cached int DEFAULT 50, p_out int DEFAULT 40) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE r jsonb; d jsonb;
BEGIN
  r := arn88_test.claim(p_exec, p_tenant, p_key, p_cmd, p_tf, p_in, p_cached, p_out);
  IF NOT (r ->> 'ok')::boolean THEN RAISE EXCEPTION 'fixture: claim refused %', r; END IF;
  d := arn88_test.dispatch(p_exec, p_tenant, (r ->> 'attempt_id')::uuid, (r ->> 'fence')::bigint);
  IF NOT (d ->> 'ok')::boolean THEN RAISE EXCEPTION 'fixture: dispatch refused %', d; END IF;
  RETURN r;
END $$;

-- Simulate a month rollover for an attempt: the reservation was made in an earlier month. Superuser fixture
-- only (triggers bypassed): moves the attempt, and the amount it holds, to last month's budget rows.
CREATE FUNCTION arn88_test.age_attempt(p_attempt uuid) RETURNS date LANGUAGE plpgsql AS $$
DECLARE a public.execution_attempts; c public.execution_claims; v_old date; v_cur date := date_trunc('month', now() AT TIME ZONE 'UTC')::date;
BEGIN
  SELECT * INTO a FROM public.execution_attempts WHERE id = p_attempt;
  SELECT * INTO c FROM public.execution_claims WHERE id = a.claim_id;
  v_old := (v_cur - interval '1 month')::date;
  PERFORM set_config('session_replication_role', 'replica', true);
  INSERT INTO public.execution_budgets(scope, tenant_id, period, cap_micros)
    SELECT scope, tenant_id, v_old, cap_micros FROM public.execution_budgets
    WHERE period = v_cur AND (scope = 'global' OR tenant_id = c.tenant_id) ON CONFLICT DO NOTHING;
  UPDATE public.execution_budgets SET reserved_micros = reserved_micros - a.reserved_micros
    WHERE period = v_cur AND (scope = 'global' OR tenant_id = c.tenant_id);
  UPDATE public.execution_budgets SET reserved_micros = reserved_micros + a.reserved_micros
    WHERE period = v_old AND (scope = 'global' OR tenant_id = c.tenant_id);
  UPDATE public.execution_attempts SET budget_period = v_old WHERE id = p_attempt;
  PERFORM set_config('session_replication_role', 'origin', true);
  RETURN v_old;
END $$;

-- Reset every broker row, the audit rows the broker wrote, and the flags, so each scenario starts clean.
CREATE FUNCTION arn88_test.reset_world() RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  PERFORM set_config('session_replication_role', 'replica', true);
  DELETE FROM public.execution_usage;
  DELETE FROM public.execution_attempts;
  DELETE FROM public.execution_claims;
  DELETE FROM public.acp_commands;
  DELETE FROM public.execution_budgets;
  DELETE FROM public.audit_events WHERE policy_rule = 'execution_broker';
  PERFORM set_config('session_replication_role', 'origin', true);
  UPDATE public.system_flags SET bool_value = false WHERE key IN ('global_kill_switch','limited_live_ready');
  PERFORM set_config('arn88.fail_audit', '', true);
  PERFORM set_config('request.jwt.claims', '', false);
  PERFORM set_config('test.uid', '', false);
END $$;

-- Test-only fault injection: a trigger on audit_events that raises for one named broker action, so a
-- failing audit insert can be shown to roll the whole operation back (A3).
CREATE FUNCTION arn88_test.audit_fault() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.policy_rule = 'execution_broker' AND NEW.action = nullif(current_setting('arn88.fail_audit', true), '') THEN
    RAISE EXCEPTION 'injected audit failure for %', NEW.action;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER arn88_audit_fault BEFORE INSERT ON public.audit_events
  FOR EACH ROW EXECUTE FUNCTION arn88_test.audit_fault();

-- A fresh tenant with budgets, a tariff and one approved command. Returns {t, tf, cmd (the mk_command jsonb)}.
CREATE FUNCTION arn88_test.world(p_global_cap bigint DEFAULT 1000000, p_tenant_cap bigint DEFAULT 1000000,
                                 p_key text DEFAULT 'k1') RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE t uuid := arn88_test.mk_tenant('w'); tf uuid := arn88_test.mk_tariff('m-' || substr(md5(random()::text), 1, 6));
BEGIN
  PERFORM arn88_test.mk_budgets(t, p_global_cap, p_tenant_cap);
  RETURN jsonb_build_object('t', t, 'tf', tf, 'cmd', arn88_test.mk_command(t, p_key));
END $$;

CREATE FUNCTION arn88_test.ok(r jsonb) RETURNS boolean LANGUAGE sql IMMUTABLE AS $$ SELECT coalesce((r ->> 'ok')::boolean, false) $$;

-- ---------------------------------------------------------------------------------------------------------
-- Crash-case fault points (K1-K5). A test-only trigger parks the session in pg_sleep at a named step while a
-- second session terminates the backend with pg_terminate_backend. Nothing here exists in the migration.
-- ---------------------------------------------------------------------------------------------------------
CREATE TABLE arn88_test.faults(point text PRIMARY KEY, armed boolean NOT NULL DEFAULT false);
GRANT SELECT ON arn88_test.faults TO PUBLIC;

-- Park the session while the point stays armed (up to 60s), so a controller can either terminate the backend
-- or disarm the point to let it continue.
CREATE FUNCTION arn88_test.park(p_point text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE i int := 0;
BEGIN
  WHILE i < 1200 AND EXISTS (SELECT 1 FROM arn88_test.faults WHERE point = p_point AND armed) LOOP
    PERFORM pg_sleep(0.05); i := i + 1;
  END LOOP;
END $$;

CREATE FUNCTION arn88_test.fault_budget() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM arn88_test.park('budget_update');
  RETURN NEW;
END $$;
CREATE TRIGGER arn88_fault_budget BEFORE UPDATE ON public.execution_budgets FOR EACH ROW EXECUTE FUNCTION arn88_test.fault_budget();

CREATE FUNCTION arn88_test.fault_attempt() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM arn88_test.park('attempt_update:' || NEW.state);
  RETURN NEW;
END $$;
CREATE TRIGGER arn88_fault_attempt BEFORE UPDATE ON public.execution_attempts FOR EACH ROW EXECUTE FUNCTION arn88_test.fault_attempt();

CREATE OR REPLACE FUNCTION arn88_test.audit_fault() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.policy_rule = 'execution_broker' THEN
    IF NEW.action = nullif(current_setting('arn88.fail_audit', true), '') THEN
      RAISE EXCEPTION 'injected audit failure for %', NEW.action;
    END IF;
    PERFORM arn88_test.park('audit_insert:' || NEW.action);
  END IF;
  RETURN NEW;
END $$;

-- Login roles for the parallel-connection harness: members of the real broker groups and nothing else.
DO $r$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'arn88_caller') THEN CREATE ROLE arn88_caller LOGIN IN ROLE broker_caller; END IF;
END $r$;
