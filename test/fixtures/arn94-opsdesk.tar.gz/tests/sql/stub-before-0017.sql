-- shadow_readiness view exists in Supabase but no repo migration creates it (test stand-in).
CREATE OR REPLACE VIEW public.shadow_readiness AS SELECT id AS tenant_id FROM public.tenants;
