-- setup_checklist exists in Supabase but no repo migration creates it; shape from src/integrations/supabase/types.ts.
CREATE TABLE IF NOT EXISTS public.setup_checklist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id),
  item_key text NOT NULL, label text NOT NULL, category text NOT NULL, required_for text NOT NULL,
  status text NOT NULL DEFAULT 'pending', owner_action_required boolean NOT NULL DEFAULT false,
  notes text, created_at timestamptz NOT NULL DEFAULT now());
CREATE OR REPLACE FUNCTION public.run_shadow_suite(uuid) RETURNS void LANGUAGE sql AS $$ SELECT $$;
